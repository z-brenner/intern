# InternBench: live run

- **Run:** 2026-11-12T20:41:03Z · commit `343ee39b8e`
- **Machine:** AMD EPYC 9V45 96-Core Processor, 4 logical cores, 15.6 GB RAM, linux (Ubuntu 24.04.5 LTS)
- **Model:** `intern-local` · 5.68 GB · sha256 `03b74727a860`
- **Corpus:** 57 documents · 57 completed · gold `77806e64ab`
- **Wall time:** 1761.41 s for the whole run, the worker's start included

## Scorecard

| Score | Result |
| --- | ---: |
| Filename (the whole name) | 19/53 (35.9%) |
| Document type | 43/57 (75.4%) |
| Date | 45/53 (84.9%) |
| Date role (when the reviewed date was chosen) | 21/44 (47.7%) |
| Parties | 35/57 (61.4%) |
| Relation word (when parties were named) | 31/48 (64.6%) |
| Party in the right role (when parties were named) | 21/31 (67.7%) |
| Ready / review routing | 11/35 (31.4%) |
| Description states nothing false | 54/57 (94.7%) |
| Description is specific | 37/57 (64.9%) |
| Description specificity | 61.4% (mean of 57) |
| Evidence recall (model's quotes) | 65.5% (mean of 56) |
| Digest recall (facts reaching the digest) | 83.9% (mean of 56) |
| Prompt recall (facts reaching the prompt sent) | 81.2% (mean of 56) |
| Sent to review | 91.2% of 57 completed |

## Phase 3 scorecard

| Figure | Value | Docs |
| --- | ---: | ---: |
| Long-document filename accuracy (10+ pages) | 45.5% | 11 |
| Complex-document filename accuracy | – | 0 |
| Description completeness | – | 0 |
| Unsupported-fact rate (documents) | 75.4% | 57 |
| Review rate | 91.2% | 57 |
| Evidence recall | 65.5% | 56 |
| Total latency p50 | 28.97 s | 57 |
| Total latency p95 | 45.28 s | 57 |
| Generation latency p50 | 14.76 s | 57 |
| Generation latency p95 | 20.33 s | 57 |
| Generated tokens p50 | 91 | 57 |
| Generated tokens p95 | 123 | 57 |
| Prompt tokens p50 | 815 | 57 |

Long: 10 pages or more. Complex: any of `referenced_agreement`, `middle_fact`, `multi_column`, `layout_parties`, `irrelevant_names`, `information_dense`, `stream_order`, `date_in_table`, `key_value`, `complex_pdf`. Unsupported-fact rate: documents with any `*_UNSUPPORTED` review reason. Latency and tokens over the documents that completed.

## Safety

| Check | Count |
| --- | ---: |
| Filed without review under a wrong name | 1 of 53 |
| Trap date chosen | 3 of 56 |
| Forbidden party named | 7 of 57 |
| Spurious parties named | 18 |
| Description states a known-wrong fact | 0 |
| Unsupported description claims | 3 of 143 (2.1%) |
| Right name sent to review anyway | 11 of 29 |
| Sent to review for an unsupported fact | 43 of 57 |

## By kind

| Kind | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| email | 1 | 0/1 | 1/1 | 0/1 | – | 100.0% | 28.84 s | 28.84 s |
| form | 3 | 0/2 | 1/2 | 0/3 | 1/1 | 100.0% | 36.93 s | 37.02 s |
| invoice | 5 | 0/5 | 1/5 | 0/5 | 1/1 | 80.0% | 15.93 s | 29.15 s |
| letter | 22 | 12/22 | 20/22 | 19/22 | 2/13 | 95.5% | 29.71 s | 45.28 s |
| memo | 6 | 0/6 | 6/6 | 3/6 | 0/4 | 100.0% | 33.82 s | 47.14 s |
| minutes | 5 | 2/5 | 5/5 | 4/5 | 1/4 | 80.0% | 33.64 s | 39.94 s |
| notice | 11 | 5/9 | 9/9 | 7/11 | 4/10 | 81.8% | 22.45 s | 41.72 s |
| receipt | 1 | 0/1 | 0/1 | 0/1 | – | 100.0% | 16.30 s | 16.30 s |
| report | 1 | – | – | 1/1 | 1/1 | 100.0% | 26.95 s | 26.95 s |
| statement | 2 | 0/2 | 2/2 | 1/2 | 1/1 | 100.0% | 28.14 s | 37.34 s |

## By text layer

| Text layer | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| image | 6 | 0/6 | 0/6 | 1/6 | – | 100.0% | 15.93 s | 24.86 s |
| native | 40 | 17/38 | 38/38 | 29/40 | 6/27 | 90.0% | 31.28 s | 45.28 s |
| office | 4 | 0/2 | 2/2 | 1/4 | 3/3 | 100.0% | 26.27 s | 28.14 s |
| scan | 7 | 2/7 | 5/7 | 4/7 | 2/5 | 85.7% | 31.68 s | 43.39 s |

## By page count

| Pages | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 19 | 3/16 | 9/16 | 8/19 | 5/10 | 94.7% | 20.38 s | 32.92 s |
| 2-4 | 16 | 5/16 | 15/16 | 9/16 | 4/8 | 81.2% | 29.71 s | 47.14 s |
| 5-9 | 11 | 6/10 | 10/10 | 10/11 | 2/9 | 90.9% | 31.28 s | 41.72 s |
| 10-24 | 9 | 5/9 | 9/9 | 8/9 | 0/7 | 100.0% | 38.72 s | 45.28 s |
| 25-49 | 1 | 0/1 | 1/1 | 0/1 | 0/1 | 100.0% | 43.39 s | 43.39 s |
| 50-99 | 1 | 0/1 | 1/1 | 0/1 | – | 100.0% | 85.23 s | 85.23 s |

## By slice

| Slice | Docs | Filename | Date | Parties | Routing | Unsafe ready | p50 total | p95 total | p50 generation | p95 generation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| long | 11 | 5/11 | 11/11 | 8/11 | 0/8 | 0 of 11 | 39.94 s | 85.23 s | 16.18 s | 20.80 s |

`long`: 10 pages or more. `complex`: any of the categories listed under the phase 3 scorecard. A document may be in both.

## By challenge

| Category | Docs | Filename | Date | Parties | Traps sprung |
| --- | ---: | ---: | ---: | ---: | ---: |
| addressed_to_person | 1 | 1/1 | 1/1 | 1/1 | 0 |
| addressee_redacted | 6 | 3/6 | 6/6 | 4/6 | 0 |
| advisory_committee | 2 | 1/2 | 2/2 | 2/2 | 0 |
| agency_guidance | 4 | 0/4 | 4/4 | 2/4 | 0 |
| annex_table | 1 | 0/1 | 1/1 | 1/1 | 0 |
| approval_letter | 3 | 3/3 | 3/3 | 3/3 | 0 |
| as_of_date | 2 | 0/2 | 2/2 | 1/2 | 0 |
| attachments | 5 | 3/5 | 5/5 | 4/5 | 0 |
| attachments_listed | 1 | 0/1 | 1/1 | 0/1 | 1 |
| attendance_list | 2 | 1/2 | 2/2 | 2/2 | 0 |
| attendee_list | 1 | 0/1 | 1/1 | 0/1 | 1 |
| billhead | 4 | 0/4 | 0/4 | 0/4 | 0 |
| blank_template | 1 | – | – | 0/1 | 0 |
| board_minutes | 2 | 1/2 | 2/2 | 2/2 | 0 |
| body_recounts_events | 1 | 0/1 | 1/1 | 1/1 | 0 |
| born_digital | 40 | 17/38 | 38/38 | 29/40 | 7 |
| care_of_counsel | 2 | 1/2 | 2/2 | 2/2 | 0 |
| charts | 1 | 0/1 | 1/1 | 1/1 | 0 |
| circular_letter | 2 | 0/2 | 2/2 | 2/2 | 0 |
| competing_dates | 36 | 16/36 | 33/36 | 26/36 | 3 |
| court_notice | 5 | 1/3 | 3/3 | 2/5 | 3 |
| cover_letter | 1 | 0/1 | 1/1 | 0/1 | 1 |
| cover_sheet | 2 | 0/2 | 1/2 | 0/2 | 1 |
| customer_first | 5 | 0/5 | 1/5 | 0/5 | 1 |
| date_at_end | 1 | 0/1 | 1/1 | 1/1 | 0 |
| date_partly_illegible | 1 | 0/1 | 0/1 | 1/1 | 0 |
| dated_line_at_end | 4 | 2/4 | 4/4 | 3/4 | 1 |
| deadline_in_body | 5 | 2/3 | 3/3 | 2/5 | 4 |
| determination | 1 | 0/1 | 1/1 | 1/1 | 0 |
| digital_signature_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| docx | 3 | 0/1 | 1/1 | 1/3 | 2 |
| due_date | 1 | 0/1 | 1/1 | 0/1 | 1 |
| effective_dates | 1 | 0/1 | 1/1 | 1/1 | 0 |
| email | 1 | 0/1 | 1/1 | 0/1 | 1 |
| email_printed_to_pdf | 1 | 0/1 | 1/1 | 0/1 | 1 |
| email_thread | 1 | 0/1 | 1/1 | 0/1 | 1 |
| enforcement_release | 3 | 3/3 | 3/3 | 3/3 | 0 |
| engraved_letterhead | 1 | 0/1 | 0/1 | 0/1 | 0 |
| eu_agency | 1 | 0/1 | 1/1 | 1/1 | 0 |
| eu_body | 2 | 1/2 | 2/2 | 2/2 | 0 |
| financial_report | 1 | 0/1 | 1/1 | 1/1 | 0 |
| foi_release | 2 | 0/2 | 2/2 | 0/2 | 2 |
| foi_response | 5 | 2/5 | 5/5 | 3/5 | 0 |
| foreign_company | 1 | 1/1 | 1/1 | 1/1 | 0 |
| form | 3 | 0/2 | 1/2 | 0/3 | 1 |
| former_name | 1 | 1/1 | 1/1 | 1/1 | 0 |
| gazette | 4 | 2/4 | 4/4 | 3/4 | 1 |
| government_form | 2 | 0/2 | 1/2 | 0/2 | 1 |
| handwritten | 6 | 0/6 | 0/6 | 1/6 | 0 |
| handwritten_dates | 2 | 0/2 | 1/2 | 0/2 | 1 |
| historic | 6 | 0/6 | 0/6 | 1/6 | 0 |
| historical | 2 | 0/2 | 1/2 | 0/2 | 1 |
| image | 6 | 0/6 | 0/6 | 1/6 | 0 |
| invoice | 5 | 0/5 | 1/5 | 0/5 | 1 |
| invoices_attached | 2 | 0/2 | 2/2 | 1/2 | 0 |
| issuer_not_named | 2 | 0/2 | 2/2 | 0/2 | 0 |
| joint_meeting | 1 | 0/1 | 1/1 | 1/1 | 0 |
| letter | 22 | 12/22 | 20/22 | 19/22 | 1 |
| letter_from_company | 3 | 1/3 | 2/3 | 3/3 | 0 |
| letterhead | 3 | 1/3 | 2/3 | 2/3 | 0 |
| liquidation | 3 | 2/3 | 3/3 | 2/3 | 1 |
| long_document | 5 | 3/5 | 5/5 | 3/5 | 0 |
| many_dates | 8 | 1/6 | 6/6 | 6/8 | 2 |
| many_parties | 1 | 0/1 | 1/1 | 0/1 | 1 |
| memo | 6 | 0/6 | 6/6 | 3/6 | 0 |
| memorandum | 4 | 0/4 | 4/4 | 1/4 | 0 |
| metadata_date_trap | 3 | 0/3 | 2/3 | 0/3 | 2 |
| minutes | 5 | 2/5 | 5/5 | 4/5 | 1 |
| modern | 46 | 19/42 | 42/42 | 33/46 | 8 |
| month_only_date | 1 | – | – | 1/1 | 1 |
| multiple_letters | 2 | 1/2 | 2/2 | 1/2 | 1 |
| named_officials | 4 | 0/2 | 2/2 | 1/4 | 3 |
| named_person_at_org | 12 | 7/12 | 11/12 | 11/12 | 1 |
| names_removed | 1 | 0/1 | 1/1 | 0/1 | 1 |
| new_zealand | 10 | 4/10 | 10/10 | 7/10 | 1 |
| newsletter | 1 | – | – | 1/1 | 1 |
| no_action_letter | 2 | 2/2 | 2/2 | 2/2 | 0 |
| no_document_date | 3 | – | – | 0/3 | 3 |
| no_inside_address | 1 | 1/1 | 1/1 | 1/1 | 0 |
| no_issuer_printed | 4 | 0/3 | 3/3 | 1/4 | 1 |
| northern_ireland | 2 | – | – | 1/2 | 1 |
| notice | 11 | 5/9 | 9/9 | 7/11 | 4 |
| ocr_text_layer | 7 | 2/7 | 5/7 | 4/7 | 1 |
| office | 4 | 0/2 | 2/2 | 1/4 | 2 |
| paid_stamp | 1 | 0/1 | 0/1 | 0/1 | 0 |
| partly_printed_year | 1 | 0/1 | 0/1 | 0/1 | 0 |
| penalty_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| placeholders | 1 | – | – | 0/1 | 0 |
| printed_form | 1 | 0/1 | 0/1 | 0/1 | 0 |
| public_notice | 8 | 2/6 | 6/6 | 4/8 | 4 |
| publication_timestamp | 4 | 2/4 | 4/4 | 3/4 | 1 |
| receipt | 1 | 0/1 | 0/1 | 0/1 | 0 |
| reference_number | 14 | 3/14 | 14/14 | 9/14 | 0 |
| regulator | 9 | 7/9 | 9/9 | 9/9 | 0 |
| reissued | 1 | 1/1 | 1/1 | 1/1 | 0 |
| relative_date_reference | 1 | 0/1 | 0/1 | 1/1 | 0 |
| remittance_slip | 1 | 0/1 | 1/1 | 0/1 | 1 |
| reply_letter | 1 | 1/1 | 1/1 | 1/1 | 0 |
| report | 1 | – | – | 1/1 | 1 |
| request_letter | 2 | 1/2 | 2/2 | 2/2 | 0 |
| safety_recommendation | 2 | 1/2 | 2/2 | 1/2 | 1 |
| scanned | 7 | 2/7 | 5/7 | 4/7 | 1 |
| sender_at_end | 1 | 0/1 | 1/1 | 1/1 | 0 |
| service_period | 2 | 2/2 | 2/2 | 2/2 | 0 |
| settlement | 2 | 2/2 | 2/2 | 2/2 | 0 |
| short | 1 | 0/1 | 1/1 | 1/1 | 0 |
| signature_scan | 1 | 0/1 | 1/1 | 0/1 | 0 |
| spreadsheet | 1 | 0/1 | 1/1 | 0/1 | 0 |
| staff_names | 4 | 2/4 | 4/4 | 4/4 | 0 |
| stamped_date | 1 | 0/1 | 0/1 | 1/1 | 0 |
| statement | 2 | 0/2 | 2/2 | 1/2 | 0 |
| struck_through_text | 1 | 0/1 | 0/1 | 0/1 | 0 |
| tables | 2 | 0/2 | 2/2 | 1/2 | 0 |
| tax_invoice | 1 | 0/1 | 1/1 | 0/1 | 1 |
| trading_name | 2 | 1/2 | 2/2 | 2/2 | 0 |
| two_addressees | 1 | 0/1 | 1/1 | 1/1 | 0 |
| type_not_printed | 1 | 0/1 | 1/1 | 0/1 | 0 |
| uk | 8 | 2/6 | 6/6 | 3/8 | 4 |
| us_date_format | 1 | 0/1 | 0/1 | 0/1 | 0 |
| us_federal | 28 | 11/26 | 24/26 | 19/28 | 5 |
| vat | 1 | 0/1 | 1/1 | 0/1 | 1 |
| wales | 6 | 2/6 | 6/6 | 2/6 | 3 |
| warning_letter | 3 | 2/3 | 3/3 | 3/3 | 0 |
| xlsx | 1 | 0/1 | 1/1 | 0/1 | 0 |

## Routes

- **Pages:** fast 187 · layout 102 · ocr 44 · ocr_regions 68
- **Documents by route class:** fast 20 · layout 21 · ocr 15 · ocr_regions 1

## Where the time goes

| Stage | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `total_ms` | 57 | 28.97 s | 45.28 s | 85.23 s |
| `extraction_wall_ms` | 57 | 13.0 ms | 4.42 s | 34.31 s |
| `worker_total_ms` | 57 | 12.4 ms | 4.42 s | 34.30 s |
| `worker_snapshot_ms` | 57 | 0.27 ms | 1.1 ms | 2.3 ms |
| `worker_parse_ms` | 57 | 8.0 ms | 50.2 ms | 131.3 ms |
| `worker_analysis_ms` | 57 | 0.87 ms | 6.9 ms | 27.5 ms |
| `worker_render_ms` | 57 | 0.00 ms | 542.2 ms | 19.95 s |
| `worker_image_decode_ms` | 57 | 0.00 ms | 33.2 ms | 69.6 ms |
| `worker_ocr_ms` | 57 | 0.00 ms | 8.25 s | 67.15 s |
| `worker_ocr_encode_ms` | 57 | 0.00 ms | 611.0 ms | 6.31 s |
| `worker_ocr_engine_ms` | 57 | 0.00 ms | 7.39 s | 60.58 s |
| `worker_vision_ms` | 57 | 0.00 ms | 17.9 ms | 27.6 ms |
| `analyze_wall_ms` | 57 | 28.83 s | 41.70 s | 50.92 s |
| `distill_ms` | 57 | 3.0 ms | 22.7 ms | 76.0 ms |
| `prompt_ms` | 57 | 0.03 ms | 0.05 ms | 0.06 ms |
| `inference_ms` | 57 | 28.82 s | 41.68 s | 50.80 s |
| `prefill_ms` | 57 | 13.72 s | 25.19 s | 32.63 s |
| `generation_ms` | 57 | 14.76 s | 20.33 s | 21.63 s |
| `validation_ms` | 57 | 5.0 ms | 17.0 ms | 40.8 ms |
| `naming_ms` | 57 | 0.30 ms | 2.2 ms | 3.3 ms |
| `index_ms` | 57 | 2.4 ms | 20.9 ms | 75.1 ms |
| `retrieval_ms` | 57 | 0.36 ms | 1.8 ms | 4.7 ms |

| Measure | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `prefill_tok_per_s` | 57 | 60.3 tok/s | 62.0 tok/s | 63.2 tok/s |
| `generation_tok_per_s` | 57 | 6.1 tok/s | 6.5 tok/s | 6.6 tok/s |
| `prompt_tokens` | 57 | 815 | 1508 | 1983 |
| `cached_tokens` | 57 | 477 | 477 | 477 |
| `generated_tokens` | 57 | 91 | 123 | 128 |
| `estimated_prompt_tokens` | 57 | 1383 | 2296 | 2346 |
| `model_requests` | 57 | 1 | 1 | 1 |
| `redistillations` | 57 | 0 | 0 | 0 |
| `source_characters` | 57 | 5735 | 49993 | 104046 |
| `digest_characters` | 57 | 2366 | 4894 | 5605 |
| `prompt_characters` | 57 | 4420 | 6949 | 7660 |
| `worker_ocr_pages` | 57 | 0 | 5 | 77 |
| `worker_ocr_passes` | 57 | 0 | 5 | 77 |
| `worker_orientation_passes` | 57 | 0 | 5 | 77 |
| `worker_rendered_pixels` | 57 | 0 | 43516740 | 667903296 |
| `index_units` | 57 | 48 | 371 | 3200 |
| `context_units` | 57 | 19 | 54 | 85 |
| `context_tokens` | 57 | 793 | 1708 | 1756 |

## Extraction time

| Route class | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fast | 20 | 3.8 ms | 16.1 ms | 3.4 ms | 15.5 ms | 13.1 ms | 1.5 ms | 0.00 ms | 0.00 ms |
| layout | 21 | 10.8 ms | 48.8 ms | 10.1 ms | 47.5 ms | 38.8 ms | 6.0 ms | 0.00 ms | 0.00 ms |
| ocr_regions | 1 | 1.66 s | 1.66 s | 1.66 s | 1.66 s | 5.2 ms | 3.2 ms | 51.9 ms | 1.56 s |
| ocr | 15 | 1.91 s | 34.31 s | 1.91 s | 34.30 s | 131.3 ms | 27.5 ms | 19.95 s | 67.15 s |

| Pages | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 19 | 4.5 ms | 1.72 s | 3.6 ms | 1.72 s | 21.2 ms | 0.96 ms | 89.4 ms | 1.60 s |
| 2-4 | 16 | 9.6 ms | 3.23 s | 9.2 ms | 3.23 s | 62.9 ms | 3.2 ms | 459.2 ms | 5.18 s |
| 5-9 | 11 | 10.4 ms | 19.1 ms | 9.9 ms | 18.5 ms | 15.0 ms | 3.2 ms | 0.00 ms | 0.00 ms |
| 10-24 | 9 | 33.4 ms | 12.41 s | 31.9 ms | 12.40 s | 39.8 ms | 6.9 ms | 2.10 s | 23.28 s |
| 25-49 | 1 | 4.42 s | 4.42 s | 4.42 s | 4.42 s | 50.2 ms | 16.8 ms | 542.2 ms | 8.25 s |
| 50-99 | 1 | 34.31 s | 34.31 s | 34.30 s | 34.30 s | 131.3 ms | 27.5 ms | 19.95 s | 67.15 s |

| Kind | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| email | 1 | 9.3 ms | 9.3 ms | 8.8 ms | 8.8 ms | 6.1 ms | 1.0 ms | 0.00 ms | 0.00 ms |
| form | 3 | 1.91 s | 2.52 s | 1.91 s | 2.52 s | 10.5 ms | 0.91 ms | 231.9 ms | 3.09 s |
| invoice | 5 | 659.3 ms | 948.2 ms | 658.9 ms | 947.7 ms | 21.2 ms | 0.52 ms | 0.00 ms | 827.7 ms |
| letter | 22 | 19.1 ms | 12.41 s | 18.5 ms | 12.40 s | 62.9 ms | 5.8 ms | 2.10 s | 23.28 s |
| memo | 6 | 9.6 ms | 4.42 s | 9.2 ms | 4.42 s | 50.2 ms | 16.8 ms | 542.2 ms | 8.25 s |
| minutes | 5 | 13.0 ms | 33.4 ms | 12.4 ms | 31.9 ms | 23.7 ms | 6.9 ms | 0.00 ms | 0.00 ms |
| notice | 11 | 4.0 ms | 16.1 ms | 3.0 ms | 15.5 ms | 13.1 ms | 1.5 ms | 0.00 ms | 0.00 ms |
| receipt | 1 | 719.9 ms | 719.9 ms | 719.5 ms | 719.5 ms | 13.7 ms | 0.07 ms | 0.00 ms | 687.0 ms |
| report | 1 | 4.0 ms | 4.0 ms | 3.4 ms | 3.4 ms | 3.1 ms | 0.00 ms | 0.00 ms | 0.00 ms |
| statement | 2 | 1.8 ms | 1.66 s | 1.3 ms | 1.66 s | 5.2 ms | 3.2 ms | 51.9 ms | 1.56 s |

Over the documents that completed. Wall is the runner's clock around the request; worker is the worker's own total. OCR is summed over the pages, so when the worker reads pages in parallel it can exceed the total. A document's route class is the most expensive route any of its pages took (ocr > ocr_regions > layout > fast), or `unrouted` when the worker sent no layouts.

## Memory

| Process | Typical peak (p50) | Highest peak | During |
| --- | ---: | ---: | ---: |
| Parser worker | 391 MB | 1323 MB | real5-letter-18 |
| Model server | 6083 MB | 6084 MB | real5-office-04 |
| Benchmark (engine) | 24 MB | 24 MB | real5-office-04 |

Resident memory sampled every 25 ms per document; a spike shorter than that can be missed.

## Misses (34)

- **real5-letter-03**: expected `2015-12-16 Warning Letter to Coast to Coast Limited.pdf`, got `2015-12-16 Letter from NEW ZEALAND.pdf` · review: TYPE_MISSING
- **real5-letter-04**: expected `2024-08-28 Safety Recommendation Letter to Federal Motor Carrier Safety Administration.pdf`, got `2024-08-28 Letter to Vinn White.pdf` · trap: party Vinn White (addressee, FMCSA's Deputy Administrator) · review: TYPE_MISSING, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real5-letter-14**: expected `2025-03-03 Letter to European Commission.pdf`, got `2025-03-03 Letter to Directorate General Financial Services.pdf` · review: TYPE_MISSING, LOW_CONFIDENCE
- **real5-letter-15**: expected `2026-04-20 Letter to European Commission.pdf`, got `2026-04-20 Concerns on Israel's registration requirements imposed on NGOs for European Commission.pdf` · review: LOW_CONFIDENCE
- **real5-letter-17**: expected `2017-02-16 Letter to Island Air Charters.pdf`, got `Letter to Island Air Charters.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real5-letter-18**: expected `2021-07-23 Official Information Act Response from Climate Change Commission.pdf`, got `2021-07-23 Tax Invoice from Thought Partners Ltd.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, LOW_CONFIDENCE
- **real5-letter-19**: expected `2024-11-15 Official Information Act Response from Ministry for Regulation.pdf`, got `2024-11-15 Letter to Ministry for Regulation.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED
- **real5-letter-20**: expected `2022-08-26 Official Information Act Response from Ministry of Foreign Affairs and Trade.pdf`, got `2022-08-26 Document.pdf` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED, DESCRIPTION_INVALID, LOW_CONFIDENCE
- **real5-letter-21**: expected `1883-09-20 Letter from Albert E. Schreiber & Co.jpg`, got `Document - Albert E. Schreiber & Co.jpg` · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, PARSER_WARNING, LOW_CONFIDENCE
- **real5-letter-22**: expected `2026-01-19 Email from Neath Port Talbot Council.pdf`, got `2026-01-19 Email - Kaymac Marine & Civil Engineering Ltd.pdf` · trap: party Kaymac Marine & Civil Engineering Ltd (issuer of an attached invoice) · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real5-letter-23**: expected `2026-08-12 Request for No-Action Relief from Electron Exchange DCM, LLC.pdf`, got `2026-08-12 Letter from Commodity Futures Trading Commission.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, LOW_CONFIDENCE
- **real5-notice-02**: expected `2026-05-07 Notice of Intention to Remove Companies From the Register from Khov Jones Limited.pdf`, got `2026-05-07 Notice of Intention to Remove Companies for Kieran Jones.pdf` · trap: party Kieran Jones (joint liquidator, a person) · review: DATE_AMBIGUOUS, PARTY_UNSUPPORTED
- **real5-notice-03**: expected `2026-11-03 Determination of a New Organism from Environmental Protection Authority.pdf`, got `2026-11-03 Document from Environmental Protection Authority.pdf` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED
- **real5-notice-05**: expected `2025-03-03 Public Notice from United States District Court for the Southern District of New York.pdf`, got `2025-03-03 Public Notice for Edward Friedland.pdf` · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real5-notice-06**: expected `2025-04-16 Public Notice from United States District Court for the Northern District of Texas.pdf`, got `2025-04-16 Public Notice for United States District Court Northern District of Texas.pdf` · review: PARTY_UNSUPPORTED
- **real5-invoice-01**: expected `1896-10-20 Bill from Sternberg Brothers.jpg`, got `Document.jpg` · review: TYPE_MISSING, DATE_MISSING, LOW_CONFIDENCE
- **real5-invoice-02**: expected `1887-11-23 Bill from S. F. & A. Rothschild.jpg`, got `Document.jpg` · review: TYPE_MISSING, DATE_MISSING, DESCRIPTION_UNSUPPORTED, DESCRIPTION_INVALID
- **real5-invoice-03**: expected `1885-05-02 Bill from Blun & Co.jpg`, got `Document.jpg` · review: TYPE_MISSING, DATE_MISSING, DESCRIPTION_UNSUPPORTED, DESCRIPTION_INVALID, LOW_CONFIDENCE
- **real5-invoice-04**: expected `1882-03-30 Bill from D. Crehange.jpg`, got `Document between D. CREHANGE and Shipe HWHOLESALE CLOTHIERS.jpg` · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real5-invoice-05**: expected `1891-07-12 Receipt from Rosenthal Bros.jpg`, got `Document from Soyg New York 189.jpg` · review: TYPE_MISSING, DATE_UNSUPPORTED, PARSER_WARNING, LOW_CONFIDENCE
- **real5-invoice-06**: expected `2025-09-09 Tax Invoice from Ian Davies Plant Limited.pdf`, got `2025-09-09 Tax Invoice from Neath Port Talbot County Borough Council.pdf` · trap: party Neath Port Talbot County Borough Council (the customer) · **filed without review**
- **real5-invoice-07**: expected `2025-09-30 Debt Position and Activity Report.pdf`, got `2025-09-30 Activity Report.pdf` · review: PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, LOW_CONFIDENCE
- **real5-form-01**: expected `1990-06-11 Request for Records Disposition Authority from Agricultural Research Service.pdf`, got `1990-06-15 Document - National Archives and Records Service.pdf` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real5-form-02**: expected `1982-03-02 Request for Records Disposition Authority from Internal Revenue Service.pdf`, got `Document between U.S. Department of Treasury and Raymond A. O'BRIEN.pdf` · trap: party Raymond A. O'Brien (person to confer with) · review: TYPE_MISSING, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real5-memo-01**: expected `2025-02-14 Memorandum from National Labor Relations Board.pdf`, got `2025-02-14 General Counsel Memorandum to Regional Directors, Officers-in-Charge, and Resident Officers.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, PARTY_UNSUPPORTED
- **real5-memo-02**: expected `2025-05-16 Memorandum from National Labor Relations Board.pdf`, got `2025-05-16 General Counsel Memorandum to All Regional Directors, Officers-in-Charge, and Resident Officers.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, PARTY_UNSUPPORTED
- **real5-memo-03**: expected `2025-01-29 Memorandum from Office of Management and Budget.pdf`, got `2025-01-29 Memorandum for Heads of Executive Departments and Agencies.pdf` · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real5-memo-04**: expected `2025-04-03 Memorandum from Office of Management and Budget.pdf`, got `2025-04-03 Memorandum from Executive Office of the President.pdf` · review: PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, LOW_CONFIDENCE
- **real5-memo-05**: expected `2025-06-03 Mortgagee Letter from U.S. Department of Housing and Urban Development.pdf`, got `2025-06-03 Mortgagee Letter to All Fha-Approved Mortgagees.pdf` · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real5-memo-06**: expected `2025-06-27 Mortgagee Letter from U.S. Department of Housing and Urban Development.pdf`, got `2025-06-27 Mortgagee Letter to All Fha-Approved Mortgagees.pdf` · review: PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED
- **real5-memo-08**: expected `2025-05-29 Board Meeting Minutes for Federal Retirement Thrift Investment Board.pdf`, got `2025-05-29 Document from Federal Retirement Thrift Investment Board.pdf` · review: TYPE_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, LOW_CONFIDENCE
- **real5-memo-10**: expected `2024-02-14 Meeting Minutes for Visiting Committee on Advanced Technology.pdf`, got `2024-02-14 Minutes from Visiting Committee on Advanced Technology.pdf` · review: LOW_CONFIDENCE
- **real5-office-01**: expected `2018-06-14 Minutes.docx`, got `2018-06-14 Minutes for Phil Brown.docx` · trap: party Phil Brown (chair of the review, a person) · review: PARTY_UNSUPPORTED
- **real5-office-04**: expected `2023-09-30 Allocation, Spend and Commitment Statement.xlsx`, got `2023-09-30 Document from RD&S.xlsx` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED

## How to compare

Keep this run's JSON, make the change, run again, then:

```text
intern-bench compare --before before.json --after after.json --markdown diff.md
```

It recomputes every rate and count over the documents both runs scored, lists each document whose score flipped, and gives the change in p50/p95 of every stage over the documents both completed - between two live runs only, since a replay's timings are its recording's. `intern-bench report --input report.json --markdown report.md` re-renders this page from the JSON.
