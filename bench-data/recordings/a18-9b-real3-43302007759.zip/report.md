# InternBench: live run

- **Run:** 2026-11-12T20:40:25Z · commit `343ee39b8e`
- **Machine:** AMD EPYC 7763 64-Core Processor, 4 logical cores, 15.6 GB RAM, linux (Ubuntu 24.04.5 LTS)
- **Model:** `intern-local` · 5.68 GB · sha256 `03b74727a860`
- **Corpus:** 49 documents · 49 completed · gold `93e10b68ab`
- **Wall time:** 3733.84 s for the whole run, the worker's start included

## Scorecard

| Score | Result |
| --- | ---: |
| Filename (the whole name) | 23/48 (47.9%) |
| Document type | 42/49 (85.7%) |
| Date | 38/48 (79.2%) |
| Date role (when the reviewed date was chosen) | 14/38 (36.8%) |
| Parties | 34/49 (69.4%) |
| Relation word (when parties were named) | 36/43 (83.7%) |
| Party in the right role (when parties were named) | 17/26 (65.4%) |
| Ready / review routing | 8/30 (26.7%) |
| Description states nothing false | 49/49 (100.0%) |
| Description is specific | 39/49 (79.6%) |
| Description specificity | 68.7% (mean of 49) |
| Evidence recall (model's quotes) | 66.0% (mean of 49) |
| Digest recall (facts reaching the digest) | 83.7% (mean of 49) |
| Prompt recall (facts reaching the prompt sent) | 81.6% (mean of 49) |
| Sent to review | 87.8% of 49 completed |

## Phase 3 scorecard

| Figure | Value | Docs |
| --- | ---: | ---: |
| Long-document filename accuracy (10+ pages) | 50.0% | 2 |
| Complex-document filename accuracy | – | 0 |
| Description completeness | – | 0 |
| Unsupported-fact rate (documents) | 79.6% | 49 |
| Review rate | 87.8% | 49 |
| Evidence recall | 66.0% | 49 |
| Total latency p50 | 75.80 s | 49 |
| Total latency p95 | 119.64 s | 49 |
| Generation latency p50 | 18.77 s | 49 |
| Generation latency p95 | 24.14 s | 49 |
| Generated tokens p50 | 92 | 49 |
| Generated tokens p95 | 122 | 49 |
| Prompt tokens p50 | 808 | 49 |

Long: 10 pages or more. Complex: any of `referenced_agreement`, `middle_fact`, `multi_column`, `layout_parties`, `irrelevant_names`, `information_dense`, `stream_order`, `date_in_table`, `key_value`, `complex_pdf`. Unsupported-fact rate: documents with any `*_UNSUPPORTED` review reason. Latency and tokens over the documents that completed.

## Safety

| Check | Count |
| --- | ---: |
| Filed without review under a wrong name | 2 of 48 |
| Trap date chosen | 3 of 49 |
| Forbidden party named | 7 of 49 |
| Spurious parties named | 8 |
| Description states a known-wrong fact | 0 |
| Unsupported description claims | 0 of 116 (0.0%) |
| Right name sent to review anyway | 11 of 25 |
| Sent to review for an unsupported fact | 39 of 49 |

## By kind

| Kind | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| invoice | 5 | 2/5 | 2/5 | 2/5 | 1/4 | 80.0% | 65.61 s | 133.68 s |
| letter | 21 | 10/21 | 18/21 | 15/21 | 2/11 | 95.2% | 78.89 s | 112.72 s |
| notice | 18 | 10/17 | 15/17 | 15/18 | 3/11 | 88.9% | 75.80 s | 119.64 s |
| receipt | 1 | 0/1 | 0/1 | 1/1 | – | 100.0% | 34.30 s | 34.30 s |
| statement | 4 | 1/4 | 3/4 | 1/4 | 2/4 | 50.0% | 63.48 s | 105.29 s |

## By text layer

| Text layer | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| image | 6 | 2/6 | 3/6 | 3/6 | 0/1 | 100.0% | 34.30 s | 77.38 s |
| native | 16 | 10/15 | 14/15 | 13/16 | 4/13 | 81.2% | 82.04 s | 133.68 s |
| office | 14 | 8/14 | 12/14 | 11/14 | 2/8 | 100.0% | 61.19 s | 111.84 s |
| scan | 10 | 2/10 | 6/10 | 5/10 | 2/5 | 80.0% | 93.93 s | 134.45 s |
| text | 3 | 1/3 | 3/3 | 2/3 | 0/3 | 66.7% | 51.43 s | 75.80 s |

## By page count

| Pages | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 21 | 10/21 | 15/21 | 14/21 | 3/12 | 90.5% | 54.08 s | 105.29 s |
| 2-4 | 20 | 11/19 | 17/19 | 15/20 | 3/12 | 85.0% | 75.84 s | 103.64 s |
| 5-9 | 6 | 1/6 | 4/6 | 4/6 | 2/4 | 83.3% | 89.35 s | 134.45 s |
| 10-24 | 2 | 1/2 | 2/2 | 1/2 | 0/2 | 100.0% | 94.13 s | 115.00 s |

## By slice

| Slice | Docs | Filename | Date | Parties | Routing | Unsafe ready | p50 total | p95 total | p50 generation | p95 generation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| long | 2 | 1/2 | 2/2 | 1/2 | 0/2 | 0 of 2 | 94.13 s | 115.00 s | 18.15 s | 22.67 s |

`long`: 10 pages or more. `complex`: any of the categories listed under the phase 3 scorecard. A document may be in both.

## By challenge

| Category | Docs | Filename | Date | Parties | Traps sprung |
| --- | ---: | ---: | ---: | ---: | ---: |
| addressed_to_staff | 1 | 0/1 | 1/1 | 0/1 | 1 |
| agency_billing | 4 | 3/4 | 4/4 | 3/4 | 1 |
| aging_table | 2 | 1/2 | 2/2 | 1/2 | 1 |
| all_caps_parties | 2 | 2/2 | 2/2 | 2/2 | 0 |
| attachment_with_own_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| attachments | 2 | 0/2 | 2/2 | 2/2 | 0 |
| attachments_with_own_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| bcc_distribution_list | 1 | 0/1 | 0/1 | 0/1 | 0 |
| billhead | 2 | 0/2 | 0/2 | 0/2 | 0 |
| blank_date | 2 | 0/2 | 0/2 | 1/2 | 1 |
| body_recounts_events | 7 | 4/6 | 6/6 | 6/7 | 1 |
| born_digital | 14 | 10/13 | 13/13 | 12/14 | 2 |
| brand_vs_legal_name | 4 | 3/4 | 4/4 | 3/4 | 1 |
| caption_court_differs_from_header | 1 | 0/1 | 1/1 | 0/1 | 0 |
| catalogue_date_trap | 1 | 0/1 | 0/1 | 0/1 | 0 |
| cc_above_subject | 1 | 1/1 | 1/1 | 1/1 | 0 |
| cc_list | 1 | 1/1 | 1/1 | 1/1 | 0 |
| circular | 1 | 1/1 | 1/1 | 1/1 | 0 |
| client_in_subject | 1 | 1/1 | 1/1 | 1/1 | 0 |
| coloured_paper | 2 | 0/2 | 0/2 | 0/2 | 1 |
| comparative_period | 1 | 0/1 | 1/1 | 0/1 | 0 |
| competing_dates | 27 | 14/27 | 23/27 | 19/27 | 5 |
| consultation_response | 1 | 0/1 | 1/1 | 1/1 | 0 |
| copies_list | 1 | 0/1 | 1/1 | 0/1 | 1 |
| corrected_firm_name | 1 | 0/1 | 0/1 | 0/1 | 0 |
| corrected_printed_year | 1 | 0/1 | 0/1 | 0/1 | 0 |
| court_filing | 3 | 2/3 | 3/3 | 2/3 | 0 |
| cover_sheet | 2 | 0/2 | 1/2 | 0/2 | 1 |
| csv | 1 | 0/1 | 1/1 | 0/1 | 0 |
| customer_first | 3 | 0/3 | 0/3 | 1/3 | 1 |
| date_at_end | 5 | 2/5 | 4/5 | 4/5 | 0 |
| date_in_caption | 1 | 1/1 | 1/1 | 1/1 | 0 |
| date_missing_from_text_layer | 1 | 0/1 | 0/1 | 1/1 | 0 |
| date_only_in_certificate | 1 | 0/1 | 1/1 | 0/1 | 0 |
| deadline_date | 4 | 3/4 | 4/4 | 3/4 | 1 |
| deadline_in_body | 5 | 1/4 | 2/4 | 4/5 | 3 |
| dear_colleague | 1 | 1/1 | 1/1 | 1/1 | 0 |
| dear_sir_madam | 1 | 0/1 | 1/1 | 1/1 | 0 |
| decision_letter | 1 | 0/1 | 1/1 | 1/1 | 0 |
| decision_numbers_look_like_dates | 1 | 0/1 | 1/1 | 0/1 | 1 |
| direction | 1 | 1/1 | 1/1 | 1/1 | 0 |
| docket_stamp | 1 | 0/1 | 1/1 | 1/1 | 0 |
| ecf_header_text | 1 | 1/1 | 1/1 | 1/1 | 0 |
| effective_date_differs | 1 | 0/1 | 1/1 | 1/1 | 0 |
| email | 2 | 1/2 | 2/2 | 2/2 | 0 |
| email_thread | 1 | 0/1 | 1/1 | 1/1 | 0 |
| enclosures_not_included | 1 | 1/1 | 1/1 | 1/1 | 0 |
| enforcement_notice | 1 | 0/1 | 0/1 | 1/1 | 0 |
| engraved_vignette | 1 | 0/1 | 0/1 | 0/1 | 0 |
| file_number | 1 | 1/1 | 1/1 | 1/1 | 0 |
| filing_stamps | 1 | 1/1 | 1/1 | 1/1 | 0 |
| flight_dates | 2 | 2/2 | 2/2 | 2/2 | 0 |
| foi_response | 2 | 2/2 | 2/2 | 2/2 | 0 |
| footnote_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| form | 2 | 1/2 | 1/2 | 2/2 | 0 |
| government_issuer | 1 | 0/1 | 0/1 | 1/1 | 0 |
| handwritten | 3 | 0/3 | 0/3 | 1/3 | 0 |
| handwritten_date | 1 | 0/1 | 0/1 | 1/1 | 0 |
| header_fields | 1 | 0/1 | 1/1 | 1/1 | 0 |
| hearing_date_in_body | 2 | 0/2 | 1/2 | 2/2 | 1 |
| hidden_sheets | 1 | 0/1 | 0/1 | 1/1 | 1 |
| historic | 4 | 0/4 | 0/4 | 1/4 | 1 |
| historical | 3 | 2/3 | 3/3 | 2/3 | 0 |
| image | 3 | 2/3 | 3/3 | 2/3 | 0 |
| image_only | 2 | 1/2 | 2/2 | 2/2 | 0 |
| image_only_body | 1 | 1/1 | 1/1 | 1/1 | 0 |
| improvement_notice | 1 | 0/1 | 0/1 | 1/1 | 0 |
| inside_address_at_end | 1 | 0/1 | 1/1 | 0/1 | 1 |
| invoice | 5 | 2/5 | 2/5 | 2/5 | 1 |
| iso_dates | 1 | 0/1 | 1/1 | 1/1 | 0 |
| jpeg | 3 | 0/3 | 0/3 | 1/3 | 0 |
| junk_ocr_layer | 1 | 0/1 | 0/1 | 0/1 | 0 |
| legacy_doc | 2 | 2/2 | 2/2 | 2/2 | 0 |
| letter | 21 | 10/21 | 18/21 | 15/21 | 5 |
| letter_format | 2 | 1/2 | 2/2 | 1/2 | 1 |
| letterhead | 2 | 1/2 | 2/2 | 1/2 | 1 |
| letterhead_logo | 1 | 1/1 | 1/1 | 1/1 | 0 |
| line_item_dates | 4 | 3/4 | 4/4 | 3/4 | 1 |
| live_date_field | 1 | 1/1 | 1/1 | 1/1 | 0 |
| local_government | 2 | 1/2 | 1/2 | 2/2 | 1 |
| lockbox | 2 | 2/2 | 2/2 | 2/2 | 0 |
| logo_trap | 1 | 1/1 | 1/1 | 1/1 | 0 |
| long_document | 2 | 1/2 | 2/2 | 1/2 | 0 |
| many_dates | 3 | 2/3 | 3/3 | 2/3 | 1 |
| memo | 1 | 0/1 | 0/1 | 1/1 | 1 |
| metadata_date_trap | 5 | 3/5 | 5/5 | 4/5 | 0 |
| metadata_title_trap | 3 | 2/3 | 3/3 | 2/3 | 1 |
| microfilm_targets | 1 | 0/1 | 0/1 | 0/1 | 0 |
| mislabelled_source | 1 | 1/1 | 1/1 | 1/1 | 0 |
| misleading_metadata | 1 | 0/1 | 1/1 | 1/1 | 0 |
| modern | 4 | 3/4 | 4/4 | 3/4 | 1 |
| msg | 2 | 1/2 | 2/2 | 2/2 | 0 |
| multi_page | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multi_recipient | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multi_round | 1 | 0/1 | 0/1 | 1/1 | 1 |
| multiple_parties_side | 2 | 1/2 | 2/2 | 1/2 | 0 |
| multiple_recipients | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multiple_senders | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multiple_signatories | 1 | 1/1 | 1/1 | 1/1 | 0 |
| named_person_at_org | 9 | 4/9 | 7/9 | 5/9 | 3 |
| network_logo | 1 | 1/1 | 1/1 | 1/1 | 0 |
| no_explicit_title | 2 | 0/2 | 0/2 | 0/2 | 1 |
| no_issuer_in_text | 2 | 0/2 | 1/2 | 0/2 | 0 |
| no_letterhead_on_letter | 1 | 0/1 | 0/1 | 0/1 | 0 |
| no_specific_addressee | 1 | 1/1 | 1/1 | 1/1 | 0 |
| no_title | 1 | 0/1 | 1/1 | 1/1 | 0 |
| no_title_word | 1 | 0/1 | 1/1 | 0/1 | 0 |
| notice | 18 | 10/17 | 15/17 | 15/18 | 3 |
| notice_of_appeal | 1 | 1/1 | 1/1 | 1/1 | 0 |
| notice_of_decision | 2 | 2/2 | 2/2 | 2/2 | 0 |
| notice_of_determination | 1 | 1/1 | 1/1 | 1/1 | 0 |
| notice_of_hearing | 2 | 0/2 | 1/2 | 2/2 | 1 |
| notice_of_removal | 2 | 1/2 | 2/2 | 1/2 | 0 |
| notice_of_violation | 1 | 0/1 | 1/1 | 0/1 | 1 |
| numeric_date | 1 | 0/1 | 0/1 | 0/1 | 1 |
| ocr_layer | 2 | 0/2 | 0/2 | 2/2 | 1 |
| ocr_text_layer | 2 | 0/2 | 1/2 | 1/2 | 1 |
| on_behalf_of_client | 3 | 1/3 | 2/3 | 2/3 | 1 |
| organization_issuer | 1 | 0/1 | 1/1 | 1/1 | 0 |
| penalty_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| pgp_signed | 1 | 0/1 | 1/1 | 1/1 | 0 |
| plain_text | 2 | 1/2 | 2/2 | 2/2 | 0 |
| posted_notice | 2 | 1/2 | 2/2 | 1/2 | 0 |
| print_field_trap | 1 | 0/1 | 0/1 | 0/1 | 0 |
| printed_form | 2 | 0/2 | 0/2 | 1/2 | 1 |
| printer_credit | 1 | 0/1 | 0/1 | 0/1 | 1 |
| public_notice | 4 | 1/3 | 2/3 | 3/4 | 2 |
| publication_number_year_differs | 1 | 1/1 | 1/1 | 1/1 | 0 |
| quoted_third_party | 1 | 0/1 | 1/1 | 1/1 | 0 |
| re_line_references_document | 3 | 1/3 | 2/3 | 1/3 | 1 |
| receipt | 1 | 0/1 | 0/1 | 1/1 | 0 |
| receipted | 3 | 0/3 | 0/3 | 1/3 | 0 |
| recipient_by_domain_only | 1 | 1/1 | 1/1 | 1/1 | 0 |
| redacted_addressee | 2 | 2/2 | 2/2 | 2/2 | 0 |
| redactions | 1 | 0/1 | 1/1 | 0/1 | 1 |
| reference_numbers | 1 | 1/1 | 1/1 | 1/1 | 0 |
| reference_numbers_look_like_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| relative_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| remit_letter | 1 | 0/1 | 1/1 | 0/1 | 1 |
| remit_to | 5 | 3/5 | 4/5 | 3/5 | 2 |
| remit_to_bank | 1 | 1/1 | 1/1 | 1/1 | 0 |
| renamed_firm | 1 | 0/1 | 1/1 | 1/1 | 0 |
| report_parameters | 1 | 1/1 | 1/1 | 1/1 | 0 |
| review | 3 | 0/3 | 1/3 | 1/3 | 1 |
| scanned | 12 | 2/12 | 7/12 | 6/12 | 6 |
| sender_block_above_addressee | 1 | 0/1 | 1/1 | 0/1 | 1 |
| sender_in_signoff_only | 1 | 0/1 | 1/1 | 1/1 | 0 |
| service_period | 2 | 1/2 | 1/2 | 2/2 | 0 |
| signatory_trap | 3 | 1/3 | 3/3 | 1/3 | 1 |
| signatory_vs_org | 1 | 0/1 | 0/1 | 0/1 | 0 |
| signature_on_later_page | 3 | 1/3 | 3/3 | 2/3 | 1 |
| signature_only_no_typed_name | 2 | 2/2 | 2/2 | 2/2 | 0 |
| small_print_date | 1 | 0/1 | 1/1 | 0/1 | 0 |
| spreadsheet | 2 | 0/2 | 0/2 | 1/2 | 1 |
| staff_names | 1 | 1/1 | 1/1 | 1/1 | 0 |
| stamp_date_only | 2 | 0/2 | 0/2 | 2/2 | 1 |
| stamp_dates | 2 | 0/2 | 1/2 | 0/2 | 1 |
| statement | 4 | 1/4 | 3/4 | 1/4 | 1 |
| subject_is_product | 1 | 1/1 | 1/1 | 1/1 | 0 |
| tables | 1 | 0/1 | 1/1 | 0/1 | 0 |
| third_party_named_in_subject | 1 | 0/1 | 1/1 | 0/1 | 1 |
| tiff | 1 | 1/1 | 1/1 | 1/1 | 0 |
| trading_name | 1 | 1/1 | 1/1 | 1/1 | 0 |
| tribunal | 2 | 2/2 | 2/2 | 2/2 | 0 |
| trustee_party | 1 | 1/1 | 1/1 | 1/1 | 0 |
| two_digit_year | 3 | 2/3 | 2/3 | 2/3 | 1 |
| two_letterhead_seals | 1 | 1/1 | 1/1 | 1/1 | 0 |
| two_signatories | 1 | 1/1 | 1/1 | 1/1 | 0 |
| typed | 1 | 0/1 | 0/1 | 0/1 | 1 |
| typist_footer_date | 1 | 0/1 | 1/1 | 0/1 | 1 |
| typo_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| uk | 5 | 3/5 | 4/5 | 4/5 | 0 |
| undated | 1 | – | – | 1/1 | 1 |
| us_state | 5 | 1/4 | 3/4 | 4/5 | 3 |
| utility_commission | 1 | 0/1 | 1/1 | 0/1 | 1 |
| watermark | 1 | 1/1 | 1/1 | 1/1 | 0 |
| wide_image | 1 | 0/1 | 0/1 | 1/1 | 0 |
| windows-1252 | 1 | 0/1 | 1/1 | 0/1 | 0 |
| windows_1252_encoding | 1 | 1/1 | 1/1 | 1/1 | 0 |
| yearless_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| zero_amount | 2 | 1/2 | 2/2 | 1/2 | 1 |

## Routes

- **Pages:** fast 74 · layout 12 · ocr 38
- **Documents by route class:** fast 27 · layout 5 · ocr 17

## Where the time goes

| Stage | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `total_ms` | 49 | 75.80 s | 119.64 s | 134.45 s |
| `extraction_wall_ms` | 49 | 10.9 ms | 7.40 s | 22.31 s |
| `worker_total_ms` | 49 | 10.2 ms | 7.40 s | 22.31 s |
| `worker_snapshot_ms` | 49 | 0.25 ms | 1.5 ms | 3.0 ms |
| `worker_parse_ms` | 49 | 3.6 ms | 32.6 ms | 99.0 ms |
| `worker_analysis_ms` | 49 | 0.19 ms | 1.9 ms | 6.4 ms |
| `worker_render_ms` | 49 | 0.00 ms | 722.4 ms | 3.03 s |
| `worker_image_decode_ms` | 49 | 0.00 ms | 74.8 ms | 1.36 s |
| `worker_ocr_ms` | 49 | 0.00 ms | 13.53 s | 43.26 s |
| `worker_ocr_encode_ms` | 49 | 0.00 ms | 933.6 ms | 2.80 s |
| `worker_ocr_engine_ms` | 49 | 0.00 ms | 12.44 s | 40.11 s |
| `worker_vision_ms` | 49 | 0.00 ms | 20.2 ms | 34.5 ms |
| `analyze_wall_ms` | 49 | 71.92 s | 114.95 s | 133.68 s |
| `distill_ms` | 49 | 2.8 ms | 25.5 ms | 31.0 ms |
| `prompt_ms` | 49 | 0.03 ms | 0.06 ms | 0.09 ms |
| `inference_ms` | 49 | 71.92 s | 114.89 s | 133.66 s |
| `prefill_ms` | 49 | 50.63 s | 92.21 s | 116.86 s |
| `generation_ms` | 49 | 18.77 s | 24.14 s | 34.12 s |
| `validation_ms` | 49 | 5.7 ms | 20.6 ms | 23.3 ms |
| `naming_ms` | 49 | 0.25 ms | 1.9 ms | 3.3 ms |
| `index_ms` | 49 | 2.3 ms | 23.3 ms | 27.1 ms |
| `retrieval_ms` | 49 | 0.04 ms | 1.7 ms | 3.5 ms |

| Measure | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `prefill_tok_per_s` | 49 | 16.0 tok/s | 16.2 tok/s | 16.3 tok/s |
| `generation_tok_per_s` | 49 | 4.9 tok/s | 5.1 tok/s | 5.1 tok/s |
| `prompt_tokens` | 49 | 808 | 1479 | 1881 |
| `cached_tokens` | 49 | 477 | 477 | 477 |
| `generated_tokens` | 49 | 92 | 122 | 171 |
| `estimated_prompt_tokens` | 49 | 1410 | 2220 | 2346 |
| `model_requests` | 49 | 1 | 1 | 1 |
| `redistillations` | 49 | 0 | 0 | 0 |
| `source_characters` | 49 | 3038 | 36778 | 45033 |
| `digest_characters` | 49 | 2436 | 5156 | 5561 |
| `prompt_characters` | 49 | 4485 | 7205 | 7616 |
| `worker_ocr_pages` | 49 | 0 | 4 | 8 |
| `worker_ocr_passes` | 49 | 0 | 4 | 9 |
| `worker_orientation_passes` | 49 | 0 | 4 | 8 |
| `worker_rendered_pixels` | 49 | 0 | 33660000 | 67578072 |
| `index_units` | 49 | 31 | 258 | 464 |
| `context_units` | 49 | 23 | 58 | 88 |
| `context_tokens` | 49 | 822 | 1632 | 1756 |

## Extraction time

| Route class | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fast | 27 | 4.2 ms | 28.7 ms | 3.7 ms | 26.6 ms | 26.3 ms | 1.1 ms | 0.00 ms | 0.00 ms |
| layout | 5 | 8.4 ms | 52.7 ms | 7.8 ms | 50.8 ms | 42.8 ms | 6.4 ms | 0.00 ms | 0.00 ms |
| ocr | 17 | 2.46 s | 22.31 s | 2.46 s | 22.31 s | 32.6 ms | 1.9 ms | 3.03 s | 43.26 s |

| Pages | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 21 | 6.3 ms | 2.41 s | 6.0 ms | 2.41 s | 23.2 ms | 1.3 ms | 133.7 ms | 2.38 s |
| 2-4 | 20 | 7.0 ms | 7.09 s | 6.3 ms | 7.09 s | 32.6 ms | 1.4 ms | 689.5 ms | 13.53 s |
| 5-9 | 6 | 19.4 ms | 22.31 s | 18.8 ms | 22.31 s | 20.9 ms | 1.9 ms | 3.03 s | 43.26 s |
| 10-24 | 2 | 28.7 ms | 52.7 ms | 26.6 ms | 50.8 ms | 42.8 ms | 6.4 ms | 0.00 ms | 0.00 ms |

| Kind | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| invoice | 5 | 466.1 ms | 2.41 s | 465.7 ms | 2.41 s | 21.7 ms | 2.3 ms | 176.0 ms | 2.38 s |
| letter | 21 | 10.9 ms | 7.09 s | 10.2 ms | 7.09 s | 26.3 ms | 1.1 ms | 689.5 ms | 12.21 s |
| notice | 18 | 8.2 ms | 22.31 s | 7.8 ms | 22.31 s | 42.8 ms | 6.4 ms | 3.03 s | 43.26 s |
| receipt | 1 | 1.82 s | 1.82 s | 1.81 s | 1.81 s | 15.9 ms | 0.08 ms | 0.00 ms | 1.77 s |
| statement | 4 | 3.0 ms | 2.31 s | 2.1 ms | 2.31 s | 4.4 ms | 1.4 ms | 133.7 ms | 2.16 s |

Over the documents that completed. Wall is the runner's clock around the request; worker is the worker's own total. OCR is summed over the pages, so when the worker reads pages in parallel it can exceed the total. A document's route class is the most expensive route any of its pages took (ocr > ocr_regions > layout > fast), or `unrouted` when the worker sent no layouts.

## Memory

| Process | Typical peak (p50) | Highest peak | During |
| --- | ---: | ---: | ---: |
| Parser worker | 214 MB | 1315 MB | real3-notice-02 |
| Model server | 6084 MB | 6084 MB | real3-office-15 |
| Benchmark (engine) | 20 MB | 21 MB | real3-office-15 |

Resident memory sampled every 25 ms per document; a spike shorter than that can be missed.

## Misses (25)

- **real3-letter-03**: expected `2023-03-28 Decision Letter to Good Energy.pdf`, got `2023-03-28 This letter sets out the decision to Good Energy Limited.pdf` · **filed without review**
- **real3-letter-06**: expected `1976-11-18 Letter to Los Alamos Scientific Laboratory.pdf`, got `1976-11-18 Document - D.R. Harbur.pdf` · trap: party D.R. Harbur (addressee at LASL) · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED
- **real3-letter-07**: expected `1966-01-04 Letter to U.S. Atomic Energy Commission.pdf`, got `Document.pdf` · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real3-letter-08**: expected `1995-12-07 Decision Letter to Bloom & Kreten.pdf`, got `1995-12-07 Letter from Marybeth Peters.pdf` · trap: party Marybeth Peters (Register of Copyrights who signs) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real3-letter-09**: expected `1992-12-24 Objection Letter to Pilcher and Pilcher.pdf`, got `Letter to Pilcher and Pilcher.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, DATE_UNSUPPORTED, LOW_CONFIDENCE
- **real3-letter-10**: expected `2019-03-28 Response Letter to Transport Scotland.pdf`, got `2019-03-28 Letter to Network Rail Scotland.pdf` · trap: party Network Rail (subject of the letter, not its recipient) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real3-notice-01**: expected `2024-02-19 Improvement Notice for The Chiltern Railway Company Limited.pdf`, got `Improvement Notice for The Chiltern Railway Company Limited.pdf` · review: DATE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real3-notice-02**: expected `2007-04-24 Notice of Public Site Visit and Informational Hearing for City of Victorville.pdf`, got `2007-04-24 Application for Certification for the Victorville for City of Victorville.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED
- **real3-notice-05**: expected `2008-09-22 Notice of Hearing from Mojave Desert Air Quality Management District.pdf`, got `2008-10-27 Notice of Hearing for Mojave Desert Air Quality Management District.pdf` · trap: date 2008-10-27 (date of the public hearing) · review: DATE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real3-notice-07**: expected `2023-04-07 Notice of Violation for PacifiCorp.pdf`, got `2023-04-07 Notice of Violation to Shelley McCoy.pdf` · trap: party Shelley McCoy (PacifiCorp's Director, Regulation, to whom the letter is addressed) · review: PARTY_UNSUPPORTED
- **real3-notice-08**: expected `2018-01-26 Notice of Removal between Olymbec USA LLC and CWFS Insight LLC.pdf`, got `2018-01-26 Notice of Removal for Olymbec USA LLC.pdf` · review: PARTY_UNSUPPORTED
- **real3-notice-13**: expected `1831-11-01 Notice from Parish of Clerkenwell.jpg`, got `1831-11-01 Document.jpg` · review: TYPE_UNSUPPORTED, DATE_IMPLAUSIBLE, PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, DESCRIPTION_INVALID
- **real3-notice-15**: expected `2026-10-14 Errata Notice from The FreeBSD Project.txt`, got `2026-10-14 Errata Notice for FreeBSD Project.txt` · review: PARTY_UNSUPPORTED
- **real3-invoice-05**: expected `2025-12-05 Statement of Account from Lotus Communications Corp.pdf`, got `2025-12-05 Statement of Account from Media Financial Services.pdf` · trap: party Media Financial Services (agency addressed on the statement) · review: PARTY_UNSUPPORTED
- **real3-invoice-09**: expected `1916-11-04 Invoice from Mergenthaler Linotype Co.pdf`, got `INVOICE from Panama City PUB Co.pdf` · trap: party Panama City Pub Co (customer, typed above the issuer) · review: DATE_UNSUPPORTED
- **real3-invoice-11**: expected `1850-07-11 Bill from Henry D. Gray & Son.jpg`, got `Document.jpg` · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real3-invoice-12**: expected `1848-11-14 Bill from Veranda Hotel.jpg`, got `Document.jpg` · review: TYPE_MISSING, DATE_MISSING, DESCRIPTION_INVALID, PARSER_WARNING
- **real3-invoice-15**: expected `1848-07-01 Receipt from Post-Office, Duxbury, Mass.jpg`, got `Document - POST-OFFICE.jpg` · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED, PARSER_WARNING, LOW_CONFIDENCE
- **real3-office-01**: expected `2026-09-14 Consultation Response to London Borough of Islington.docx`, got `2026-09-14 Letter from London Borough of Islington.docx` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING
- **real3-office-02**: expected `2018-11-21 Remit Letter to NHS Pay Review Body.docx`, got `2018-11-21 Letter to Office of Manpower Economics.docx` · trap: party Office of Manpower Economics (secretariat whose address is used) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING
- **real3-office-07**: expected `2020-04-28 Update Letter to Home Affairs Select Committee.odt`, got `2020-04-28 Letter to Home Secretary.odt` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED
- **real3-office-10**: expected `2018-03-21 Email to Royal Borough of Greenwich.msg`, got `2018-03-21 Email from Smith, Greg (GVA).msg` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, LOW_CONFIDENCE
- **real3-office-12**: expected `2012-09-30 Statement of Financial Position from Province of British Columbia.xlsx`, got `Statement of Financial Position.xlsx` · review: DATE_UNSUPPORTED, PARTY_UNSUPPORTED, DESCRIPTION_INVALID, LOW_CONFIDENCE
- **real3-office-13**: expected `2026-08-07 Air Quality Memo to Stoney Wood Property Developments Ltd.xlsx`, got `2025-11-01 Air Quality Memo GLA Consultation to Stoney Wood Property Developments Ltd.xlsx` · trap: date 2025-11-01 (date of the applicant's air quality assessment) · review: PARTY_UNSUPPORTED
- **real3-office-14**: expected `2017-03-31 Condensed Statement of Financial Position from Administrative Tribunals Support Service of Canada.csv`, got `2017-03-31 Condensed Statement of Financial Position unaudited.csv` · **filed without review**

## How to compare

Keep this run's JSON, make the change, run again, then:

```text
intern-bench compare --before before.json --after after.json --markdown diff.md
```

It recomputes every rate and count over the documents both runs scored, lists each document whose score flipped, and gives the change in p50/p95 of every stage over the documents both completed - between two live runs only, since a replay's timings are its recording's. `intern-bench report --input report.json --markdown report.md` re-renders this page from the JSON.
