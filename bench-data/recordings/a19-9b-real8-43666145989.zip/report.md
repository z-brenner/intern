# InternBench: live run

- **Run:** 2026-11-15T02:13:21Z · commit `6e8061fcbf`
- **Machine:** INTEL(R) XEON(R) PLATINUM 8573C, 4 logical cores, 15.6 GB RAM, linux (Ubuntu 24.04.5 LTS)
- **Model:** `intern-local` · 5.68 GB · sha256 `03b74727a860`
- **Corpus:** 55 documents · 55 completed · gold `364923546a`
- **Wall time:** 2789.82 s for the whole run, the worker's start included

## Scorecard

| Score | Result |
| --- | ---: |
| Filename (the whole name) | 16/54 (29.6%) |
| Document type | 43/55 (78.2%) |
| Date | 41/54 (75.9%) |
| Date role (when the reviewed date was chosen) | 22/39 (56.4%) |
| Parties | 40/55 (72.7%) |
| Relation word (when parties were named) | 34/53 (64.1%) |
| Party in the right role (when parties were named) | 31/41 (75.6%) |
| Ready / review routing | 4/23 (17.4%) |
| Description states nothing false | 55/55 (100.0%) |
| Description is specific | 43/55 (78.2%) |
| Description specificity | 66.1% (mean of 55) |
| Evidence recall (model's quotes) | 67.3% (mean of 55) |
| Digest recall (facts reaching the digest) | 76.7% (mean of 55) |
| Prompt recall (facts reaching the prompt sent) | 75.8% (mean of 55) |
| Sent to review | 81.8% of 55 completed |

## Phase 3 scorecard

| Figure | Value | Docs |
| --- | ---: | ---: |
| Long-document filename accuracy (10+ pages) | 50.0% | 2 |
| Complex-document filename accuracy | 0.0% | 1 |
| Description completeness | – | 0 |
| Unsupported-fact rate (documents) | 70.9% | 55 |
| Review rate | 81.8% | 55 |
| Evidence recall | 67.3% | 55 |
| Total latency p50 | 49.34 s | 55 |
| Total latency p95 | 71.00 s | 55 |
| Generation latency p50 | 23.45 s | 55 |
| Generation latency p95 | 32.79 s | 55 |
| Generated tokens p50 | 88 | 55 |
| Generated tokens p95 | 123 | 55 |
| Prompt tokens p50 | 833 | 55 |

Long: 10 pages or more. Complex: any of `referenced_agreement`, `middle_fact`, `multi_column`, `layout_parties`, `irrelevant_names`, `information_dense`, `stream_order`, `date_in_table`, `key_value`, `complex_pdf`. Unsupported-fact rate: documents with any `*_UNSUPPORTED` review reason. Latency and tokens over the documents that completed.

## Safety

| Check | Count |
| --- | ---: |
| Filed without review under a wrong name | 4 of 54 |
| Trap date chosen | 3 of 55 |
| Forbidden party named | 8 of 55 |
| Spurious parties named | 12 |
| Description states a known-wrong fact | 0 |
| Unsupported description claims | 0 of 138 (0.0%) |
| Right name sent to review anyway | 6 of 22 |
| Sent to review for an unsupported fact | 39 of 55 |

## By kind

| Kind | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| contract | 3 | 0/3 | 1/3 | 2/3 | – | 66.7% | 63.30 s | 73.69 s |
| form | 5 | 2/5 | 4/5 | 4/5 | – | 40.0% | 48.69 s | 68.15 s |
| invoice | 6 | 2/6 | 3/6 | 3/6 | 1/2 | 83.3% | 35.85 s | 63.81 s |
| letter | 18 | 3/18 | 13/18 | 12/18 | 0/8 | 100.0% | 49.34 s | 73.73 s |
| memo | 4 | 1/4 | 2/4 | 3/4 | 0/1 | 100.0% | 48.41 s | 60.57 s |
| minutes | 3 | 1/3 | 3/3 | 3/3 | 0/3 | 100.0% | 56.64 s | 57.14 s |
| notice | 12 | 6/11 | 11/11 | 9/12 | 3/9 | 66.7% | 50.90 s | 68.85 s |
| purchase_order | 1 | 0/1 | 1/1 | 1/1 | – | 0.0% | 47.87 s | 47.87 s |
| report | 1 | 1/1 | 1/1 | 1/1 | – | 100.0% | 53.81 s | 53.81 s |
| statement | 2 | 0/2 | 2/2 | 2/2 | – | 100.0% | 37.51 s | 49.90 s |

## By text layer

| Text layer | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| image | 6 | 0/6 | 2/6 | 3/6 | 0/1 | 100.0% | 35.85 s | 38.96 s |
| native | 27 | 12/26 | 23/26 | 22/27 | 3/17 | 77.8% | 49.34 s | 68.85 s |
| office | 3 | 2/3 | 3/3 | 3/3 | 0/1 | 100.0% | 37.51 s | 53.81 s |
| scan | 19 | 2/19 | 13/19 | 12/19 | 1/4 | 79.0% | 55.83 s | 73.69 s |

## By page count

| Pages | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 18 | 4/18 | 13/18 | 11/18 | 2/8 | 83.3% | 38.96 s | 63.81 s |
| 2-4 | 30 | 10/29 | 24/29 | 23/30 | 1/11 | 80.0% | 53.31 s | 73.69 s |
| 5-9 | 5 | 1/5 | 2/5 | 4/5 | 1/2 | 80.0% | 56.22 s | 63.30 s |
| 10-24 | 2 | 1/2 | 2/2 | 2/2 | 0/2 | 100.0% | 46.77 s | 50.70 s |

## By slice

| Slice | Docs | Filename | Date | Parties | Routing | Unsafe ready | p50 total | p95 total | p50 generation | p95 generation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| long | 2 | 1/2 | 2/2 | 2/2 | 0/2 | 0 of 2 | 46.77 s | 50.70 s | 27.66 s | 32.79 s |
| complex | 1 | 0/1 | 0/1 | 1/1 | – | 0 of 1 | 42.86 s | 42.86 s | 21.99 s | 21.99 s |

`long`: 10 pages or more. `complex`: any of the categories listed under the phase 3 scorecard. A document may be in both.

## By challenge

| Category | Docs | Filename | Date | Parties | Traps sprung |
| --- | ---: | ---: | ---: | ---: | ---: |
| abbreviated_issuer | 3 | 1/3 | 3/3 | 2/3 | 1 |
| addressed_to_office_holder | 2 | 0/2 | 1/2 | 2/2 | 0 |
| addressed_to_person | 1 | 1/1 | 1/1 | 1/1 | 0 |
| addressee_at_end | 2 | 0/2 | 1/2 | 1/2 | 1 |
| addressee_is_office_holder | 2 | 2/2 | 2/2 | 2/2 | 0 |
| agencies_named_in_boilerplate | 1 | 1/1 | 1/1 | 1/1 | 0 |
| agency_notice | 3 | 2/3 | 3/3 | 2/3 | 0 |
| ambiguous_numeric_date | 1 | 0/1 | 0/1 | 1/1 | 0 |
| as_of_date | 2 | 0/2 | 2/2 | 2/2 | 0 |
| attachment_with_own_date | 4 | 2/4 | 3/4 | 3/4 | 0 |
| attachments | 6 | 4/6 | 6/6 | 6/6 | 0 |
| attachments_listed | 1 | 0/1 | 1/1 | 1/1 | 0 |
| attendance_list | 2 | 1/2 | 2/2 | 2/2 | 0 |
| australia | 2 | 1/2 | 1/2 | 2/2 | 0 |
| bilingual_letterhead | 2 | 0/2 | 0/2 | 2/2 | 2 |
| billhead | 3 | 0/3 | 0/3 | 1/3 | 0 |
| blank_fields | 2 | 1/2 | 2/2 | 1/2 | 0 |
| board_minutes | 1 | 0/1 | 1/1 | 1/1 | 0 |
| born_digital | 26 | 12/25 | 22/25 | 22/26 | 6 |
| brand_vs_legal_name | 2 | 0/2 | 2/2 | 1/2 | 1 |
| broken_text_layer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| canada | 3 | 1/3 | 1/3 | 3/3 | 1 |
| caption_title | 1 | 1/1 | 1/1 | 1/1 | 0 |
| care_of_address | 1 | 0/1 | 1/1 | 1/1 | 0 |
| catalogue_date_differs | 1 | 0/1 | 0/1 | 1/1 | 0 |
| cc_list | 9 | 2/9 | 6/9 | 6/9 | 2 |
| certificate | 1 | 1/1 | 1/1 | 1/1 | 0 |
| certificate_of_posting | 1 | 0/1 | 1/1 | 1/1 | 0 |
| checkboxes | 1 | 0/1 | 1/1 | 0/1 | 1 |
| class_of_recipients | 4 | 0/3 | 2/3 | 2/4 | 3 |
| company_number | 3 | 1/3 | 3/3 | 3/3 | 0 |
| comparative_period | 1 | 0/1 | 1/1 | 1/1 | 0 |
| competing_dates | 48 | 16/47 | 37/47 | 38/48 | 7 |
| confirmation_date | 2 | 0/2 | 2/2 | 2/2 | 0 |
| contract | 3 | 0/3 | 1/3 | 2/3 | 0 |
| copier_searchable_pdf | 1 | 0/1 | 1/1 | 0/1 | 1 |
| corporate_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| council_minutes | 1 | 1/1 | 1/1 | 1/1 | 0 |
| court_notice | 2 | 1/2 | 2/2 | 1/2 | 1 |
| cover_letter | 1 | 1/1 | 1/1 | 1/1 | 0 |
| cover_page | 1 | 0/1 | 1/1 | 1/1 | 0 |
| customer_first | 6 | 2/6 | 3/6 | 3/6 | 1 |
| date_at_end | 5 | 4/5 | 5/5 | 4/5 | 1 |
| date_at_foot | 3 | 2/3 | 3/3 | 3/3 | 0 |
| date_at_top | 1 | 1/1 | 1/1 | 1/1 | 0 |
| date_in_sentence | 1 | 0/1 | 1/1 | 1/1 | 0 |
| date_in_title | 1 | 0/1 | 1/1 | 0/1 | 1 |
| date_missing_from_text_layer | 1 | 0/1 | 0/1 | 1/1 | 0 |
| date_of_birth | 1 | 0/1 | 0/1 | 1/1 | 0 |
| date_without_year | 4 | 2/4 | 3/4 | 2/4 | 0 |
| dated_line_at_end | 3 | 1/3 | 3/3 | 2/3 | 1 |
| day_first_date | 14 | 5/14 | 12/14 | 12/14 | 4 |
| dd_month_yyyy | 2 | 0/2 | 2/2 | 1/2 | 1 |
| deadline_in_body | 6 | 2/5 | 4/5 | 5/6 | 3 |
| decided_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| docket_number | 1 | 1/1 | 1/1 | 1/1 | 0 |
| docx | 2 | 2/2 | 2/2 | 2/2 | 0 |
| due_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| effective_date_differs | 3 | 2/3 | 3/3 | 2/3 | 1 |
| effective_dates | 4 | 2/3 | 3/3 | 3/4 | 2 |
| election_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| embedded_second_letter | 1 | 0/1 | 0/1 | 0/1 | 0 |
| enclosure | 2 | 1/2 | 2/2 | 2/2 | 0 |
| enclosures | 2 | 0/2 | 2/2 | 1/2 | 0 |
| encrypted_pdf | 1 | 0/1 | 1/1 | 1/1 | 0 |
| engraved_vignette | 1 | 0/1 | 0/1 | 0/1 | 0 |
| eu_agency | 1 | 0/1 | 1/1 | 1/1 | 0 |
| eu_body | 2 | 0/2 | 2/2 | 1/2 | 1 |
| event_date_prominent | 5 | 2/4 | 4/4 | 4/5 | 2 |
| expiry_date | 1 | 0/1 | 0/1 | 1/1 | 0 |
| file_number | 1 | 0/1 | 0/1 | 1/1 | 1 |
| filled_form | 10 | 3/10 | 9/10 | 8/10 | 1 |
| financial_report | 1 | 0/1 | 1/1 | 1/1 | 0 |
| first_name_salutation | 3 | 0/3 | 3/3 | 1/3 | 1 |
| foi_release | 9 | 3/9 | 8/9 | 6/9 | 2 |
| footer_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| footnotes | 5 | 1/5 | 3/5 | 4/5 | 2 |
| form | 7 | 2/7 | 6/7 | 6/7 | 1 |
| form_layout | 3 | 1/3 | 3/3 | 2/3 | 1 |
| form_revision_date | 4 | 1/4 | 4/4 | 3/4 | 1 |
| government_form | 6 | 2/6 | 5/6 | 5/6 | 1 |
| government_sender | 2 | 0/2 | 0/2 | 1/2 | 1 |
| handwritten | 2 | 0/2 | 0/2 | 0/2 | 0 |
| handwritten_annotation | 1 | 0/1 | 0/1 | 0/1 | 0 |
| handwritten_annotations | 4 | 1/4 | 2/4 | 2/4 | 1 |
| handwritten_date | 4 | 0/4 | 1/4 | 2/4 | 1 |
| handwritten_dates | 2 | 0/2 | 1/2 | 2/2 | 0 |
| handwritten_signature | 7 | 1/7 | 4/7 | 5/7 | 2 |
| hearing_date | 4 | 1/3 | 3/3 | 2/4 | 2 |
| hearing_notice | 3 | 0/2 | 2/2 | 1/3 | 2 |
| historic | 10 | 1/10 | 4/10 | 5/10 | 0 |
| historical | 1 | 0/1 | 1/1 | 0/1 | 0 |
| image | 6 | 0/6 | 2/6 | 3/6 | 0 |
| image_only | 10 | 2/10 | 9/10 | 6/10 | 1 |
| india | 1 | 0/1 | 0/1 | 1/1 | 1 |
| instructions_in_cells | 1 | 0/1 | 1/1 | 1/1 | 0 |
| internal_correspondence | 1 | 0/1 | 1/1 | 0/1 | 0 |
| invoice | 6 | 2/6 | 3/6 | 3/6 | 1 |
| invoice_number_looks_like_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| ireland | 1 | 0/1 | 1/1 | 0/1 | 1 |
| irregular_spacing | 2 | 0/2 | 1/2 | 2/2 | 0 |
| issuer_in_logo | 4 | 1/4 | 4/4 | 3/4 | 1 |
| issuer_in_signature_block | 2 | 0/2 | 1/2 | 2/2 | 0 |
| issuer_named_in_customer_block | 1 | 0/1 | 1/1 | 0/1 | 1 |
| issuer_not_named | 3 | 1/3 | 2/3 | 2/3 | 1 |
| jpeg | 6 | 0/6 | 2/6 | 3/6 | 0 |
| lease | 1 | 0/1 | 1/1 | 1/1 | 0 |
| letter | 18 | 3/18 | 13/18 | 12/18 | 4 |
| letter_format | 2 | 1/2 | 2/2 | 1/2 | 1 |
| letter_from_company | 1 | 0/1 | 1/1 | 1/1 | 0 |
| letter_from_nonprofit | 1 | 0/1 | 0/1 | 1/1 | 0 |
| letterhead | 9 | 1/9 | 6/9 | 4/9 | 2 |
| letterhead_image_only | 3 | 1/3 | 2/3 | 3/3 | 1 |
| letterhead_logo | 10 | 3/9 | 8/9 | 7/10 | 4 |
| letterhead_logo_only | 1 | 1/1 | 1/1 | 1/1 | 0 |
| licence | 1 | 0/1 | 0/1 | 1/1 | 0 |
| line_item_dates | 3 | 1/3 | 1/3 | 2/3 | 0 |
| live_date_field | 1 | 1/1 | 1/1 | 1/1 | 0 |
| local_government | 2 | 1/2 | 2/2 | 2/2 | 0 |
| logo | 2 | 2/2 | 2/2 | 2/2 | 0 |
| long_document | 1 | 0/1 | 1/1 | 1/1 | 0 |
| long_letter | 1 | 1/1 | 1/1 | 1/1 | 0 |
| many_companies_named | 2 | 1/2 | 2/2 | 2/2 | 0 |
| many_dates | 8 | 3/7 | 5/7 | 8/8 | 2 |
| many_named_organisations | 6 | 1/6 | 2/6 | 4/6 | 1 |
| memo | 4 | 1/4 | 2/4 | 3/4 | 2 |
| memo_header | 2 | 1/2 | 2/2 | 1/2 | 1 |
| memorandum | 4 | 1/4 | 2/4 | 3/4 | 2 |
| memorandum_of_understanding | 1 | 0/1 | 0/1 | 1/1 | 0 |
| metadata_date_trap | 34 | 11/33 | 26/33 | 26/34 | 8 |
| metadata_party_trap | 2 | 1/2 | 2/2 | 2/2 | 0 |
| metadata_title_trap | 1 | 1/1 | 1/1 | 1/1 | 0 |
| minutes | 3 | 1/3 | 3/3 | 3/3 | 0 |
| mixed_scan_and_digital | 1 | 1/1 | 1/1 | 1/1 | 0 |
| modern | 44 | 15/43 | 36/43 | 35/44 | 11 |
| month_only_date | 1 | 0/1 | 1/1 | 1/1 | 0 |
| month_only_references | 1 | 0/1 | 1/1 | 1/1 | 0 |
| multiple_letters | 1 | 0/1 | 0/1 | 0/1 | 0 |
| multiple_parties | 2 | 1/2 | 2/2 | 1/2 | 0 |
| multiple_sheets | 1 | 0/1 | 1/1 | 1/1 | 0 |
| multiple_signers | 1 | 0/1 | 1/1 | 1/1 | 0 |
| municipal | 1 | 1/1 | 1/1 | 1/1 | 0 |
| name_printed_two_ways | 2 | 2/2 | 2/2 | 2/2 | 0 |
| name_variant | 1 | 1/1 | 1/1 | 1/1 | 0 |
| named_officials | 13 | 5/13 | 11/13 | 8/13 | 4 |
| named_person_at_org | 13 | 3/13 | 10/13 | 8/13 | 3 |
| new_zealand | 9 | 2/9 | 3/9 | 5/9 | 1 |
| no_addressee_block | 1 | 0/1 | 1/1 | 0/1 | 1 |
| no_dated_line | 2 | 0/1 | 1/1 | 2/2 | 1 |
| no_document_date | 1 | – | – | 1/1 | 1 |
| no_explicit_addressee | 3 | 1/3 | 3/3 | 3/3 | 0 |
| no_issuer_name_in_header | 1 | 0/1 | 0/1 | 1/1 | 0 |
| no_issuer_printed | 2 | 0/2 | 1/2 | 1/2 | 1 |
| no_letterhead | 3 | 0/3 | 2/3 | 2/3 | 1 |
| no_salutation | 1 | 0/1 | 1/1 | 1/1 | 0 |
| no_signatory | 2 | 1/2 | 1/2 | 2/2 | 0 |
| no_signature | 2 | 0/2 | 2/2 | 1/2 | 0 |
| no_specific_addressee | 1 | 0/1 | 0/1 | 1/1 | 0 |
| no_text_layer | 8 | 2/8 | 7/8 | 5/8 | 1 |
| noisy_ocr_layer | 3 | 0/3 | 0/3 | 2/3 | 1 |
| nonprofit | 1 | 0/1 | 0/1 | 1/1 | 0 |
| notice | 12 | 6/11 | 11/11 | 9/12 | 3 |
| notice_of_meeting | 2 | 1/2 | 2/2 | 2/2 | 0 |
| number_looks_like_date | 2 | 0/2 | 1/2 | 1/2 | 2 |
| numeric_date | 6 | 2/5 | 4/5 | 6/6 | 2 |
| ocr_text_layer | 11 | 0/11 | 6/11 | 7/11 | 3 |
| office | 3 | 2/3 | 3/3 | 3/3 | 0 |
| office_memorandum | 1 | 0/1 | 0/1 | 1/1 | 1 |
| opinion_letter | 2 | 1/2 | 2/2 | 1/2 | 0 |
| parent_company_mention | 1 | 0/1 | 1/1 | 1/1 | 0 |
| partly_printed_date_line | 4 | 0/4 | 1/4 | 2/4 | 1 |
| partly_printed_year | 1 | 0/1 | 0/1 | 0/1 | 0 |
| payment_advice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| person_party | 2 | 0/2 | 0/2 | 2/2 | 0 |
| personal_sender_on_letterhead | 2 | 0/2 | 1/2 | 1/2 | 0 |
| placeholder_data | 1 | 0/1 | 1/1 | 1/1 | 0 |
| placeholders | 3 | 2/3 | 3/3 | 3/3 | 0 |
| printed_form | 4 | 0/4 | 3/4 | 3/4 | 1 |
| printer_credit | 1 | 0/1 | 0/1 | 1/1 | 0 |
| public_notice | 5 | 2/4 | 4/4 | 4/5 | 2 |
| purchase_order | 1 | 0/1 | 1/1 | 1/1 | 0 |
| quoted_message | 1 | 0/1 | 1/1 | 1/1 | 0 |
| rasterized_born_digital | 1 | 0/1 | 1/1 | 1/1 | 0 |
| receipted | 1 | 0/1 | 0/1 | 0/1 | 0 |
| received_stamp | 3 | 1/3 | 3/3 | 3/3 | 0 |
| redacted | 2 | 1/2 | 2/2 | 2/2 | 0 |
| redacted_signer | 1 | 0/1 | 1/1 | 1/1 | 0 |
| redactions | 6 | 1/6 | 5/6 | 4/6 | 2 |
| reference_number | 16 | 4/16 | 12/16 | 14/16 | 4 |
| referenced_agreement | 1 | 0/1 | 0/1 | 1/1 | 0 |
| referenced_dates | 23 | 6/23 | 16/23 | 18/23 | 3 |
| regulator | 1 | 0/1 | 0/1 | 1/1 | 1 |
| remittance_slip | 1 | 1/1 | 1/1 | 1/1 | 0 |
| report | 1 | 1/1 | 1/1 | 1/1 | 0 |
| revenue_stamp | 1 | 0/1 | 0/1 | 0/1 | 0 |
| running_header | 5 | 2/5 | 4/5 | 3/5 | 0 |
| scanned | 18 | 2/18 | 12/18 | 11/18 | 4 |
| seal_date | 1 | 0/1 | 1/1 | 1/1 | 0 |
| senate_minutes | 1 | 0/1 | 1/1 | 1/1 | 0 |
| sender_at_end | 1 | 0/1 | 1/1 | 1/1 | 0 |
| sender_block_is_person | 2 | 0/2 | 2/2 | 1/2 | 1 |
| service_period | 5 | 3/5 | 5/5 | 4/5 | 1 |
| short | 12 | 3/12 | 11/12 | 9/12 | 3 |
| signatory_trap | 13 | 2/13 | 9/13 | 8/13 | 3 |
| signatory_vs_org | 18 | 4/18 | 14/18 | 12/18 | 3 |
| signature_date | 2 | 0/2 | 2/2 | 2/2 | 0 |
| signature_dates | 1 | 0/1 | 0/1 | 1/1 | 0 |
| signature_image | 5 | 0/5 | 5/5 | 1/5 | 4 |
| signature_on_later_page | 7 | 1/7 | 4/7 | 3/7 | 2 |
| signature_scan | 3 | 0/3 | 2/3 | 3/3 | 0 |
| signed_for | 1 | 0/1 | 0/1 | 1/1 | 0 |
| sister_company_named | 1 | 0/1 | 0/1 | 0/1 | 0 |
| small_print | 1 | 0/1 | 1/1 | 0/1 | 1 |
| source_title_mismatch | 3 | 0/3 | 2/3 | 3/3 | 0 |
| spreadsheet | 1 | 0/1 | 1/1 | 1/1 | 0 |
| staff_names | 15 | 6/15 | 14/15 | 14/15 | 1 |
| stamp | 1 | 0/1 | 0/1 | 1/1 | 0 |
| stamp_date | 6 | 1/6 | 4/6 | 4/6 | 1 |
| stamped_date | 6 | 0/6 | 3/6 | 4/6 | 1 |
| statement | 2 | 0/2 | 2/2 | 2/2 | 0 |
| statutory_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| subject_is_product | 1 | 0/1 | 1/1 | 0/1 | 1 |
| successor_name | 1 | 0/1 | 1/1 | 1/1 | 0 |
| system_generated | 1 | 1/1 | 1/1 | 1/1 | 0 |
| table_layout | 1 | 0/1 | 1/1 | 0/1 | 1 |
| tables | 7 | 2/6 | 6/6 | 5/7 | 3 |
| tax_invoice | 2 | 2/2 | 2/2 | 2/2 | 0 |
| text_date_cell | 1 | 0/1 | 1/1 | 1/1 | 0 |
| third_party_named_in_body | 8 | 2/8 | 4/8 | 6/8 | 2 |
| trading_name | 1 | 0/1 | 1/1 | 1/1 | 0 |
| transmittal_letter | 2 | 0/2 | 2/2 | 2/2 | 0 |
| two_addressees | 2 | 1/2 | 2/2 | 2/2 | 0 |
| two_digit_year | 10 | 4/9 | 7/9 | 8/10 | 2 |
| two_senders | 2 | 1/2 | 1/2 | 1/2 | 1 |
| type_in_subject_line | 2 | 0/2 | 1/2 | 2/2 | 0 |
| type_not_printed | 3 | 1/3 | 3/3 | 3/3 | 0 |
| typewritten | 9 | 1/9 | 5/9 | 5/9 | 0 |
| uk | 8 | 4/8 | 8/8 | 7/8 | 1 |
| uk_regulator | 1 | 1/1 | 1/1 | 1/1 | 0 |
| university | 2 | 0/2 | 1/2 | 1/2 | 0 |
| us_date_format | 6 | 2/6 | 5/6 | 5/6 | 1 |
| us_federal | 14 | 3/14 | 11/14 | 10/14 | 1 |
| us_local | 7 | 3/6 | 6/6 | 6/7 | 2 |
| us_state | 7 | 2/7 | 7/7 | 4/7 | 2 |
| warn_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| watermark | 1 | 1/1 | 1/1 | 1/1 | 0 |
| wide_image | 1 | 0/1 | 0/1 | 1/1 | 0 |
| xlsx | 1 | 0/1 | 1/1 | 1/1 | 0 |

## Routes

- **Pages:** fast 79 · layout 23 · ocr 42 · ocr_regions 7
- **Documents by route class:** fast 18 · layout 13 · ocr 20 · ocr_regions 4

## Where the time goes

| Stage | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `total_ms` | 55 | 49.34 s | 71.00 s | 73.73 s |
| `extraction_wall_ms` | 55 | 20.6 ms | 7.98 s | 12.61 s |
| `worker_total_ms` | 55 | 19.8 ms | 7.98 s | 12.61 s |
| `worker_snapshot_ms` | 55 | 0.31 ms | 0.76 ms | 5.9 ms |
| `worker_parse_ms` | 55 | 5.6 ms | 27.5 ms | 2.22 s |
| `worker_analysis_ms` | 55 | 0.65 ms | 3.0 ms | 19.5 ms |
| `worker_render_ms` | 55 | 0.00 ms | 788.6 ms | 915.0 ms |
| `worker_image_decode_ms` | 55 | 0.00 ms | 15.8 ms | 35.1 ms |
| `worker_ocr_ms` | 55 | 0.00 ms | 14.64 s | 24.28 s |
| `worker_ocr_encode_ms` | 55 | 0.00 ms | 937.3 ms | 1.50 s |
| `worker_ocr_engine_ms` | 55 | 0.00 ms | 13.28 s | 22.51 s |
| `worker_vision_ms` | 55 | 0.00 ms | 4.8 ms | 10.2 ms |
| `analyze_wall_ms` | 55 | 48.41 s | 67.67 s | 73.72 s |
| `distill_ms` | 55 | 2.5 ms | 12.5 ms | 17.8 ms |
| `prompt_ms` | 55 | 0.04 ms | 0.05 ms | 0.06 ms |
| `inference_ms` | 55 | 48.40 s | 67.66 s | 73.70 s |
| `prefill_ms` | 55 | 24.42 s | 40.41 s | 44.52 s |
| `generation_ms` | 55 | 23.45 s | 32.79 s | 37.13 s |
| `validation_ms` | 55 | 5.0 ms | 10.5 ms | 17.2 ms |
| `naming_ms` | 55 | 0.27 ms | 1.4 ms | 2.5 ms |
| `index_ms` | 55 | 2.3 ms | 11.2 ms | 16.2 ms |
| `retrieval_ms` | 55 | 0.05 ms | 1.2 ms | 1.4 ms |

| Measure | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `prefill_tok_per_s` | 55 | 34.6 tok/s | 36.1 tok/s | 36.5 tok/s |
| `generation_tok_per_s` | 55 | 3.8 tok/s | 3.8 tok/s | 3.8 tok/s |
| `prompt_tokens` | 55 | 833 | 1418 | 1524 |
| `cached_tokens` | 55 | 477 | 477 | 477 |
| `generated_tokens` | 55 | 88 | 123 | 136 |
| `estimated_prompt_tokens` | 55 | 1388 | 2099 | 2173 |
| `model_requests` | 55 | 1 | 1 | 1 |
| `redistillations` | 55 | 0 | 0 | 0 |
| `source_characters` | 55 | 3553 | 21976 | 33310 |
| `digest_characters` | 55 | 2295 | 4843 | 5253 |
| `prompt_characters` | 55 | 4349 | 6892 | 7302 |
| `worker_ocr_pages` | 55 | 0 | 3 | 6 |
| `worker_ocr_passes` | 55 | 0 | 3 | 6 |
| `worker_orientation_passes` | 55 | 0 | 3 | 6 |
| `worker_rendered_pixels` | 55 | 0 | 26106960 | 52213920 |
| `index_units` | 55 | 34 | 165 | 223 |
| `context_units` | 55 | 24 | 57 | 62 |
| `context_tokens` | 55 | 800 | 1511 | 1585 |

## Extraction time

| Route class | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fast | 18 | 5.9 ms | 21.9 ms | 5.5 ms | 21.4 ms | 19.3 ms | 3.0 ms | 0.00 ms | 0.00 ms |
| layout | 13 | 7.9 ms | 2.23 s | 7.2 ms | 2.23 s | 2.22 s | 5.5 ms | 0.00 ms | 0.00 ms |
| ocr_regions | 4 | 1.04 s | 3.72 s | 1.04 s | 3.72 s | 16.9 ms | 3.0 ms | 471.6 ms | 6.36 s |
| ocr | 20 | 3.16 s | 9.14 s | 3.16 s | 9.14 s | 27.5 ms | 3.0 ms | 888.2 ms | 17.66 s |

| Pages | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 18 | 12.1 ms | 2.56 s | 11.6 ms | 2.56 s | 14.4 ms | 0.90 ms | 101.7 ms | 2.45 s |
| 2-4 | 30 | 8.8 ms | 7.28 s | 8.3 ms | 7.28 s | 19.3 ms | 2.5 ms | 471.6 ms | 13.78 s |
| 5-9 | 5 | 7.39 s | 12.61 s | 7.38 s | 12.61 s | 27.9 ms | 19.5 ms | 915.0 ms | 24.28 s |
| 10-24 | 2 | 21.8 ms | 2.23 s | 20.8 ms | 2.23 s | 2.22 s | 5.5 ms | 0.00 ms | 0.00 ms |

| Kind | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| contract | 3 | 7.28 s | 12.61 s | 7.28 s | 12.61 s | 16.9 ms | 3.0 ms | 888.2 ms | 24.28 s |
| form | 5 | 1.10 s | 9.14 s | 1.10 s | 9.14 s | 27.5 ms | 3.0 ms | 426.1 ms | 17.66 s |
| invoice | 6 | 917.2 ms | 2.56 s | 916.5 ms | 2.56 s | 11.5 ms | 0.68 ms | 97.4 ms | 2.45 s |
| letter | 18 | 12.1 ms | 4.78 s | 11.6 ms | 4.78 s | 2.22 s | 5.5 ms | 680.8 ms | 8.43 s |
| memo | 4 | 8.6 ms | 10.9 ms | 8.2 ms | 10.3 ms | 8.2 ms | 0.90 ms | 0.00 ms | 0.00 ms |
| minutes | 3 | 21.9 ms | 7.98 s | 21.4 ms | 7.98 s | 19.3 ms | 1.3 ms | 788.6 ms | 14.64 s |
| notice | 12 | 8.8 ms | 7.39 s | 8.3 ms | 7.38 s | 27.9 ms | 19.5 ms | 915.0 ms | 9.93 s |
| purchase_order | 1 | 2.51 s | 2.51 s | 2.51 s | 2.51 s | 0.33 ms | 0.45 ms | 101.7 ms | 2.40 s |
| report | 1 | 4.1 ms | 4.1 ms | 3.5 ms | 3.5 ms | 3.2 ms | 0.00 ms | 0.00 ms | 0.00 ms |
| statement | 2 | 2.5 ms | 3.20 s | 1.6 ms | 3.20 s | 1.3 ms | 0.45 ms | 290.7 ms | 5.54 s |

Over the documents that completed. Wall is the runner's clock around the request; worker is the worker's own total. OCR is summed over the pages, so when the worker reads pages in parallel it can exceed the total. A document's route class is the most expensive route any of its pages took (ocr > ocr_regions > layout > fast), or `unrouted` when the worker sent no layouts.

## Memory

| Process | Typical peak (p50) | Highest peak | During |
| --- | ---: | ---: | ---: |
| Parser worker | 492 MB | 1425 MB | real8-contract-02 |
| Model server | 6082 MB | 6084 MB | real8-minutes-03 |
| Benchmark (engine) | 16 MB | 20 MB | real8-minutes-03 |

Resident memory sampled every 25 ms per document; a spike shorter than that can be missed.

## Misses (38)

- **real8-letter-02**: expected `2008-09-08 Letter from Government Accountability Office.pdf`, got `2008-09-08 Document from United States Government Accountability Office.pdf` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real8-letter-03**: expected `2018-10-02 Letter from Irish Fiscal Advisory Council.pdf`, got `2018-10-02 Letter to Secretary General Moran.pdf` · trap: party Secretary General Moran (addressee, the Department's Secretary General, named only by title and surname) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, LOW_CONFIDENCE
- **real8-letter-04**: expected `2025-10-20 Decision Letter to Trans-Northern Pipelines Inc.pdf`, got `2025-06-20 Letter from Canada Energy Regulator.pdf` · trap: date 2025-06-20 (date of the company's application, printed in the heading and in the PDF's metadata title) · review: TYPE_INFERRED, TYPE_UNSUPPORTED, TYPE_MISSING, PARTY_UNSUPPORTED
- **real8-letter-05**: expected `2019-10-25 Letter from Copper Market, Inc.pdf`, got `2019-10-25 summary from Copper Market, Inc.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, PARTY_UNSUPPORTED
- **real8-letter-07**: expected `2025-11-26 Letter from Office for Budget Responsibility.pdf`, got `2025-11-26 Letter from Richard Hughes.pdf` · trap: party Richard Hughes (Chair of the OBR, who signs and whose name heads the sender's block) · review: TYPE_MISSING, PARTY_UNSUPPORTED
- **real8-letter-09**: expected `2024-10-15 Letter to UnitedHealth Group.pdf`, got `2024-10-15 Letter to Ron Wyden.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED
- **real8-letter-10**: expected `2024-02-16 Letter from Federation of South Toronto Residents' Associations.pdf`, got `Letter to Toronto City Council Members.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, DATE_UNSUPPORTED
- **real8-letter-11**: expected `2024-12-02 Official Information Act Response from Ministry of Social Development.pdf`, got `2024-12-02 Document from Ministry of Social Development.pdf` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real8-letter-12**: expected `1935-05-09 Letter from Senate Committee on Banking and Currency.pdf`, got `1935-05-02 Document.pdf` · review: TYPE_UNSUPPORTED, DATE_AMBIGUOUS, PARTY_MISSING, DESCRIPTION_INVALID
- **real8-letter-13**: expected `1988-09-14 Letter to State Law Enforcement Division.pdf`, got `1988-09-14 Letter.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, DESCRIPTION_INVALID, LOW_CONFIDENCE
- **real8-letter-14**: expected `2024-12-10 Letter from European Banking Authority.pdf`, got `2024-12-10 Letter to Directorate-General for Financial Stability.pdf` · review: TYPE_MISSING, LOW_CONFIDENCE
- **real8-letter-15**: expected `2024-05-30 Letter from Premier of Tasmania.pdf`, got `Letter from Productivity Commission.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, DATE_UNSUPPORTED, DESCRIPTION_UNSUPPORTED
- **real8-letter-16**: expected `2024-06-10 Letter from Prime Minister.pdf`, got `Letter from Heather Baggott.pdf` · trap: party Heather Baggott (addressee, the Acting Public Service Commissioner) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, DATE_UNSUPPORTED, LOW_CONFIDENCE
- **real8-letter-17**: expected `2018-11-30 Letter from United States Trade Representative.pdf`, got `2018-11-30 Letter of Confirmation to Government of the United Mexican States.pdf` · review: PARTY_UNSUPPORTED
- **real8-letter-18**: expected `1958-11-21 Letter from United States Information Agency.pdf`, got `1958-11-21 Letter to Chris Abbott.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED
- **real8-notice-02**: expected `2025-09-19 Notice to the Bar from New Jersey Supreme Court.pdf`, got `2025-09-19 Notice to the Bar for New Jersey Lawyers' Fund for Client Protection.pdf` · trap: party New Jersey Lawyers' Fund for Client Protection (fund that took part in the study and takes questions; not the issuer) · review: PARTY_UNSUPPORTED
- **real8-notice-03**: expected `2026-07-01 Notice of Proposed Service Charge Increase & Public Hearing.pdf`, got `2026-07-01 Notice to Property Owner.pdf` · trap: party Property Owner (class of recipients in the salutation) · review: TYPE_INFERRED, TYPE_MISSING, LOW_CONFIDENCE
- **real8-notice-07**: expected `1944-02-28 Notice of Hearing between Mary Halpin and Southern N. E. Telephone Co.jpg`, got `1944-02-28 Notice for Southern N. E. Telephone Co.jpg` · review: TYPE_MISSING, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real8-notice-09**: expected `2026-06-17 Notice of Regular Meeting from Liberty County Commissioners Court.pdf`, got `2026-06-17 Notice of Regular Meeting of Liberty County, Texas Commissioners Court.pdf` · **filed without review**
- **real8-notice-12**: expected `1942-12-30 Notice from U.S. Navy Yard, Portsmouth, N.H.jpg`, got `1942-12-30 Cabrilla in Record from U. S. Navy Yard Portsmouth, N.H.jpg` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real8-invoice-01**: expected `2025-03-31 Invoice from AMP SA.pdf`, got `2025-03-31 Invoice from CESE Comit Economique et Social Europen.pdf` · trap: party CESE (the customer's French abbreviation) · review: DESCRIPTION_INVALID, LOW_CONFIDENCE
- **real8-invoice-04**: expected `1875-11-26 Invoice from William Mill.jpg`, got `Document - Wildeam Mftele.jpg` · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, PARSER_WARNING, LOW_CONFIDENCE
- **real8-invoice-05**: expected `1886-07-01 Invoice from Arthur Briscoe & Co.jpg`, got `Invoice from Han Dann.jpg` · review: DATE_UNSUPPORTED, PARTY_UNSUPPORTED, DESCRIPTION_INVALID, PARSER_WARNING, LOW_CONFIDENCE
- **real8-invoice-06**: expected `1960-04-27 Invoice from Purser's Ltd.jpg`, got `Document - PURSER'S LTD.jpg` · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real8-purchase_order-01**: expected `2024-04-29 Order Form to Partner Press.pdf`, got `2024-04-29 Order Form for Partner Press.pdf` · **filed without review**
- **real8-statement-01**: expected `2025-05-15 Bank Reconciliation from Bridgerule Parish Council.xlsx`, got `2025-03-31 Document - Bridgerule Parish Council.xlsx` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED
- **real8-statement-02**: expected `2025-03-31 Micro-entity Accounts from The British Open Brass Band Championship Limited.pdf`, got `2025-03-31 Document from The British Open Brass Band Championship Limited.pdf` · review: TYPE_UNSUPPORTED
- **real8-form-01**: expected `2018-02-28 Striking Off Application from Marine and General Mutual Life Assurance Society.pdf`, got `2018-03-31 Off Application for Marine and General Mutual Life Assurance Society.pdf` · **filed without review**
- **real8-form-03**: expected `1936-10-20 Private Pilot's Licence for Alfred Rose.jpg`, got `Licence I. Licence with Controller of Civil Aviation.jpg` · review: DATE_UNSUPPORTED, PARTY_UNSUPPORTED, PARTY_MISSING, LOW_CONFIDENCE
- **real8-form-04**: expected `2010-01-15 Proposal to Lease Space from Ryan Companies US, Inc.pdf`, got `2010-01-15 Proposal to Lease Space between Ryan Companles US, Inc and John Strittmatter.pdf` · trap: party John Strittmatter (the offeror's vice president, who signs) · review: DESCRIPTION_UNSUPPORTED
- **real8-contract-01**: expected `2006-12-20 Lease between 2200 C Street, LLC and United States of America.pdf`, got `2006-12-20 Administration Lease for Real Property between C Street, LLC and United States of America.pdf` · **filed without review**
- **real8-contract-02**: expected `2019-12-13 Memorandum of Understanding with Auckland University Students' Association Incorporated.pdf`, got `Memorandum of Understanding to Auckland University Students' Association Incorporated.pdf` · review: DATE_UNSUPPORTED, PARTY_UNSUPPORTED
- **real8-contract-03**: expected `2014-03-11 Memorandum of Understanding between Mule Deer Foundation and USDA Forest Service.pdf`, got `Memorandum of Understanding to Mule Deer Foundation.pdf` · review: DATE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real8-memo-02**: expected `2026-07-31 Highway Design Memorandum from Kentucky Transportation Cabinet.pdf`, got `2026-07-31 Highway Design Memorandum to Chief District Engineers.pdf` · trap: party Chief District Engineers (class of recipients in the To line) · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real8-memo-03**: expected `2026-01-19 Office Memorandum from Central Bureau of Communication.pdf`, got `2025-12-22 Office Memorandum to Central Bureau of Communication.pdf` · trap: date 2025-12-22 (date of the Bureau's earlier Office Memorandum on the same subject) · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real8-memo-04**: expected `1941-12-24 Memorandum from Railroad Retirement Board.pdf`, got `Document - The General Counsel.pdf` · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED, PARTY_UNSUPPORTED
- **real8-minutes-02**: expected `2026-05-26 Meeting Minutes for Snohomish County Public Utility District.pdf`, got `2026-05-26 Consent Agenda from Snohomish County Public Utility District.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED
- **real8-minutes-03**: expected `2026-09-01 Faculty Senate Minutes for University of Toledo Faculty Senate.pdf`, got `2026-09-01 Toledo Faculty Senate Minutes for The University of Toledo Faculty Senate.pdf` · review: PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED

## How to compare

Keep this run's JSON, make the change, run again, then:

```text
intern-bench compare --before before.json --after after.json --markdown diff.md
```

It recomputes every rate and count over the documents both runs scored, lists each document whose score flipped, and gives the change in p50/p95 of every stage over the documents both completed - between two live runs only, since a replay's timings are its recording's. `intern-bench report --input report.json --markdown report.md` re-renders this page from the JSON.
