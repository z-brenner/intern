# InternBench: live run

- **Run:** 2026-11-11T08:00:31Z · commit `0c8d3295d9`
- **Machine:** AMD EPYC 7763 64-Core Processor, 4 logical cores, 15.6 GB RAM, linux (Ubuntu 24.04.5 LTS)
- **Model:** `intern-local` · 5.68 GB · sha256 `03b74727a860`
- **Corpus:** 77 documents · 77 completed · gold `0d03c75723`
- **Wall time:** 6237.03 s for the whole run, the worker's start included

## Scorecard

| Score | Result |
| --- | ---: |
| Filename (the whole name) | 70/77 (90.9%) |
| Document type | 75/77 (97.4%) |
| Date | 74/77 (96.1%) |
| Date role (when the reviewed date was chosen) | 55/73 (75.3%) |
| Parties | 76/77 (98.7%) |
| Relation word (when parties were named) | 76/77 (98.7%) |
| Party in the right role (when parties were named) | 76/77 (98.7%) |
| Ready / review routing | 46/57 (80.7%) |
| Description has every fact | 22/77 (28.6%) |
| Description states nothing false | 77/77 (100.0%) |
| Description is specific | 77/77 (100.0%) |
| Description fact coverage | 56.9% (mean of 77) |
| Description specificity | 97.8% (mean of 77) |
| Evidence recall (model's quotes) | 89.4% (mean of 77) |
| Digest recall (facts reaching the digest) | 99.4% (mean of 77) |
| Prompt recall (facts reaching the prompt sent) | 100.0% (mean of 77) |
| Sent to review | 16.9% of 77 completed |

## Phase 3 scorecard

| Figure | Value | Docs |
| --- | ---: | ---: |
| Long-document filename accuracy (10+ pages) | 83.3% | 12 |
| Complex-document filename accuracy | 89.3% | 56 |
| Description completeness | 56.9% | 77 |
| Unsupported-fact rate (documents) | 7.8% | 77 |
| Review rate | 16.9% | 77 |
| Evidence recall | 89.4% | 77 |
| Total latency p50 | 74.54 s | 77 |
| Total latency p95 | 135.14 s | 77 |
| Generation latency p50 | 17.85 s | 77 |
| Generation latency p95 | 21.99 s | 77 |
| Generated tokens p50 | 89 | 77 |
| Generated tokens p95 | 108 | 77 |
| Prompt tokens p50 | 870 | 77 |

Long: 10 pages or more. Complex: any of `referenced_agreement`, `middle_fact`, `multi_column`, `layout_parties`, `irrelevant_names`, `information_dense`, `stream_order`, `date_in_table`, `key_value`, `complex_pdf`. Unsupported-fact rate: documents with any `*_UNSUPPORTED` review reason. Latency and tokens over the documents that completed.

## Safety

| Check | Count |
| --- | ---: |
| Filed without review under a wrong name | 5 of 77 |
| Trap date chosen | 3 of 77 |
| Forbidden party named | 1 of 77 |
| Spurious parties named | 1 |
| Description states a known-wrong fact | 0 |
| Unsupported description claims | 0 of 295 (0.0%) |
| Right name sent to review anyway | 7 of 53 |
| Sent to review for an unsupported fact | 6 of 77 |

## By kind

| Kind | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| amendment | 3 | 3/3 | 3/3 | 3/3 | 1/1 | 0.0% | 95.75 s | 98.17 s |
| annual_report | 2 | 1/2 | 2/2 | 1/2 | 2/2 | 0.0% | 71.75 s | 124.77 s |
| bill_of_lading | 1 | 1/1 | 1/1 | 1/1 | – | 0.0% | 76.72 s | 76.72 s |
| certificate | 1 | 0/1 | 1/1 | 1/1 | – | 0.0% | 80.10 s | 80.10 s |
| claim | 1 | 1/1 | 1/1 | 1/1 | – | 0.0% | 68.36 s | 68.36 s |
| condition_report | 1 | 1/1 | 1/1 | 1/1 | – | 0.0% | 77.65 s | 77.65 s |
| contract | 16 | 15/16 | 15/16 | 16/16 | 12/12 | 0.0% | 102.54 s | 145.37 s |
| email | 1 | 1/1 | 1/1 | 1/1 | 0/1 | 100.0% | 65.44 s | 65.44 s |
| form | 5 | 5/5 | 5/5 | 5/5 | 4/4 | 20.0% | 63.08 s | 87.90 s |
| inspection_report | 1 | 1/1 | 1/1 | 1/1 | 1/1 | 0.0% | 54.09 s | 54.09 s |
| insurance | 2 | 1/2 | 1/2 | 2/2 | 2/2 | 0.0% | 98.85 s | 149.42 s |
| invoice | 7 | 7/7 | 7/7 | 7/7 | 4/5 | 28.6% | 54.96 s | 64.70 s |
| letter | 5 | 4/5 | 5/5 | 5/5 | 0/4 | 80.0% | 73.34 s | 87.95 s |
| log | 1 | 1/1 | 1/1 | 1/1 | – | 0.0% | 148.00 s | 148.00 s |
| maintenance_record | 1 | 1/1 | 1/1 | 1/1 | – | 100.0% | 84.88 s | 84.88 s |
| minutes | 1 | 1/1 | 1/1 | 1/1 | 1/1 | 0.0% | 104.91 s | 104.91 s |
| newsletter | 1 | 1/1 | 1/1 | 1/1 | – | 0.0% | 74.54 s | 74.54 s |
| notice | 10 | 10/10 | 10/10 | 10/10 | 7/8 | 20.0% | 55.33 s | 98.51 s |
| payroll | 1 | 1/1 | 1/1 | 1/1 | 1/1 | 0.0% | 68.79 s | 68.79 s |
| presentation | 2 | 2/2 | 2/2 | 2/2 | 2/2 | 0.0% | 74.35 s | 113.25 s |
| price_list | 1 | 1/1 | 1/1 | 1/1 | 1/1 | 0.0% | 89.42 s | 89.42 s |
| purchase_order | 2 | 2/2 | 2/2 | 2/2 | 0/1 | 50.0% | 48.37 s | 81.34 s |
| quotation | 1 | 1/1 | 1/1 | 1/1 | 0/1 | 0.0% | 60.49 s | 60.49 s |
| rate_confirmation | 1 | 1/1 | 1/1 | 1/1 | 1/1 | 0.0% | 72.14 s | 72.14 s |
| receipt | 1 | 0/1 | 1/1 | 1/1 | 1/1 | 100.0% | 54.40 s | 54.40 s |
| remittance_advice | 1 | 1/1 | 1/1 | 1/1 | 0/1 | 0.0% | 64.44 s | 64.44 s |
| report | 2 | 2/2 | 2/2 | 2/2 | 2/2 | 0.0% | 122.57 s | 129.62 s |
| resolution | 1 | 1/1 | 1/1 | 1/1 | 1/1 | 0.0% | 104.65 s | 104.65 s |
| sow | 1 | 0/1 | 0/1 | 1/1 | 1/1 | 0.0% | 89.94 s | 89.94 s |
| statement | 3 | 3/3 | 3/3 | 3/3 | 2/3 | 0.0% | 73.07 s | 88.95 s |

## By text layer

| Text layer | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| email | 1 | 1/1 | 1/1 | 1/1 | 0/1 | 100.0% | 65.44 s | 65.44 s |
| mixed | 3 | 3/3 | 3/3 | 3/3 | – | 0.0% | 77.59 s | 98.17 s |
| native | 47 | 42/47 | 44/47 | 46/47 | 38/44 | 14.9% | 81.34 s | 135.14 s |
| ocr_corrupted | 1 | 1/1 | 1/1 | 1/1 | – | 100.0% | 47.41 s | 47.41 s |
| office | 5 | 5/5 | 5/5 | 5/5 | 4/5 | 20.0% | 104.24 s | 113.25 s |
| scan | 16 | 14/16 | 16/16 | 16/16 | 1/4 | 18.8% | 60.49 s | 120.58 s |
| sheet | 3 | 3/3 | 3/3 | 3/3 | 2/2 | 0.0% | 122.57 s | 148.00 s |
| text | 1 | 1/1 | 1/1 | 1/1 | 1/1 | 0.0% | 68.98 s | 68.98 s |

## By page count

| Pages | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 37 | 35/37 | 37/37 | 37/37 | 19/26 | 27.0% | 63.08 s | 104.65 s |
| 2-4 | 24 | 23/24 | 24/24 | 24/24 | 13/17 | 12.5% | 76.24 s | 108.70 s |
| 5-9 | 4 | 2/4 | 3/4 | 3/4 | 4/4 | 0.0% | 71.75 s | 89.94 s |
| 10-24 | 4 | 4/4 | 4/4 | 4/4 | 3/3 | 0.0% | 96.88 s | 114.15 s |
| 25-49 | 4 | 3/4 | 3/4 | 4/4 | 3/3 | 0.0% | 120.58 s | 145.37 s |
| 50-99 | 2 | 1/2 | 1/2 | 2/2 | 2/2 | 0.0% | 135.14 s | 149.42 s |
| 100+ | 2 | 2/2 | 2/2 | 2/2 | 2/2 | 0.0% | 124.77 s | 129.62 s |

## By slice

| Slice | Docs | Filename | Date | Parties | Routing | Unsafe ready | p50 total | p95 total | p50 generation | p95 generation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| long | 12 | 10/12 | 10/12 | 12/12 | 10/10 | 2 of 12 | 120.58 s | 149.42 s | 18.00 s | 21.95 s |
| complex | 56 | 50/56 | 53/56 | 55/56 | 39/46 | 5 of 56 | 76.72 s | 135.14 s | 17.85 s | 21.99 s |

`long`: 10 pages or more. `complex`: any of the categories listed under the phase 3 scorecard. A document may be in both.

## By challenge

| Category | Docs | Filename | Date | Parties | Traps sprung |
| --- | ---: | ---: | ---: | ---: | ---: |
| amendment | 3 | 3/3 | 3/3 | 3/3 | 0 |
| competing_dates | 67 | 61/67 | 64/67 | 66/67 | 4 |
| complex_pdf | 5 | 4/5 | 5/5 | 4/5 | 1 |
| contract | 20 | 18/20 | 18/20 | 20/20 | 2 |
| csv | 1 | 1/1 | 1/1 | 1/1 | 0 |
| date_in_table | 7 | 5/7 | 5/7 | 7/7 | 2 |
| docx | 3 | 3/3 | 3/3 | 3/3 | 0 |
| email | 1 | 1/1 | 1/1 | 1/1 | 0 |
| financial | 10 | 7/10 | 9/10 | 9/10 | 2 |
| form | 7 | 6/7 | 7/7 | 7/7 | 0 |
| healthcare | 3 | 3/3 | 3/3 | 3/3 | 0 |
| hr | 4 | 4/4 | 4/4 | 4/4 | 0 |
| image_only_scan | 16 | 14/16 | 16/16 | 16/16 | 0 |
| image_region | 1 | 1/1 | 1/1 | 1/1 | 0 |
| information_dense | 10 | 8/10 | 8/10 | 10/10 | 2 |
| invoice | 7 | 7/7 | 7/7 | 7/7 | 0 |
| irrelevant_names | 17 | 14/17 | 15/17 | 17/17 | 2 |
| key_value | 11 | 10/11 | 11/11 | 11/11 | 0 |
| layout_parties | 11 | 11/11 | 11/11 | 11/11 | 0 |
| letter | 5 | 4/5 | 5/5 | 5/5 | 0 |
| low_resolution_scan | 3 | 2/3 | 3/3 | 3/3 | 0 |
| middle_fact | 6 | 4/6 | 4/6 | 6/6 | 2 |
| mixed_scan | 3 | 3/3 | 3/3 | 3/3 | 0 |
| multi_column | 7 | 7/7 | 7/7 | 7/7 | 0 |
| noisy_scan | 3 | 3/3 | 3/3 | 3/3 | 0 |
| notice | 10 | 10/10 | 10/10 | 10/10 | 0 |
| ocr_corrupted | 1 | 1/1 | 1/1 | 1/1 | 0 |
| ocr_critical_fields | 4 | 3/4 | 4/4 | 4/4 | 0 |
| pages_10 | 3 | 3/3 | 3/3 | 3/3 | 0 |
| pages_100 | 2 | 2/2 | 2/2 | 2/2 | 0 |
| pages_25 | 4 | 3/4 | 3/4 | 4/4 | 1 |
| pages_5 | 1 | 0/1 | 0/1 | 1/1 | 1 |
| pages_50 | 2 | 1/2 | 1/2 | 2/2 | 1 |
| png | 5 | 4/5 | 5/5 | 5/5 | 0 |
| pptx | 2 | 2/2 | 2/2 | 2/2 | 0 |
| presentation | 2 | 2/2 | 2/2 | 2/2 | 0 |
| purchase_order | 2 | 2/2 | 2/2 | 2/2 | 0 |
| referenced_agreement | 20 | 18/20 | 19/20 | 20/20 | 1 |
| rotated_page | 1 | 1/1 | 1/1 | 1/1 | 0 |
| rotated_scan | 4 | 4/4 | 4/4 | 4/4 | 0 |
| simple_digital | 1 | 1/1 | 1/1 | 1/1 | 0 |
| sow | 1 | 0/1 | 0/1 | 1/1 | 1 |
| spreadsheet | 3 | 3/3 | 3/3 | 3/3 | 0 |
| statement | 3 | 3/3 | 3/3 | 3/3 | 0 |
| stream_order | 3 | 3/3 | 3/3 | 3/3 | 0 |
| table | 41 | 37/41 | 39/41 | 40/41 | 3 |
| tiff | 2 | 2/2 | 2/2 | 2/2 | 0 |
| unusual | 4 | 4/4 | 4/4 | 4/4 | 0 |
| xlsx | 2 | 2/2 | 2/2 | 2/2 | 0 |

## OCR

| Document | Layer | Pages | CER | CER (any case) | WER | Dates | Names | IDs | Confidence | OCR time |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| scan-clean-lease-2p | scan | 2 | 0.4% | 0.4% | 0.5% | 100.0% | 100.0% | 100.0% | 96 | 3.83 s |
| scan-mixed-amendment | mixed | 1 | 2.3% | 2.3% | 2.9% | 100.0% | 100.0% | – | 97 | 1.19 s |
| scan-rotated-90-invoice | scan | 1 | 0.0% | 0.0% | 0.0% | 100.0% | 100.0% | 100.0% | 98 | 1.27 s |
| scan-upside-down-po | scan | 1 | 0.1% | 0.1% | 0.7% | 100.0% | 100.0% | 100.0% | 99 | 1.86 s |
| scan-skewed-notice | scan | 1 | 0.0% | 0.0% | 0.0% | 100.0% | 100.0% | 100.0% | 98 | 1.85 s |
| scan-low-res-receipt | scan | 1 | 12.5% | 12.5% | 3.0% | 100.0% | 100.0% | 100.0% | 98 | 1.03 s |
| scan-noisy-statement | scan | 1 | 1.0% | 1.0% | 9.2% | 100.0% | 100.0% | 100.0% | 95 | 1.58 s |
| scan-faint-letter | scan | 1 | 0.4% | 0.4% | 0.5% | 100.0% | 100.0% | – | 98 | 1.74 s |
| scan-agreement-10p | scan | 10 | 0.1% | 0.1% | 0.1% | 100.0% | 100.0% | 100.0% | 98 | 23.46 s |
| scan-lease-25p | scan | 25 | 0.0% | 0.0% | 0.1% | 100.0% | 100.0% | 100.0% | 99 | 50.98 s |
| scan-fax-two-frames | scan | 2 | 2.6% | 2.6% | 1.4% | 100.0% | 100.0% | 100.0% | 99 | 2.61 s |
| scan-patient-intake-form | scan | 1 | 0.4% | 0.4% | 1.8% | 100.0% | 100.0% | 100.0% | 96 | 2.07 s |
| scan-rotated-page-in-pdf | scan | 2 | 0.1% | 0.1% | 0.5% | 100.0% | 100.0% | 100.0% | 98 | 3.00 s |
| scan-cancellation-notice-150dpi | scan | 1 | 0.0% | 0.0% | 0.0% | 100.0% | 100.0% | 100.0% | 97 | 1.97 s |
| scan-remittance-advice-120dpi | scan | 1 | 10.1% | 10.0% | 12.7% | 100.0% | 100.0% | 100.0% | 98 | 2.11 s |
| scan-mixed-middle-page | mixed | 1 | 4.0% | 4.0% | 4.0% | – | – | 100.0% | 96 | 1.22 s |
| mixed-signature-region | mixed | 1 | 0.2% | 0.2% | 1.0% | 100.0% | 100.0% | – | – | 755.1 ms |
| scan-certificate-of-insurance | scan | 1 | 28.8% | 28.0% | 33.3% | 100.0% | 100.0% | 100.0% | 98 | 2.95 s |
| scan-bill-of-lading | scan | 1 | 32.5% | 31.7% | 30.2% | 100.0% | 100.0% | 100.0% | 98 | 2.48 s |
| **All scanned pages** |  | 55 | 1.8% | 1.8% | 1.9% | 100.0% | 100.0% | 100.0% | 98 | – |

Error rates are edit distances over the drawn text's length, pooled over pages; Dates, Names and IDs are the fraction of those drawn on the read pages that survive OCR. A page the reader does not return (a TIFF frame it does not read, shown as unread) counts as read empty, as does every page of a scan whose extraction failed: every character and value on it missed.

## Structure

| Document | Route class | Reading order (snippets) | Table rows | Table cells | Key-values | Routes (pages) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| invoice-date-in-table | layout | – | 7/7 (100.0%) | 39/39 (100.0%) | 7/7 (100.0%) | 1/1 (100.0%) |
| invoice-layout-only | layout | – | 5/5 (100.0%) | 25/25 (100.0%) | 7/7 (100.0%) | 1/1 (100.0%) |
| purchase-order | layout | – | 8/8 (100.0%) | 48/48 (100.0%) | 3/3 (100.0%) | 1/1 (100.0%) |
| lease-two-column | layout | 8/8 (100.0%) | 10/10 (100.0%) | 20/20 (100.0%) | – | 1/1 (100.0%) |
| declarations-interleaved | layout | 8/8 (100.0%) | 6/6 (100.0%) | 12/12 (100.0%) | 6/6 (100.0%) | 2/2 (100.0%) |
| vendor-registration-form | layout | – | – | – | 6/6 (100.0%) | 1/1 (100.0%) |
| change-order-form | layout | – | 6/6 (100.0%) | 18/18 (100.0%) | 6/6 (100.0%) | 1/1 (100.0%) |
| scan-patient-intake-form | ocr | – | – | – | 6/6 (100.0%) | 1/1 (100.0%) |
| newsletter-three-column | layout | 9/9 (100.0%) | – | – | – | 1/1 (100.0%) |
| agreement-two-column-footnotes | layout | 10/10 (100.0%) | – | – | – | 2/2 (100.0%) |
| meeting-notice-columns | layout | 11/11 (100.0%) | – | – | – | 1/1 (100.0%) |
| meeting-notice-interleaved | layout | 11/11 (100.0%) | – | – | – | 1/1 (100.0%) |
| meeting-notice-reversed | layout | 11/11 (100.0%) | – | – | – | 1/1 (100.0%) |
| rate-confirmation-rotated | layout | – | 4/4 (100.0%) | 28/28 (100.0%) | 5/5 (100.0%) | 2/2 (100.0%) |
| inspection-log-ruled-2p | layout | – | 45/45 (100.0%) | 315/315 (100.0%) | 5/5 (100.0%) | 2/2 (100.0%) |
| price-list-unruled | layout | – | 21/21 (100.0%) | 126/126 (100.0%) | – | 1/1 (100.0%) |
| invoice-label-above | layout | – | – | – | 8/8 (100.0%) | 1/1 (100.0%) |
| invoice-right-aligned | layout | – | 7/7 (100.0%) | 28/28 (100.0%) | 8/8 (100.0%) | 1/1 (100.0%) |
| invoice-boxed-grid | layout | – | 5/5 (100.0%) | 20/20 (100.0%) | 11/11 (100.0%) | 1/1 (100.0%) |
| benefits-change-checkbox-form | layout | – | 17/17 (100.0%) | 22/22 (100.0%) | 7/7 (100.0%) | 1/1 (100.0%) |
| loss-notice-boxed-fields | layout | – | – | – | 17/17 (100.0%) | 1/1 (100.0%) |
| scan-rotated-page-in-pdf | ocr | – | 6/6 (100.0%) | 36/36 (100.0%) | 5/5 (100.0%) | 2/2 (100.0%) |
| scan-cancellation-notice-150dpi | ocr | – | – | – | 7/7 (100.0%) | 1/1 (100.0%) |
| scan-remittance-advice-120dpi | ocr | – | 6/7 (85.7%) | 34/35 (97.1%) | 7/7 (100.0%) | 1/1 (100.0%) |
| scan-mixed-middle-page | ocr | – | 6/6 (100.0%) | 24/24 (100.0%) | – | 3/3 (100.0%) |
| mixed-signature-region | ocr_regions | 5/5 (100.0%) | – | – | – | 2/2 (100.0%) |
| scan-certificate-of-insurance | ocr | – | 3/5 (60.0%) | 28/30 (93.3%) | 4/5 (80.0%) | 1/1 (100.0%) |
| scan-bill-of-lading | ocr | – | 5/5 (100.0%) | 31/31 (100.0%) | 10/10 (100.0%) | 1/1 (100.0%) |
| msa-effective-date-in-definitions-12p | layout | 3/5 (60.0%) | – | – | 1/1 (100.0%) | – |
| industrial-lease-dated-in-schedule-25p | layout | 5/7 (71.4%) | – | – | 3/3 (100.0%) | – |
| term-loan-parties-apart-40p | layout | 1/8 (12.5%) | – | – | 1/1 (100.0%) | – |
| property-policy-declarations-mid-60p | layout | 1/6 (16.7%) | – | – | 2/2 (100.0%) | – |
| watershed-monitoring-report-100p | layout | 1/8 (12.5%) | – | – | – | – |
| **All** |  | 84/107 (78.5%) | 167/170 (98.2%) | 854/857 (99.6%) | 142/143 (99.3%) | 36/36 (100.0%) |

Measured over the page text the engine receives. Reading order: the most gold snippets found in the gold's order (a longest increasing run), of all of them. Table rows: rows whose cells are all on one line of their table, in order, with no other row between them and an empty check box left empty. Table cells: cells found in their table's lines. Key-values: values after their label on its line (before the next label), alone on the next line, or in the cell under it in a linearized table. Routes: pages whose layout took the expected route, judged only when the worker sends layouts. See `docs/internbench.md` for the exact rules.

## Routes

- **Pages:** fast 121 · layout 392 · ocr 55 · ocr_regions 1
- **Documents by route class:** fast 11 · layout 46 · ocr 19 · ocr_regions 1
- **Pages the gold gives a route for:** 36, 36 judged

| Expected, then taken | fast | layout | ocr | ocr_regions |
| --- | ---: | ---: | ---: | ---: |
| fast | 5 | · | · | · |
| layout | · | 22 | · | · |
| ocr | · | · | 8 | · |
| ocr_regions | · | · | · | 1 |

Pages the gold gives a route for, by the route they should take and the one they took (`none`: the page came without a layout).

## Where the time goes

| Stage | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `total_ms` | 77 | 74.54 s | 135.14 s | 149.42 s |
| `extraction_wall_ms` | 77 | 5.4 ms | 3.13 s | 51.16 s |
| `worker_total_ms` | 77 | 4.6 ms | 3.13 s | 51.16 s |
| `worker_snapshot_ms` | 77 | 0.22 ms | 0.52 ms | 1.3 ms |
| `worker_parse_ms` | 77 | 2.4 ms | 64.6 ms | 110.2 ms |
| `worker_analysis_ms` | 77 | 0.55 ms | 35.9 ms | 84.0 ms |
| `worker_render_ms` | 77 | 0.00 ms | 199.3 ms | 3.51 s |
| `worker_image_decode_ms` | 77 | 0.00 ms | 68.2 ms | 104.4 ms |
| `worker_ocr_ms` | 77 | 0.00 ms | 3.00 s | 50.98 s |
| `worker_ocr_encode_ms` | 77 | 0.00 ms | 259.0 ms | 4.62 s |
| `worker_ocr_engine_ms` | 77 | 0.00 ms | 2.70 s | 46.22 s |
| `worker_vision_ms` | 77 | 0.00 ms | 6.0 ms | 12.2 ms |
| `analyze_wall_ms` | 77 | 73.34 s | 135.08 s | 149.27 s |
| `distill_ms` | 77 | 4.2 ms | 121.8 ms | 575.4 ms |
| `prompt_ms` | 77 | 0.03 ms | 0.06 ms | 0.07 ms |
| `inference_ms` | 77 | 73.29 s | 134.73 s | 148.72 s |
| `prefill_ms` | 77 | 54.99 s | 116.72 s | 129.71 s |
| `generation_ms` | 77 | 17.85 s | 21.99 s | 24.71 s |
| `validation_ms` | 77 | 33.4 ms | 383.2 ms | 786.7 ms |
| `naming_ms` | 77 | 1.0 ms | 11.7 ms | 18.5 ms |
| `index_ms` | 77 | 3.7 ms | 110.1 ms | 565.6 ms |
| `retrieval_ms` | 77 | 0.04 ms | 4.8 ms | 10.5 ms |

| Measure | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `prefill_tok_per_s` | 77 | 16.1 tok/s | 16.5 tok/s | 16.6 tok/s |
| `generation_tok_per_s` | 77 | 5.0 tok/s | 5.1 tok/s | 5.2 tok/s |
| `prompt_tokens` | 77 | 870 | 1861 | 2080 |
| `cached_tokens` | 77 | 477 | 477 | 1104 |
| `generated_tokens` | 77 | 89 | 108 | 123 |
| `estimated_prompt_tokens` | 77 | 1464 | 2506 | 2612 |
| `model_requests` | 77 | 1 | 1 | 1 |
| `redistillations` | 77 | 0 | 0 | 0 |
| `source_characters` | 77 | 2460 | 112672 | 211186 |
| `digest_characters` | 77 | 2496 | 5387 | 6343 |
| `prompt_characters` | 77 | 4545 | 7442 | 8398 |
| `worker_ocr_pages` | 77 | 0 | 2 | 25 |
| `worker_ocr_passes` | 77 | 0 | 2 | 25 |
| `worker_orientation_passes` | 77 | 0 | 2 | 25 |
| `worker_rendered_pixels` | 77 | 0 | 16830000 | 210375000 |
| `index_units` | 77 | 28 | 1339 | 3806 |
| `context_units` | 77 | 25 | 59 | 68 |
| `context_tokens` | 77 | 876 | 1915 | 2022 |

## Extraction time

| Route class | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fast | 11 | 1.9 ms | 5.4 ms | 1.2 ms | 3.9 ms | 3.0 ms | 0.40 ms | 0.00 ms | 0.00 ms |
| layout | 46 | 4.4 ms | 127.5 ms | 4.0 ms | 110.3 ms | 77.5 ms | 43.4 ms | 0.00 ms | 0.00 ms |
| ocr_regions | 1 | 858.4 ms | 858.4 ms | 857.9 ms | 857.9 ms | 2.2 ms | 0.31 ms | 74.2 ms | 755.1 ms |
| ocr | 19 | 2.10 s | 51.16 s | 2.10 s | 51.16 s | 32.8 ms | 1.7 ms | 3.51 s | 50.98 s |

| Pages | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 37 | 3.8 ms | 2.63 s | 3.2 ms | 2.63 s | 25.3 ms | 0.84 ms | 120.8 ms | 2.48 s |
| 2-4 | 24 | 5.1 ms | 3.13 s | 4.2 ms | 3.13 s | 4.6 ms | 1.3 ms | 199.3 ms | 3.00 s |
| 5-9 | 4 | 8.9 ms | 13.5 ms | 8.2 ms | 12.7 ms | 10.1 ms | 3.1 ms | 0.00 ms | 0.00 ms |
| 10-24 | 4 | 18.8 ms | 23.60 s | 16.9 ms | 23.60 s | 14.6 ms | 5.8 ms | 1.13 s | 23.46 s |
| 25-49 | 4 | 51.8 ms | 51.16 s | 47.3 ms | 51.16 s | 51.8 ms | 35.9 ms | 3.51 s | 50.98 s |
| 50-99 | 2 | 57.2 ms | 148.4 ms | 52.8 ms | 132.7 ms | 77.5 ms | 53.6 ms | 0.00 ms | 0.00 ms |
| 100+ | 2 | 127.5 ms | 224.0 ms | 110.3 ms | 196.5 ms | 110.2 ms | 84.0 ms | 0.00 ms | 0.00 ms |

| Kind | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| amendment | 3 | 858.4 ms | 1.33 s | 857.9 ms | 1.33 s | 3.3 ms | 0.93 ms | 108.0 ms | 1.19 s |
| annual_report | 2 | 8.9 ms | 127.5 ms | 8.2 ms | 110.3 ms | 64.6 ms | 43.4 ms | 0.00 ms | 0.00 ms |
| bill_of_lading | 1 | 2.63 s | 2.63 s | 2.63 s | 2.63 s | 0.21 ms | 0.38 ms | 120.8 ms | 2.48 s |
| certificate | 1 | 3.09 s | 3.09 s | 3.09 s | 3.09 s | 0.15 ms | 0.37 ms | 103.6 ms | 2.95 s |
| claim | 1 | 3.13 s | 3.13 s | 3.13 s | 3.13 s | 0.27 ms | 0.31 ms | 199.3 ms | 3.00 s |
| condition_report | 1 | 4.0 ms | 4.0 ms | 3.6 ms | 3.6 ms | 2.5 ms | 0.67 ms | 0.00 ms | 0.00 ms |
| contract | 16 | 22.8 ms | 51.16 s | 21.0 ms | 51.16 s | 51.8 ms | 35.9 ms | 3.51 s | 50.98 s |
| email | 1 | 0.92 ms | 0.92 ms | 0.50 ms | 0.50 ms | 0.18 ms | 0.00 ms | 0.00 ms | 0.00 ms |
| form | 5 | 3.8 ms | 2.19 s | 3.3 ms | 2.19 s | 25.3 ms | 0.73 ms | 0.00 ms | 2.07 s |
| inspection_report | 1 | 8.0 ms | 8.0 ms | 7.1 ms | 7.1 ms | 4.6 ms | 2.0 ms | 0.00 ms | 0.00 ms |
| insurance | 2 | 4.1 ms | 148.4 ms | 3.7 ms | 132.7 ms | 77.5 ms | 53.6 ms | 0.00 ms | 0.00 ms |
| invoice | 7 | 3.0 ms | 1.75 s | 2.5 ms | 1.75 s | 21.4 ms | 0.57 ms | 112.2 ms | 1.62 s |
| letter | 5 | 3.8 ms | 1.80 s | 3.4 ms | 1.80 s | 18.2 ms | 0.60 ms | 0.00 ms | 1.74 s |
| log | 1 | 1.8 ms | 1.8 ms | 1.1 ms | 1.1 ms | 0.78 ms | 0.00 ms | 0.00 ms | 0.00 ms |
| maintenance_record | 1 | 3.8 ms | 3.8 ms | 3.3 ms | 3.3 ms | 2.2 ms | 0.72 ms | 0.00 ms | 0.00 ms |
| minutes | 1 | 5.4 ms | 5.4 ms | 3.9 ms | 3.9 ms | 3.0 ms | 0.40 ms | 0.00 ms | 0.00 ms |
| newsletter | 1 | 4.3 ms | 4.3 ms | 3.8 ms | 3.8 ms | 2.6 ms | 0.84 ms | 0.00 ms | 0.00 ms |
| notice | 10 | 4.0 ms | 2.10 s | 3.6 ms | 2.10 s | 106.6 ms | 0.85 ms | 106.2 ms | 1.97 s |
| payroll | 1 | 2.0 ms | 2.0 ms | 1.3 ms | 1.3 ms | 1.0 ms | 0.00 ms | 0.00 ms | 0.00 ms |
| presentation | 2 | 1.9 ms | 2.3 ms | 1.5 ms | 1.9 ms | 1.6 ms | 0.00 ms | 0.00 ms | 0.00 ms |
| price_list | 1 | 3.2 ms | 3.2 ms | 2.8 ms | 2.8 ms | 1.7 ms | 0.78 ms | 0.00 ms | 0.00 ms |
| purchase_order | 2 | 4.0 ms | 1.98 s | 3.1 ms | 1.98 s | 2.0 ms | 0.74 ms | 97.7 ms | 1.86 s |
| quotation | 1 | 2.72 s | 2.72 s | 2.71 s | 2.71 s | 32.8 ms | 0.18 ms | 0.00 ms | 2.61 s |
| rate_confirmation | 1 | 3.4 ms | 3.4 ms | 3.0 ms | 3.0 ms | 2.2 ms | 0.50 ms | 0.00 ms | 0.00 ms |
| receipt | 1 | 1.04 s | 1.04 s | 1.04 s | 1.04 s | 7.6 ms | 0.09 ms | 0.00 ms | 1.03 s |
| remittance_advice | 1 | 2.15 s | 2.15 s | 2.15 s | 2.15 s | 22.5 ms | 0.20 ms | 0.00 ms | 2.11 s |
| report | 2 | 2.5 ms | 224.0 ms | 0.61 ms | 196.5 ms | 110.2 ms | 84.0 ms | 0.00 ms | 0.00 ms |
| resolution | 1 | 1.6 ms | 1.6 ms | 1.2 ms | 1.2 ms | 0.94 ms | 0.00 ms | 0.00 ms | 0.00 ms |
| sow | 1 | 11.0 ms | 11.0 ms | 10.2 ms | 10.2 ms | 6.6 ms | 3.1 ms | 0.00 ms | 0.00 ms |
| statement | 3 | 6.0 ms | 1.73 s | 4.8 ms | 1.73 s | 3.2 ms | 1.3 ms | 123.1 ms | 1.58 s |

Over the documents that completed. Wall is the runner's clock around the request; worker is the worker's own total. OCR is summed over the pages, so when the worker reads pages in parallel it can exceed the total. A document's route class is the most expensive route any of its pages took (ocr > ocr_regions > layout > fast), or `unrouted` when the worker sent no layouts.

## Memory

| Process | Typical peak (p50) | Highest peak | During |
| --- | ---: | ---: | ---: |
| Parser worker | 18 MB | 771 MB | scan-lease-25p |
| Model server | 6132 MB | 6134 MB | watershed-monitoring-report-100p |
| Benchmark (engine) | 23 MB | 42 MB | watershed-monitoring-report-100p |

Resident memory sampled every 25 ms per document; a spike shorter than that can be missed.

## Misses (7)

- **sow-under-msa-5p**: expected `2026-05-26 Statement of Work between Thornbury Data Labs LLC and Saltmarsh Regional Water Authority.pdf`, got `2026-06-03 Statement of Work between Thornbury Data Labs LLC and Saltmarsh Regional Water Authority.pdf` · trap: date 2026-06-03 (client signature date) · **filed without review**
- **engagement-letter**: expected `2026-01-09 Engagement Letter between Halloran Ostrowski CPAs LLP and Silverbirch Ceramics Inc.pdf`, got `2026-01-09 Letter to Silverbirch Ceramics Inc.pdf` · review: TYPE_MISSING
- **annual-report-excerpt-8p**: expected `2026-03-12 Annual Report from Rookwood Precision Metals Corporation.pdf`, got `2026-03-12 2025 Annual Report for Casimir Ellingsen.pdf` · trap: party Casimir Ellingsen (chief executive who signs the letter) · **filed without review**
- **scan-low-res-receipt**: expected `2026-05-09 Receipt from Quarry Bend Hardware & Feed.png`, got `2026-05-09 Document from Quarry Bend Hardware & Feed.png` · review: TYPE_UNSUPPORTED
- **scan-certificate-of-insurance**: expected `2026-06-23 Certificate of Liability Insurance for Ostergaard Roofing Contractors LLC.pdf`, got `2026-06-23 Certificate of Liability Insurance Date (Mmddyyyy) for Ostergaard Roofing Contractors LLC.pdf` · **filed without review**
- **industrial-lease-dated-in-schedule-25p**: expected `2026-04-14 Industrial Lease between Ardent Quay Industrial Properties LP and Moss & Lanyard Distribution Inc.pdf`, got `2026-04-16 Industrial Lease between Ardent Quay Industrial Properties LP and Moss & Lanyard Distribution Inc.pdf` · trap: date 2026-04-16 (tenant signature date) · **filed without review**
- **property-policy-declarations-mid-60p**: expected `2026-07-01 Commercial Property Policy for Hollowmere Craft Brewing Cooperative.pdf`, got `2026-06-24 Commercial Property Policy for Hollowmere Craft Brewing Cooperative.pdf` · trap: date 2026-06-24 (countersignature date) · **filed without review**

## How to compare

Keep this run's JSON, make the change, run again, then:

```text
intern-bench compare --before before.json --after after.json --markdown diff.md
```

It recomputes every rate and count over the documents both runs scored, lists each document whose score flipped, and gives the change in p50/p95 of every stage over the documents both completed - between two live runs only, since a replay's timings are its recording's. `intern-bench report --input report.json --markdown report.md` re-renders this page from the JSON.
