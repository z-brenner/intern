# InternBench: live run

- **Run:** 2026-11-11T07:59:57Z · commit `0c8d3295d9`
- **Machine:** AMD EPYC 7763 64-Core Processor, 4 logical cores, 15.6 GB RAM, linux (Ubuntu 24.04.5 LTS)
- **Model:** `intern-local` · 5.68 GB · sha256 `03b74727a860`
- **Corpus:** 59 documents · 59 completed · gold `0860327e2c`
- **Wall time:** 4223.79 s for the whole run, the worker's start included

## Scorecard

| Score | Result |
| --- | ---: |
| Filename (the whole name) | 31/59 (52.5%) |
| Document type | 49/59 (83.0%) |
| Date | 53/59 (89.8%) |
| Date role (when the reviewed date was chosen) | 22/53 (41.5%) |
| Parties | 43/59 (72.9%) |
| Relation word (when parties were named) | 45/58 (77.6%) |
| Party in the right role (when parties were named) | 21/36 (58.3%) |
| Ready / review routing | 4/35 (11.4%) |
| Description states nothing false | 59/59 (100.0%) |
| Description is specific | 45/59 (76.3%) |
| Description specificity | 69.5% (mean of 59) |
| Evidence recall (model's quotes) | 69.2% (mean of 59) |
| Digest recall (facts reaching the digest) | 92.2% (mean of 59) |
| Prompt recall (facts reaching the prompt sent) | 92.2% (mean of 59) |
| Sent to review | 88.1% of 59 completed |

## Phase 3 scorecard

| Figure | Value | Docs |
| --- | ---: | ---: |
| Long-document filename accuracy (10+ pages) | 100.0% | 3 |
| Complex-document filename accuracy | – | 0 |
| Description completeness | – | 0 |
| Unsupported-fact rate (documents) | 78.0% | 59 |
| Review rate | 88.1% | 59 |
| Evidence recall | 69.2% | 59 |
| Total latency p50 | 72.07 s | 59 |
| Total latency p95 | 116.46 s | 59 |
| Generation latency p50 | 18.61 s | 59 |
| Generation latency p95 | 23.30 s | 59 |
| Generated tokens p50 | 93 | 59 |
| Generated tokens p95 | 114 | 59 |
| Prompt tokens p50 | 760 | 59 |

Long: 10 pages or more. Complex: any of `referenced_agreement`, `middle_fact`, `multi_column`, `layout_parties`, `irrelevant_names`, `information_dense`, `stream_order`, `date_in_table`, `key_value`, `complex_pdf`. Unsupported-fact rate: documents with any `*_UNSUPPORTED` review reason. Latency and tokens over the documents that completed.

## Safety

| Check | Count |
| --- | ---: |
| Filed without review under a wrong name | 2 of 59 |
| Trap date chosen | 0 of 59 |
| Forbidden party named | 12 of 59 |
| Spurious parties named | 14 |
| Description states a known-wrong fact | 0 |
| Unsupported description claims | 0 of 152 (0.0%) |
| Right name sent to review anyway | 18 of 35 |
| Sent to review for an unsupported fact | 46 of 59 |

## By kind

| Kind | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| invoice | 11 | 6/11 | 8/11 | 7/11 | 1/8 | 90.9% | 61.48 s | 108.47 s |
| letter | 25 | 11/25 | 24/25 | 16/25 | 0/13 | 96.0% | 67.66 s | 89.03 s |
| notice | 20 | 14/20 | 20/20 | 19/20 | 3/14 | 80.0% | 85.03 s | 116.46 s |
| receipt | 1 | 0/1 | 0/1 | 0/1 | – | 100.0% | 22.34 s | 22.34 s |
| statement | 2 | 0/2 | 1/2 | 1/2 | – | 50.0% | 30.38 s | 46.18 s |

## By text layer

| Text layer | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| image | 10 | 5/10 | 7/10 | 5/10 | 1/6 | 80.0% | 46.82 s | 108.47 s |
| native | 16 | 10/16 | 15/16 | 15/16 | 1/11 | 87.5% | 66.82 s | 99.86 s |
| office | 17 | 7/17 | 17/17 | 10/17 | 1/8 | 88.2% | 72.86 s | 125.97 s |
| scan | 14 | 8/14 | 12/14 | 11/14 | 0/8 | 100.0% | 76.51 s | 120.64 s |
| text | 2 | 1/2 | 2/2 | 2/2 | 1/2 | 50.0% | 75.18 s | 113.78 s |

## By page count

| Pages | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 27 | 12/27 | 22/27 | 17/27 | 2/14 | 85.2% | 53.81 s | 77.53 s |
| 2-4 | 24 | 12/24 | 23/24 | 18/24 | 2/16 | 87.5% | 76.51 s | 107.78 s |
| 5-9 | 5 | 4/5 | 5/5 | 5/5 | 0/3 | 100.0% | 91.93 s | 116.46 s |
| 10-24 | 2 | 2/2 | 2/2 | 2/2 | 0/1 | 100.0% | 90.91 s | 120.64 s |
| 25-49 | 1 | 1/1 | 1/1 | 1/1 | 0/1 | 100.0% | 125.97 s | 125.97 s |

## By slice

| Slice | Docs | Filename | Date | Parties | Routing | Unsafe ready | p50 total | p95 total | p50 generation | p95 generation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| long | 3 | 3/3 | 3/3 | 3/3 | 0/2 | 0 of 3 | 120.64 s | 125.97 s | 16.90 s | 20.42 s |

`long`: 10 pages or more. `complex`: any of the categories listed under the phase 3 scorecard. A document may be in both.

## By challenge

| Category | Docs | Filename | Date | Parties | Traps sprung |
| --- | ---: | ---: | ---: | ---: | ---: |
| address_of_host_institution | 1 | 1/1 | 1/1 | 1/1 | 0 |
| addressed_to_outside_counsel | 1 | 0/1 | 1/1 | 1/1 | 0 |
| addressed_to_person_at_body | 1 | 0/1 | 1/1 | 0/1 | 1 |
| addressed_to_person_at_company | 8 | 3/8 | 7/8 | 6/8 | 2 |
| addressed_to_person_at_firm | 1 | 1/1 | 1/1 | 1/1 | 0 |
| addressee_at_bottom | 1 | 0/1 | 1/1 | 0/1 | 1 |
| addressee_at_foot | 1 | 1/1 | 1/1 | 1/1 | 0 |
| addressee_in_frame | 1 | 0/1 | 1/1 | 0/1 | 1 |
| addressee_is_office_holder | 1 | 0/1 | 1/1 | 0/1 | 1 |
| advisory_opinion | 2 | 1/2 | 1/2 | 2/2 | 0 |
| agency_billing | 1 | 1/1 | 1/1 | 1/1 | 0 |
| agency_enforcement | 7 | 7/7 | 7/7 | 7/7 | 0 |
| agency_notice | 2 | 1/2 | 2/2 | 2/2 | 0 |
| aka_name | 1 | 1/1 | 1/1 | 1/1 | 0 |
| ambiguous_digit | 1 | 0/1 | 0/1 | 0/1 | 0 |
| annex | 1 | 0/1 | 1/1 | 0/1 | 1 |
| annex_table | 1 | 1/1 | 1/1 | 1/1 | 0 |
| attachments | 2 | 0/2 | 2/2 | 0/2 | 1 |
| australian_government | 1 | 1/1 | 1/1 | 1/1 | 0 |
| bank_details_redacted | 1 | 1/1 | 1/1 | 1/1 | 0 |
| bill_to | 1 | 1/1 | 1/1 | 1/1 | 0 |
| bill_to_prominent | 1 | 1/1 | 1/1 | 1/1 | 0 |
| billhead | 5 | 0/5 | 1/5 | 2/5 | 1 |
| body_recounts_earlier_dates | 2 | 2/2 | 2/2 | 2/2 | 0 |
| born_digital | 2 | 2/2 | 2/2 | 2/2 | 0 |
| brand_vs_legal_name | 4 | 0/4 | 2/4 | 1/4 | 2 |
| business_letter | 1 | 1/1 | 1/1 | 1/1 | 0 |
| caption_table | 6 | 4/6 | 6/6 | 5/6 | 0 |
| caption_table_flattened | 1 | 1/1 | 1/1 | 1/1 | 0 |
| case_citations | 1 | 1/1 | 1/1 | 1/1 | 0 |
| cc_in_body | 2 | 0/2 | 2/2 | 0/2 | 2 |
| cc_list | 5 | 4/5 | 5/5 | 5/5 | 0 |
| cell_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| certificate_of_service | 3 | 2/3 | 3/3 | 2/3 | 0 |
| class_action | 1 | 1/1 | 1/1 | 1/1 | 0 |
| client_named_in_body | 1 | 0/1 | 1/1 | 1/1 | 0 |
| coloured_paper | 1 | 0/1 | 1/1 | 0/1 | 1 |
| competing_dates | 22 | 12/22 | 20/22 | 18/22 | 3 |
| copy_list | 1 | 1/1 | 1/1 | 1/1 | 0 |
| corrected_invoice | 1 | 0/1 | 1/1 | 0/1 | 1 |
| court_filing | 6 | 4/6 | 6/6 | 5/6 | 0 |
| court_letter | 2 | 2/2 | 2/2 | 2/2 | 0 |
| customer_first | 3 | 0/3 | 1/3 | 0/3 | 2 |
| date_at_end | 1 | 1/1 | 1/1 | 1/1 | 0 |
| date_at_top | 1 | 1/1 | 1/1 | 1/1 | 0 |
| date_field_trap | 1 | 0/1 | 1/1 | 0/1 | 1 |
| date_typo | 1 | 0/1 | 1/1 | 0/1 | 1 |
| dated_line_at_end | 7 | 5/7 | 7/7 | 7/7 | 0 |
| dd_mm_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| dd_month_yyyy | 1 | 1/1 | 1/1 | 1/1 | 0 |
| deadline_dates | 3 | 0/3 | 3/3 | 2/3 | 0 |
| delivery_contact | 1 | 1/1 | 1/1 | 1/1 | 0 |
| descriptive_title | 1 | 1/1 | 1/1 | 1/1 | 0 |
| doc | 4 | 2/4 | 4/4 | 2/4 | 2 |
| docx | 4 | 2/4 | 4/4 | 3/4 | 1 |
| due_date | 2 | 1/2 | 2/2 | 1/2 | 1 |
| ecf_header | 1 | 1/1 | 1/1 | 1/1 | 0 |
| ecf_header_text_only | 3 | 2/3 | 3/3 | 2/3 | 0 |
| email | 2 | 0/2 | 2/2 | 0/2 | 1 |
| enclosure_after_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| enclosures | 1 | 1/1 | 1/1 | 1/1 | 0 |
| endorsement | 1 | 0/1 | 0/1 | 0/1 | 0 |
| enforcement | 3 | 2/3 | 3/3 | 3/3 | 0 |
| established_year | 1 | 0/1 | 0/1 | 1/1 | 0 |
| fax_artifacts | 1 | 1/1 | 1/1 | 1/1 | 0 |
| fax_header | 1 | 1/1 | 1/1 | 1/1 | 0 |
| federal_register_stamp | 2 | 1/2 | 2/2 | 2/2 | 0 |
| filename_date_trap | 2 | 1/2 | 2/2 | 1/2 | 1 |
| first_name_salutation | 1 | 0/1 | 1/1 | 0/1 | 1 |
| flight_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| footnote_citation | 1 | 0/1 | 1/1 | 1/1 | 0 |
| footnotes | 2 | 1/2 | 2/2 | 2/2 | 0 |
| form_layout | 1 | 1/1 | 1/1 | 1/1 | 0 |
| handwritten | 5 | 0/5 | 1/5 | 2/5 | 0 |
| handwritten_annotation | 6 | 3/6 | 5/6 | 3/6 | 3 |
| handwritten_annotations | 1 | 0/1 | 0/1 | 1/1 | 0 |
| handwritten_salutation | 1 | 1/1 | 1/1 | 1/1 | 0 |
| historic | 6 | 0/6 | 1/6 | 2/6 | 2 |
| historical | 1 | 1/1 | 1/1 | 1/1 | 0 |
| image | 2 | 2/2 | 2/2 | 2/2 | 0 |
| in_re_caption | 1 | 1/1 | 1/1 | 1/1 | 0 |
| inline_footnotes | 1 | 1/1 | 1/1 | 1/1 | 0 |
| invoice | 11 | 6/11 | 8/11 | 7/11 | 3 |
| issuer_not_named | 1 | 1/1 | 1/1 | 1/1 | 0 |
| jpeg | 3 | 0/3 | 0/3 | 0/3 | 1 |
| letter | 25 | 11/25 | 24/25 | 16/25 | 8 |
| letter_format | 2 | 2/2 | 2/2 | 2/2 | 0 |
| letter_style | 1 | 1/1 | 1/1 | 1/1 | 0 |
| letterhead_image_only | 2 | 1/2 | 2/2 | 2/2 | 0 |
| letterhead_mismatch | 1 | 0/1 | 1/1 | 0/1 | 1 |
| letterhead_officers | 1 | 1/1 | 1/1 | 1/1 | 0 |
| line_item_dates | 5 | 1/5 | 2/5 | 2/5 | 1 |
| long_document | 2 | 2/2 | 2/2 | 2/2 | 0 |
| long_letter | 1 | 1/1 | 1/1 | 1/1 | 0 |
| many_companies_named | 1 | 0/1 | 1/1 | 0/1 | 1 |
| many_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| many_named_organisations | 1 | 1/1 | 1/1 | 1/1 | 0 |
| memo_header | 1 | 0/1 | 1/1 | 1/1 | 0 |
| metadata_date_mismatch | 1 | 0/1 | 1/1 | 0/1 | 1 |
| metadata_date_trap | 1 | 0/1 | 1/1 | 0/1 | 1 |
| msg | 2 | 0/2 | 2/2 | 0/2 | 1 |
| multi_page | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multiple_defendants | 4 | 3/4 | 4/4 | 3/4 | 0 |
| multiple_parties | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multiple_sheets | 1 | 1/1 | 1/1 | 1/1 | 0 |
| name_variant | 1 | 0/1 | 1/1 | 1/1 | 0 |
| native | 7 | 5/7 | 7/7 | 7/7 | 0 |
| native_pdf | 6 | 3/6 | 6/6 | 5/6 | 1 |
| no_dated_letterhead | 1 | 0/1 | 1/1 | 1/1 | 0 |
| no_dated_line | 1 | 0/1 | 1/1 | 0/1 | 0 |
| no_explicit_addressee | 1 | 0/1 | 1/1 | 1/1 | 0 |
| no_letterhead | 1 | 0/1 | 0/1 | 0/1 | 1 |
| no_letterhead_text | 1 | 1/1 | 1/1 | 1/1 | 0 |
| no_ocr_layer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| no_subject_line | 1 | 0/1 | 1/1 | 1/1 | 0 |
| no_text_layer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| notary_stamp | 1 | 0/1 | 1/1 | 0/1 | 0 |
| notice | 20 | 14/20 | 20/20 | 19/20 | 0 |
| notice_of_meeting | 1 | 0/1 | 1/1 | 1/1 | 0 |
| number_looks_like_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| ocr_text_layer | 1 | 0/1 | 0/1 | 1/1 | 0 |
| odt | 4 | 1/4 | 4/4 | 3/4 | 1 |
| office | 13 | 5/13 | 13/13 | 8/13 | 5 |
| old_referenced_date | 1 | 0/1 | 0/1 | 0/1 | 1 |
| ordinal_date | 1 | 0/1 | 1/1 | 1/1 | 0 |
| paid_stamp | 2 | 0/2 | 1/2 | 0/2 | 1 |
| past_due_stamp | 1 | 1/1 | 1/1 | 1/1 | 0 |
| person_addressee | 2 | 2/2 | 2/2 | 2/2 | 0 |
| person_party | 2 | 0/2 | 2/2 | 0/2 | 2 |
| pleading_paper_line_numbers | 1 | 0/1 | 1/1 | 1/1 | 0 |
| product_names | 1 | 1/1 | 1/1 | 1/1 | 0 |
| public_records_release | 3 | 1/3 | 3/3 | 1/3 | 1 |
| publication_note_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| re_line_other_matter | 2 | 2/2 | 2/2 | 2/2 | 0 |
| receipt | 1 | 0/1 | 0/1 | 0/1 | 0 |
| receipted | 1 | 0/1 | 0/1 | 0/1 | 1 |
| received_stamp | 2 | 1/2 | 2/2 | 1/2 | 1 |
| redacted | 1 | 1/1 | 1/1 | 1/1 | 0 |
| redactions | 1 | 1/1 | 1/1 | 1/1 | 0 |
| referenced_case | 1 | 0/1 | 1/1 | 1/1 | 0 |
| referenced_dates | 7 | 4/7 | 7/7 | 6/7 | 1 |
| referenced_document | 1 | 1/1 | 1/1 | 1/1 | 0 |
| regulator_correspondence | 4 | 1/4 | 3/4 | 3/4 | 1 |
| released_date | 2 | 2/2 | 2/2 | 2/2 | 0 |
| remit_to | 2 | 1/2 | 2/2 | 1/2 | 1 |
| remit_to_bank | 1 | 1/1 | 1/1 | 1/1 | 0 |
| rtf | 1 | 1/1 | 1/1 | 1/1 | 0 |
| scanned | 21 | 12/21 | 18/21 | 16/21 | 4 |
| schedules_attached | 1 | 1/1 | 1/1 | 1/1 | 0 |
| screen_printout | 1 | 1/1 | 1/1 | 1/1 | 0 |
| serial_number_looks_like_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| service_period | 1 | 1/1 | 1/1 | 1/1 | 0 |
| settling_party_differs_from_caption | 2 | 2/2 | 2/2 | 2/2 | 0 |
| signatory_vs_org | 1 | 1/1 | 1/1 | 1/1 | 0 |
| signature_page_date | 1 | 0/1 | 1/1 | 1/1 | 0 |
| sister_company_named | 1 | 0/1 | 1/1 | 1/1 | 0 |
| sole_proprietor | 1 | 0/1 | 0/1 | 1/1 | 0 |
| source_title_mismatch | 1 | 1/1 | 1/1 | 1/1 | 0 |
| staff_names | 7 | 3/7 | 5/7 | 3/7 | 2 |
| stamp_date | 2 | 1/2 | 1/2 | 2/2 | 0 |
| statement | 2 | 0/2 | 1/2 | 1/2 | 1 |
| status_log | 1 | 1/1 | 1/1 | 1/1 | 0 |
| subject_line_names_statute | 1 | 0/1 | 1/1 | 0/1 | 1 |
| subject_line_other_party | 1 | 0/1 | 1/1 | 0/1 | 1 |
| table | 1 | 1/1 | 1/1 | 1/1 | 0 |
| table_layout | 2 | 1/2 | 2/2 | 2/2 | 0 |
| termination | 1 | 1/1 | 1/1 | 1/1 | 0 |
| text | 1 | 0/1 | 1/1 | 1/1 | 0 |
| tiff | 5 | 3/5 | 5/5 | 3/5 | 2 |
| two_addressees | 3 | 2/3 | 3/3 | 2/3 | 1 |
| two_digit_year | 3 | 2/3 | 2/3 | 3/3 | 0 |
| txt | 2 | 1/2 | 2/2 | 2/2 | 0 |
| typed | 1 | 0/1 | 0/1 | 0/1 | 1 |
| uk | 9 | 5/9 | 9/9 | 6/9 | 3 |
| uk_date_format | 2 | 2/2 | 2/2 | 2/2 | 0 |
| uk_government | 7 | 2/7 | 7/7 | 3/7 | 4 |
| uk_regulator | 3 | 1/3 | 3/3 | 3/3 | 0 |
| us_federal | 1 | 0/1 | 1/1 | 1/1 | 0 |
| us_state_government | 3 | 1/3 | 3/3 | 1/3 | 1 |
| utf8_bom | 1 | 1/1 | 1/1 | 1/1 | 0 |
| vat | 1 | 1/1 | 1/1 | 1/1 | 0 |
| wmo_header | 1 | 0/1 | 1/1 | 1/1 | 0 |
| xlsx | 1 | 1/1 | 1/1 | 1/1 | 0 |
| year_in_subject | 1 | 1/1 | 1/1 | 1/1 | 0 |
| year_in_title | 1 | 0/1 | 1/1 | 0/1 | 1 |
| zero_amount | 1 | 1/1 | 1/1 | 1/1 | 0 |

## Routes

- **Pages:** fast 65 · layout 12 · ocr 68 · ocr_regions 2
- **Documents by route class:** fast 25 · layout 8 · ocr 24 · ocr_regions 2

## Where the time goes

| Stage | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `total_ms` | 59 | 72.07 s | 116.46 s | 125.97 s |
| `extraction_wall_ms` | 59 | 13.9 ms | 21.64 s | 60.32 s |
| `worker_total_ms` | 59 | 13.3 ms | 21.64 s | 60.32 s |
| `worker_snapshot_ms` | 59 | 0.27 ms | 2.0 ms | 3.2 ms |
| `worker_parse_ms` | 59 | 2.6 ms | 30.5 ms | 1.34 s |
| `worker_analysis_ms` | 59 | 0.21 ms | 1.9 ms | 15.8 ms |
| `worker_render_ms` | 59 | 0.00 ms | 931.8 ms | 6.26 s |
| `worker_image_decode_ms` | 59 | 0.00 ms | 102.0 ms | 113.3 ms |
| `worker_ocr_ms` | 59 | 0.00 ms | 21.43 s | 59.96 s |
| `worker_ocr_encode_ms` | 59 | 0.00 ms | 2.01 s | 5.52 s |
| `worker_ocr_engine_ms` | 59 | 0.00 ms | 19.31 s | 54.32 s |
| `worker_vision_ms` | 59 | 0.00 ms | 11.6 ms | 15.5 ms |
| `analyze_wall_ms` | 59 | 67.64 s | 104.61 s | 125.96 s |
| `distill_ms` | 59 | 2.8 ms | 32.9 ms | 68.9 ms |
| `prompt_ms` | 59 | 0.03 ms | 0.04 ms | 0.06 ms |
| `inference_ms` | 59 | 67.61 s | 104.55 s | 125.77 s |
| `prefill_ms` | 59 | 47.73 s | 85.90 s | 108.86 s |
| `generation_ms` | 59 | 18.61 s | 23.30 s | 27.64 s |
| `validation_ms` | 59 | 31.6 ms | 136.0 ms | 213.8 ms |
| `naming_ms` | 59 | 0.50 ms | 4.1 ms | 8.5 ms |
| `index_ms` | 59 | 2.7 ms | 30.8 ms | 65.5 ms |
| `retrieval_ms` | 59 | 0.03 ms | 1.8 ms | 3.7 ms |

| Measure | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `prefill_tok_per_s` | 59 | 16.0 tok/s | 16.3 tok/s | 16.3 tok/s |
| `generation_tok_per_s` | 59 | 5.0 tok/s | 5.1 tok/s | 5.1 tok/s |
| `prompt_tokens` | 59 | 760 | 1387 | 1754 |
| `cached_tokens` | 59 | 477 | 477 | 477 |
| `generated_tokens` | 59 | 93 | 114 | 136 |
| `estimated_prompt_tokens` | 59 | 1381 | 1987 | 2403 |
| `model_requests` | 59 | 1 | 1 | 1 |
| `redistillations` | 59 | 0 | 0 | 0 |
| `source_characters` | 59 | 2779 | 43392 | 76305 |
| `digest_characters` | 59 | 2434 | 4636 | 5214 |
| `prompt_characters` | 59 | 4483 | 6685 | 7263 |
| `worker_ocr_pages` | 59 | 0 | 7 | 18 |
| `worker_ocr_passes` | 59 | 0 | 7 | 18 |
| `worker_orientation_passes` | 59 | 0 | 7 | 18 |
| `worker_rendered_pixels` | 59 | 0 | 58905000 | 156552480 |
| `index_units` | 59 | 25 | 255 | 397 |
| `context_units` | 59 | 22 | 41 | 61 |
| `context_tokens` | 59 | 792 | 1399 | 1814 |

## Extraction time

| Route class | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fast | 25 | 2.8 ms | 13.9 ms | 2.5 ms | 13.3 ms | 11.4 ms | 0.69 ms | 0.00 ms | 0.00 ms |
| layout | 8 | 6.6 ms | 1.34 s | 5.9 ms | 1.34 s | 1.34 s | 15.8 ms | 0.00 ms | 0.00 ms |
| ocr_regions | 2 | 391.8 ms | 1.68 s | 391.3 ms | 1.68 s | 9.8 ms | 1.5 ms | 144.1 ms | 1.51 s |
| ocr | 24 | 2.70 s | 22.93 s | 2.70 s | 22.93 s | 27.1 ms | 0.98 ms | 1.03 s | 22.79 s |

| Pages | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 27 | 1.36 s | 3.97 s | 1.36 s | 3.97 s | 27.1 ms | 0.42 ms | 173.6 ms | 3.77 s |
| 2-4 | 24 | 5.7 ms | 9.19 s | 5.4 ms | 9.19 s | 9.8 ms | 1.5 ms | 584.7 ms | 8.96 s |
| 5-9 | 5 | 14.41 s | 22.93 s | 14.41 s | 22.93 s | 1.34 s | 1.6 ms | 1.03 s | 22.79 s |
| 10-24 | 2 | 173.8 ms | 60.32 s | 171.9 ms | 60.32 s | 153.9 ms | 15.8 ms | 6.26 s | 59.96 s |
| 25-49 | 1 | 17.8 ms | 17.8 ms | 16.4 ms | 16.4 ms | 16.0 ms | 0.00 ms | 0.00 ms | 0.00 ms |

| Kind | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| invoice | 11 | 1.68 s | 5.73 s | 1.68 s | 5.73 s | 30.5 ms | 4.2 ms | 159.3 ms | 5.58 s |
| letter | 25 | 8.3 ms | 12.33 s | 8.0 ms | 12.33 s | 17.9 ms | 1.6 ms | 599.5 ms | 12.14 s |
| notice | 20 | 5.7 ms | 21.64 s | 5.4 ms | 21.64 s | 16.0 ms | 1.2 ms | 931.8 ms | 21.43 s |
| receipt | 1 | 1.98 s | 1.98 s | 1.98 s | 1.98 s | 27.1 ms | 0.06 ms | 0.00 ms | 1.92 s |
| statement | 2 | 837.9 ms | 1.36 s | 837.6 ms | 1.36 s | 17.4 ms | 0.24 ms | 173.6 ms | 1.29 s |

Over the documents that completed. Wall is the runner's clock around the request; worker is the worker's own total. OCR is summed over the pages, so when the worker reads pages in parallel it can exceed the total. A document's route class is the most expensive route any of its pages took (ocr > ocr_regions > layout > fast), or `unrouted` when the worker sent no layouts.

## Memory

| Process | Typical peak (p50) | Highest peak | During |
| --- | ---: | ---: | ---: |
| Parser worker | 284 MB | 767 MB | real2-notice-02 |
| Model server | 6134 MB | 6134 MB | real2-office-15 |
| Benchmark (engine) | 15 MB | 21 MB | real2-office-15 |

Resident memory sampled every 25 ms per document; a spike shorter than that can be missed.

## Misses (28)

- **real2-letter-01**: expected `2008-12-05 Approval Letter to Cleary Gottlieb Steen & Hamilton LLP.pdf`, got `2008-12-05 Letter from Federal Reserve System.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, LOW_CONFIDENCE
- **real2-letter-04**: expected `1974-12-20 Advisory Opinion to ARP Industries, Inc.pdf`, got `1974-12-28 Letter to ARP Industries, Inc.pdf` · review: TYPE_MISSING, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, DESCRIPTION_INVALID, LOW_CONFIDENCE
- **real2-letter-05**: expected `2014-06-30 Extension Letter to PricewaterhouseCoopers LLP.pdf`, got `2014-06-30 report for London Borough of Tower Hamlets.pdf` · trap: party London Borough of Tower Hamlets (subject of the inspection, named in the subject line) · review: TYPE_UNSUPPORTED, TYPE_INFERRED
- **real2-letter-07**: expected `2018-02-09 Untitled Letter to Collegium Pharmaceutical, Inc.pdf`, got `2018-02-09 Document - Collegium Pharmaceutical, Inc.pdf` · review: TYPE_UNSUPPORTED, DATE_AMBIGUOUS, DESCRIPTION_UNSUPPORTED, LOW_CONFIDENCE
- **real2-letter-11**: expected `2022-12-14 Letter of Comfort to Low Carbon Contracts Company.pdf`, got `2022-12-14 Letter to Patrick Bibby Low Carbon Contracts Company.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED
- **real2-letter-12**: expected `2025-08-20 Guidance Letter to Pool Reinsurance Company Limited.pdf`, got `2025-08-20 Letter from Gwyneth Nurse.pdf` · trap: party Gwyneth Nurse (HM Treasury Director General who signs) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, LOW_CONFIDENCE
- **real2-letter-13**: expected `2021-12-14 Remit Letter to Armed Forces’ Pay Review Body.odt`, got `2021-12-14 Letter from BEN WALLACE.odt` · trap: party Ben Wallace (Secretary of State who signs) · review: TYPE_MISSING, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real2-notice-05**: expected `2008-01-22 Notice of Entry of Order between American Service Insurance Company and NAFTA General Agency.pdf`, got `2008-01-22 Notice of Entry of Order for Nafta General Agency.pdf` · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real2-notice-07**: expected `2003-10-20 Notice of Related Action between Synopsys, Inc and Ricoh Company, Ltd.pdf`, got `2003-10-20 Notice of Related Action Pending in the Northern District of California for Ricoh Company, Ltd.pdf` · review: PARTY_UNSUPPORTED
- **real2-notice-10**: expected `2024-06-12 Notice of Technical Conference for Stingray Pipeline Company, L.L.C.pdf`, got `2024-06-12 Document from Federal Energy Regulatory Commission.pdf` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED
- **real2-invoice-01**: expected `1995-12-04 Ticket Subscription Invoice from USTA.tif`, got `1995-12-04 1996 Ticket Subscription Invoice from Philip Morris.tif` · trap: party Philip Morris (customer (account name), not the issuer) · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real2-invoice-03**: expected `1996-02-15 Statement from The Hearst Corporation.tif`, got `1996-02-15 Service Center Statement for Philip Morris USA.tif` · trap: party Philip Morris USA (bill-to customer, not the issuer) · **filed without review**
- **real2-invoice-06**: expected `1882-10-01 Bill from Charles Williams, Jr.jpg`, got `Bill from M Chrof. A. b. Bill.jpg` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, DATE_UNSUPPORTED, DESCRIPTION_INVALID, PARSER_WARNING, LOW_CONFIDENCE
- **real2-invoice-07**: expected `1897-01-02 Bill from Pollok & Mauro.jpg`, got `To bill rendered Feby.16, 1891 from Alexander Graham Bell, Esq.jpg` · trap: party Alexander Graham Bell (client billed, printed first) · review: DATE_UNSUPPORTED
- **real2-invoice-08**: expected `1864-12-31 Receipt from The United States Telegraph Company.jpg`, got `Document.jpg` · review: TYPE_MISSING, DATE_MISSING, DESCRIPTION_UNSUPPORTED, DESCRIPTION_INVALID, PARSER_WARNING
- **real2-invoice-10**: expected `1923-11-22 Invoice from Times-Mirror Printing & Binding House.pdf`, got `1923-11-22 Corrected Invoice from Chas F Lummis.pdf` · trap: party Chas F Lummis (customer, typed above the letterhead) · review: DATE_UNSUPPORTED
- **real2-invoice-11**: expected `1920-01-13 Statement from Grace Bros. Brewing Co.pdf`, got `Statement from GRACE BrOS., Inc.pdf` · review: DATE_UNSUPPORTED, PARTY_UNSUPPORTED, DESCRIPTION_INVALID, LOW_CONFIDENCE
- **real2-invoice-12**: expected `1895-12-09 Bill from Geo. P. McNear.pdf`, got `Document - GEO. P. MCNEAR.pdf` · review: TYPE_MISSING, DATE_UNSUPPORTED, DESCRIPTION_INVALID, LOW_CONFIDENCE
- **real2-office-01**: expected `2023-06-22 Request Letter to Ofsted.docx`, got `2023-06-22 Letter to Amanda Spielman.docx` · trap: party Amanda Spielman (individual Chief Inspector addressed; the organisation is Ofsted) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real2-office-04**: expected `2014-11-17 Announcement of Consultation from Environment Agency.docx`, got `2014-11-17 Environmental Assessment of Plans and Programmes Regulations from Environment Agency.docx` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, PARTY_UNSUPPORTED
- **real2-office-06**: expected `2019-10-24 Response Letter to ONS.odt`, got `2019-10-24 Engagement on Adjustment of Migration Statistics from Migration Advisory Committee.odt` · review: PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED
- **real2-office-07**: expected `2024-03-28 Response Letter to Welsh Government.odt`, got `2024-03-28 Letter from Liz Kendall.odt` · trap: party Liz Kendall (Secretary of State who signs) · review: TYPE_MISSING, PARTY_UNSUPPORTED
- **real2-office-08**: expected `2026-01-29 Notice of Proposal to Modify Definitive Map Order for North Yorkshire Council.odt`, got `2026-01-29 Notice of Proposal to Modify Definitive Map Order from North Yorkshire Council.odt` · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real2-office-10**: expected `2011-07-19 Response Letter to John Mann MP.doc`, got `2011-07-19 Letter to SIR GUS O'DONNELL KCB.doc` · trap: party Gus O'Donnell (Cabinet Secretary who signs) · review: TYPE_MISSING, PARTY_UNSUPPORTED
- **real2-office-11**: expected `2013-04-08 Advice Letter to Lord Strathclyde CH PC.doc`, got `2013-04-08 Document - Lord Lang of Monkton.doc` · trap: party Lord Lang of Monkton (committee chairman who signs) · review: TYPE_UNSUPPORTED, LOW_CONFIDENCE
- **real2-office-13**: expected `2016-04-05 Email to NFPA.msg`, got `2016-04-05 2016 California Electrical Code Publication Agreement between NFPA and Department of General Services.msg` · **filed without review**
- **real2-office-14**: expected `2016-06-21 Email to ICC.msg`, got `2016-06-21 Guide to the - Mark Johnson.msg` · trap: party Mark Johnson (ICC staff member addressed) · review: LOW_CONFIDENCE
- **real2-office-15**: expected `2024-06-21 Public Information Statement from National Weather Service.txt`, got `2024-06-21 Public Information Statement from National Weather Service Headquarters Silver Spring MD.txt` · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE

## How to compare

Keep this run's JSON, make the change, run again, then:

```text
intern-bench compare --before before.json --after after.json --markdown diff.md
```

It recomputes every rate and count over the documents both runs scored, lists each document whose score flipped, and gives the change in p50/p95 of every stage over the documents both completed - between two live runs only, since a replay's timings are its recording's. `intern-bench report --input report.json --markdown report.md` re-renders this page from the JSON.
