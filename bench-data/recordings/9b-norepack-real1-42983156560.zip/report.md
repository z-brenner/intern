# InternBench: live run

- **Run:** 2026-11-11T08:00:19Z · commit `0c8d3295d9`
- **Machine:** AMD EPYC 9V45 96-Core Processor, 4 logical cores, 15.6 GB RAM, linux (Ubuntu 24.04.5 LTS)
- **Model:** `intern-local` · 5.68 GB · sha256 `03b74727a860`
- **Corpus:** 58 documents · 58 completed · gold `3a6d11e305`
- **Wall time:** 2085.67 s for the whole run, the worker's start included

## Scorecard

| Score | Result |
| --- | ---: |
| Filename (the whole name) | 30/56 (53.6%) |
| Document type | 47/58 (81.0%) |
| Date | 47/57 (82.5%) |
| Date role (when the reviewed date was chosen) | 14/46 (30.4%) |
| Parties | 42/58 (72.4%) |
| Relation word (when parties were named) | 41/53 (77.4%) |
| Party in the right role (when parties were named) | 17/27 (63.0%) |
| Ready / review routing | 10/43 (23.3%) |
| Description states nothing false | 58/58 (100.0%) |
| Description is specific | 47/58 (81.0%) |
| Description specificity | 67.8% (mean of 58) |
| Evidence recall (model's quotes) | 63.2% (mean of 58) |
| Digest recall (facts reaching the digest) | 86.7% (mean of 58) |
| Prompt recall (facts reaching the prompt sent) | 86.7% (mean of 58) |
| Sent to review | 84.5% of 58 completed |

## Phase 3 scorecard

| Figure | Value | Docs |
| --- | ---: | ---: |
| Long-document filename accuracy (10+ pages) | 50.0% | 4 |
| Complex-document filename accuracy | – | 0 |
| Description completeness | – | 0 |
| Unsupported-fact rate (documents) | 58.6% | 58 |
| Review rate | 84.5% | 58 |
| Evidence recall | 63.2% | 58 |
| Total latency p50 | 33.86 s | 58 |
| Total latency p95 | 60.46 s | 58 |
| Generation latency p50 | 16.26 s | 58 |
| Generation latency p95 | 21.51 s | 58 |
| Generated tokens p50 | 94 | 58 |
| Generated tokens p95 | 122 | 58 |
| Prompt tokens p50 | 919 | 58 |

Long: 10 pages or more. Complex: any of `referenced_agreement`, `middle_fact`, `multi_column`, `layout_parties`, `irrelevant_names`, `information_dense`, `stream_order`, `date_in_table`, `key_value`, `complex_pdf`. Unsupported-fact rate: documents with any `*_UNSUPPORTED` review reason. Latency and tokens over the documents that completed.

## Safety

| Check | Count |
| --- | ---: |
| Filed without review under a wrong name | 0 of 56 |
| Trap date chosen | 6 of 58 |
| Forbidden party named | 4 of 58 |
| Spurious parties named | 8 |
| Description states a known-wrong fact | 0 |
| Unsupported description claims | 0 of 133 (0.0%) |
| Right name sent to review anyway | 19 of 41 |
| Sent to review for an unsupported fact | 34 of 58 |

## By kind

| Kind | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| invoice | 17 | 10/16 | 12/17 | 10/17 | 4/13 | 76.5% | 29.75 s | 48.99 s |
| letter | 20 | 10/19 | 18/19 | 17/20 | 1/13 | 100.0% | 33.86 s | 60.46 s |
| notice | 18 | 10/18 | 16/18 | 14/18 | 5/17 | 72.2% | 38.01 s | 60.93 s |
| receipt | 2 | 0/2 | 0/2 | 0/2 | – | 100.0% | 8.22 s | 13.60 s |
| statement | 1 | 0/1 | 1/1 | 1/1 | – | 100.0% | 50.17 s | 50.17 s |

## By text layer

| Text layer | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| image | 9 | 2/8 | 3/9 | 2/9 | 2/4 | 88.9% | 13.60 s | 37.64 s |
| native | 17 | 9/17 | 14/17 | 12/17 | 3/13 | 76.5% | 36.55 s | 51.13 s |
| office | 14 | 11/14 | 14/14 | 13/14 | 2/11 | 85.7% | 30.98 s | 50.17 s |
| scan | 12 | 4/12 | 11/12 | 9/12 | 0/10 | 100.0% | 42.47 s | 85.23 s |
| text | 6 | 4/5 | 5/5 | 6/6 | 3/5 | 66.7% | 31.81 s | 47.88 s |

## By page count

| Pages | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 22 | 9/20 | 14/21 | 12/22 | 6/14 | 81.8% | 26.82 s | 47.88 s |
| 2-4 | 27 | 15/27 | 25/27 | 21/27 | 2/21 | 88.9% | 37.40 s | 50.17 s |
| 5-9 | 5 | 4/5 | 5/5 | 5/5 | 1/5 | 80.0% | 38.89 s | 60.46 s |
| 10-24 | 4 | 2/4 | 3/4 | 4/4 | 1/3 | 75.0% | 47.29 s | 85.23 s |

## By slice

| Slice | Docs | Filename | Date | Parties | Routing | Unsafe ready | p50 total | p95 total | p50 generation | p95 generation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| long | 4 | 2/4 | 3/4 | 4/4 | 1/3 | 0 of 4 | 47.29 s | 85.23 s | 16.48 s | 24.47 s |

`long`: 10 pages or more. `complex`: any of the categories listed under the phase 3 scorecard. A document may be in both.

## By challenge

| Category | Docs | Filename | Date | Parties | Traps sprung |
| --- | ---: | ---: | ---: | ---: | ---: |
| addressed_to_company | 1 | 1/1 | 1/1 | 1/1 | 0 |
| addressed_to_counsel | 3 | 2/2 | 2/2 | 3/3 | 1 |
| addressed_to_government | 3 | 0/3 | 3/3 | 3/3 | 0 |
| adopted_vs_released | 1 | 1/1 | 1/1 | 1/1 | 0 |
| agency_billing | 4 | 2/4 | 3/4 | 2/4 | 2 |
| agency_in_account_with | 1 | 1/1 | 1/1 | 1/1 | 0 |
| agency_published_sample | 1 | 1/1 | 1/1 | 1/1 | 0 |
| agent_trap | 1 | 1/1 | 1/1 | 1/1 | 0 |
| aging_table | 1 | 0/1 | 1/1 | 1/1 | 0 |
| annex_table | 1 | 1/1 | 1/1 | 1/1 | 0 |
| appended_statements | 1 | 1/1 | 1/1 | 1/1 | 0 |
| approval_letter | 2 | 0/2 | 1/2 | 2/2 | 1 |
| as_of_date | 1 | 0/1 | 1/1 | 1/1 | 0 |
| attachment_note | 2 | 1/2 | 2/2 | 1/2 | 1 |
| automated_notice | 1 | 0/1 | 1/1 | 1/1 | 0 |
| bankruptcy | 3 | 0/3 | 3/3 | 2/3 | 1 |
| blank_date | 1 | – | 0/1 | 0/1 | 0 |
| born_digital | 16 | 8/16 | 13/16 | 11/16 | 5 |
| business_review_letter | 1 | 1/1 | 1/1 | 1/1 | 0 |
| c_o_customer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| caption_block | 1 | 1/1 | 1/1 | 1/1 | 0 |
| caption_trap | 1 | 0/1 | 0/1 | 0/1 | 0 |
| case_number | 1 | 1/1 | 1/1 | 1/1 | 0 |
| catalogue_date_trap | 1 | 0/1 | 0/1 | 0/1 | 0 |
| cc_list | 2 | 0/2 | 1/2 | 2/2 | 1 |
| company_letterhead | 1 | 0/1 | 1/1 | 1/1 | 0 |
| competing_dates | 43 | 23/42 | 35/42 | 32/43 | 9 |
| consolidated_captions | 1 | 1/1 | 1/1 | 1/1 | 0 |
| court_filed_letter | 1 | 0/1 | 1/1 | 0/1 | 1 |
| court_filing | 11 | 5/11 | 10/11 | 7/11 | 2 |
| da_number | 3 | 2/2 | 2/2 | 3/3 | 1 |
| damaged | 1 | 0/1 | 0/1 | 0/1 | 0 |
| dataset_footer_trap | 1 | 0/1 | 1/1 | 1/1 | 0 |
| date_at_end | 1 | 0/1 | 0/1 | 1/1 | 1 |
| date_only_in_digital_signature | 1 | 0/1 | 0/1 | 1/1 | 1 |
| date_repeated_in_page_headers | 3 | 1/3 | 3/3 | 2/3 | 1 |
| date_stamp | 1 | 0/1 | 1/1 | 1/1 | 0 |
| dd_mm_date | 1 | 0/1 | 0/1 | 1/1 | 1 |
| deadline_trap | 1 | 0/1 | 1/1 | 0/1 | 1 |
| dual_salutation | 1 | 1/1 | 1/1 | 1/1 | 0 |
| due_date_trap | 2 | 2/2 | 2/2 | 2/2 | 0 |
| ecf_header | 5 | 3/5 | 4/5 | 3/5 | 2 |
| ecf_header_stamp | 1 | 0/1 | 1/1 | 0/1 | 1 |
| email | 1 | 0/1 | 1/1 | 1/1 | 0 |
| email_addresses | 1 | 0/1 | 0/1 | 1/1 | 1 |
| email_printout | 1 | 1/1 | 1/1 | 1/1 | 0 |
| eml | 1 | 0/1 | 1/1 | 1/1 | 0 |
| enron | 7 | 4/7 | 7/7 | 7/7 | 0 |
| exhibit_attached | 2 | 1/2 | 2/2 | 2/2 | 0 |
| faint | 1 | 0/1 | 0/1 | 0/1 | 0 |
| first_name_salutation | 1 | 1/1 | 1/1 | 1/1 | 0 |
| footer_codes | 1 | 1/1 | 1/1 | 1/1 | 0 |
| footnotes | 3 | 1/3 | 3/3 | 3/3 | 0 |
| footnotes_inline | 1 | 1/1 | 1/1 | 1/1 | 0 |
| form | 2 | 0/2 | 1/2 | 0/2 | 1 |
| former_company_name | 1 | 1/1 | 1/1 | 1/1 | 0 |
| government | 7 | 6/7 | 6/7 | 7/7 | 1 |
| government_issuer | 1 | 0/1 | 1/1 | 0/1 | 1 |
| government_party | 1 | 0/1 | 0/1 | 0/1 | 1 |
| government_regulator | 3 | 3/3 | 3/3 | 3/3 | 0 |
| government_sender | 8 | 4/7 | 6/7 | 7/8 | 2 |
| handwritten | 7 | 1/6 | 2/7 | 1/7 | 1 |
| handwritten_signature | 5 | 2/5 | 5/5 | 3/5 | 0 |
| hearing_date_banner | 1 | 0/1 | 1/1 | 1/1 | 0 |
| historical | 5 | 0/4 | 0/5 | 0/5 | 1 |
| illegible_labels | 1 | 0/1 | 1/1 | 0/1 | 0 |
| image | 9 | 2/8 | 3/9 | 2/9 | 1 |
| in_re_caption | 3 | 0/3 | 3/3 | 2/3 | 1 |
| inconsistent_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| inline_footnotes | 1 | 1/1 | 1/1 | 1/1 | 0 |
| invoice | 17 | 10/16 | 12/17 | 10/17 | 3 |
| invoice_number_looks_like_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| invoice_reference | 1 | 0/1 | 1/1 | 1/1 | 0 |
| issuer_ambiguity | 1 | 0/1 | 0/1 | 0/1 | 0 |
| issuer_in_remit_to | 1 | 1/1 | 1/1 | 1/1 | 0 |
| large_image | 1 | 0/1 | 0/1 | 0/1 | 0 |
| law_firm_letterhead | 2 | 0/2 | 2/2 | 1/2 | 1 |
| letter | 21 | 11/20 | 19/20 | 18/21 | 4 |
| letter_in_spreadsheet | 1 | 0/1 | 1/1 | 1/1 | 0 |
| letter_to_judge | 1 | 0/1 | 1/1 | 0/1 | 1 |
| letterhead_issuer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| logo_only_issuer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| long_document | 4 | 2/4 | 3/4 | 4/4 | 1 |
| long_lines | 1 | – | – | 1/1 | 1 |
| many_attorneys | 3 | 2/3 | 3/3 | 3/3 | 0 |
| many_dates | 6 | 3/6 | 5/6 | 4/6 | 2 |
| many_deadlines | 1 | 1/1 | 1/1 | 1/1 | 0 |
| memo_endorsed | 1 | 0/1 | 1/1 | 0/1 | 1 |
| metadata_date_trap | 5 | 4/5 | 5/5 | 5/5 | 0 |
| minimal_address_block | 1 | 0/1 | 1/1 | 0/1 | 0 |
| missing_date | 1 | – | – | 1/1 | 1 |
| missing_letterhead | 1 | – | – | 1/1 | 1 |
| missing_logo | 1 | 1/1 | 1/1 | 1/1 | 0 |
| modern | 4 | 2/4 | 3/4 | 2/4 | 2 |
| multi_frame | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multi_page | 6 | 4/6 | 5/6 | 5/6 | 2 |
| multi_sheet | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multiple_addressees | 1 | 0/1 | 1/1 | 1/1 | 0 |
| multiple_defendants | 4 | 2/4 | 4/4 | 2/4 | 0 |
| multiple_plaintiffs | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multiple_signers | 1 | 1/1 | 1/1 | 1/1 | 0 |
| needs_review | 1 | – | 0/1 | 0/1 | 0 |
| network_logo | 1 | 1/1 | 1/1 | 1/1 | 0 |
| no_explicit_title | 4 | 0/4 | 0/4 | 0/4 | 1 |
| no_invoice_date_field | 1 | 1/1 | 1/1 | 1/1 | 0 |
| no_letterhead | 1 | 0/1 | 1/1 | 1/1 | 0 |
| no_salutation | 1 | 0/1 | 1/1 | 0/1 | 0 |
| no_typed_date | 1 | 0/1 | 0/1 | 1/1 | 1 |
| no_typed_signature | 1 | 0/1 | 1/1 | 1/1 | 0 |
| non_ascii_party | 1 | 1/1 | 1/1 | 1/1 | 0 |
| non_utf8_encoding | 1 | 1/1 | 1/1 | 1/1 | 0 |
| notice | 18 | 10/18 | 16/18 | 14/18 | 3 |
| numeric_date | 1 | 0/1 | 0/1 | 0/1 | 0 |
| odd_text_spacing | 1 | 0/1 | 1/1 | 0/1 | 1 |
| odt | 1 | 1/1 | 1/1 | 1/1 | 0 |
| office_format | 8 | 7/8 | 8/8 | 7/8 | 1 |
| office_holder_addressee | 1 | 1/1 | 1/1 | 1/1 | 0 |
| one_page | 2 | 0/2 | 1/2 | 0/2 | 1 |
| ordinal_dates | 1 | 0/1 | 1/1 | 0/1 | 0 |
| organisation_sender | 1 | 1/1 | 1/1 | 1/1 | 0 |
| parent_company_mention | 1 | 0/1 | 1/1 | 0/1 | 0 |
| parent_company_trap | 1 | 1/1 | 1/1 | 1/1 | 0 |
| payment_stub | 1 | 1/1 | 1/1 | 1/1 | 0 |
| penalty | 1 | 1/1 | 1/1 | 1/1 | 0 |
| period_only_date | 1 | – | 0/1 | 0/1 | 0 |
| person_in_letterhead | 1 | 1/1 | 1/1 | 1/1 | 0 |
| placeholder_data | 1 | 1/1 | 1/1 | 1/1 | 0 |
| placeholder_defendants | 1 | 0/1 | 1/1 | 0/1 | 0 |
| plain_text | 5 | 4/4 | 4/4 | 5/5 | 1 |
| published_sample | 1 | 1/1 | 1/1 | 1/1 | 0 |
| re_line_names_client | 1 | 1/1 | 1/1 | 1/1 | 0 |
| receipt | 2 | 0/2 | 0/2 | 0/2 | 0 |
| redacted | 1 | 1/1 | 1/1 | 1/1 | 0 |
| references_other_letter | 1 | 0/1 | 1/1 | 1/1 | 0 |
| register_tape | 1 | 0/1 | 0/1 | 0/1 | 0 |
| regulatory_penalty | 3 | 2/3 | 2/3 | 3/3 | 1 |
| release_date_equals_letter_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| request_letter | 2 | 0/2 | 2/2 | 2/2 | 0 |
| response_letter | 2 | 1/2 | 2/2 | 2/2 | 0 |
| rtf | 1 | 1/1 | 1/1 | 1/1 | 0 |
| scanned | 15 | 6/15 | 14/15 | 11/15 | 2 |
| secretariat_trap | 1 | 1/1 | 1/1 | 1/1 | 0 |
| sender_in_from_line | 1 | 0/1 | 1/1 | 0/1 | 0 |
| service_period_trap | 2 | 2/2 | 2/2 | 2/2 | 0 |
| short | 2 | 2/2 | 2/2 | 2/2 | 0 |
| signatory_trap | 9 | 7/9 | 9/9 | 8/9 | 1 |
| signed_for | 1 | 0/1 | 1/1 | 1/1 | 0 |
| spreadsheet | 6 | 4/6 | 6/6 | 6/6 | 0 |
| staff_names | 2 | 1/2 | 2/2 | 2/2 | 0 |
| stamp | 7 | 4/7 | 5/7 | 4/7 | 1 |
| statement | 1 | 0/1 | 1/1 | 1/1 | 0 |
| stylised_letterhead | 1 | 1/1 | 1/1 | 1/1 | 0 |
| tabular | 2 | 1/2 | 1/2 | 1/2 | 2 |
| tax | 1 | 1/1 | 1/1 | 1/1 | 0 |
| text_date_cell | 1 | 1/1 | 1/1 | 1/1 | 0 |
| third_party | 1 | 1/1 | 1/1 | 1/1 | 0 |
| third_party_stamp | 2 | 2/2 | 2/2 | 2/2 | 0 |
| timezone_headers | 1 | 0/1 | 1/1 | 1/1 | 0 |
| titled_letter | 1 | 1/1 | 1/1 | 1/1 | 0 |
| two_addressees | 1 | 1/1 | 1/1 | 1/1 | 0 |
| two_senders | 1 | 0/1 | 1/1 | 0/1 | 1 |
| type_trap | 1 | 0/1 | 1/1 | 1/1 | 0 |
| typed | 1 | 1/1 | 1/1 | 1/1 | 0 |
| uk | 3 | 1/3 | 2/3 | 2/3 | 1 |
| uk_date_format | 2 | 1/2 | 2/2 | 1/2 | 0 |
| unsigned_department_signoff | 1 | 1/1 | 1/1 | 1/1 | 0 |
| untitled_document | 1 | 0/1 | 1/1 | 1/1 | 0 |
| utf8_bom | 1 | – | – | 1/1 | 1 |
| warning_letter | 1 | 1/1 | 1/1 | 1/1 | 0 |
| watermark | 2 | 1/2 | 2/2 | 1/2 | 0 |
| word_doc_legacy | 2 | 2/2 | 2/2 | 2/2 | 0 |
| word_docx | 4 | 3/4 | 4/4 | 3/4 | 1 |
| xls | 6 | 4/6 | 6/6 | 6/6 | 0 |

## Routes

- **Pages:** fast 66 · layout 18 · ocr 75 · ocr_regions 10
- **Documents by route class:** fast 27 · layout 9 · ocr 21 · ocr_regions 1

## Where the time goes

| Stage | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `total_ms` | 58 | 33.86 s | 60.46 s | 85.23 s |
| `extraction_wall_ms` | 58 | 5.3 ms | 14.28 s | 48.75 s |
| `worker_total_ms` | 58 | 4.9 ms | 14.28 s | 48.75 s |
| `worker_snapshot_ms` | 58 | 0.23 ms | 1.3 ms | 3.4 ms |
| `worker_parse_ms` | 58 | 2.0 ms | 29.1 ms | 61.3 ms |
| `worker_analysis_ms` | 58 | 0.21 ms | 3.3 ms | 13.9 ms |
| `worker_render_ms` | 58 | 0.00 ms | 846.7 ms | 1.93 s |
| `worker_image_decode_ms` | 58 | 0.00 ms | 62.3 ms | 427.6 ms |
| `worker_ocr_ms` | 58 | 0.00 ms | 14.18 s | 48.62 s |
| `worker_ocr_encode_ms` | 58 | 0.00 ms | 1.35 s | 4.25 s |
| `worker_ocr_engine_ms` | 58 | 0.00 ms | 12.77 s | 44.27 s |
| `worker_vision_ms` | 58 | 0.00 ms | 5.1 ms | 24.0 ms |
| `analyze_wall_ms` | 58 | 33.86 s | 48.99 s | 51.13 s |
| `distill_ms` | 58 | 2.7 ms | 40.3 ms | 77.8 ms |
| `prompt_ms` | 58 | 0.03 ms | 0.04 ms | 0.05 ms |
| `inference_ms` | 58 | 33.84 s | 48.95 s | 51.07 s |
| `prefill_ms` | 58 | 15.25 s | 32.36 s | 33.89 s |
| `generation_ms` | 58 | 16.26 s | 21.51 s | 24.47 s |
| `validation_ms` | 58 | 25.5 ms | 82.1 ms | 143.7 ms |
| `naming_ms` | 58 | 0.49 ms | 3.8 ms | 6.6 ms |
| `index_ms` | 58 | 2.6 ms | 51.5 ms | 76.0 ms |
| `retrieval_ms` | 58 | 0.03 ms | 1.9 ms | 5.1 ms |

| Measure | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `prefill_tok_per_s` | 58 | 58.5 tok/s | 60.6 tok/s | 61.7 tok/s |
| `generation_tok_per_s` | 58 | 5.8 tok/s | 6.1 tok/s | 6.2 tok/s |
| `prompt_tokens` | 58 | 919 | 1921 | 1967 |
| `cached_tokens` | 58 | 477 | 497 | 497 |
| `generated_tokens` | 58 | 94 | 122 | 144 |
| `estimated_prompt_tokens` | 58 | 1481 | 2236 | 2693 |
| `model_requests` | 58 | 1 | 1 | 1 |
| `redistillations` | 58 | 0 | 0 | 0 |
| `source_characters` | 58 | 3209 | 55143 | 91065 |
| `digest_characters` | 58 | 2624 | 4986 | 6172 |
| `prompt_characters` | 58 | 4673 | 7035 | 8226 |
| `worker_ocr_pages` | 58 | 0 | 10 | 23 |
| `worker_ocr_passes` | 58 | 0 | 10 | 23 |
| `worker_orientation_passes` | 58 | 0 | 10 | 23 |
| `worker_rendered_pixels` | 58 | 0 | 84150000 | 193545000 |
| `index_units` | 58 | 37 | 307 | 781 |
| `context_units` | 58 | 28 | 52 | 71 |
| `context_tokens` | 58 | 894 | 1648 | 2104 |

## Extraction time

| Route class | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fast | 27 | 2.2 ms | 43.3 ms | 1.8 ms | 42.9 ms | 41.8 ms | 0.57 ms | 0.00 ms | 0.00 ms |
| layout | 9 | 5.3 ms | 17.9 ms | 4.9 ms | 17.3 ms | 14.0 ms | 3.3 ms | 0.00 ms | 0.00 ms |
| ocr_regions | 1 | 12.00 s | 12.00 s | 12.00 s | 12.00 s | 14.0 ms | 13.9 ms | 671.7 ms | 11.88 s |
| ocr | 21 | 2.15 s | 22.11 s | 2.14 s | 22.11 s | 26.4 ms | 2.0 ms | 1.23 s | 21.98 s |

| Pages | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 22 | 2.2 ms | 1.40 s | 1.9 ms | 1.40 s | 21.3 ms | 0.40 ms | 0.00 ms | 1.34 s |
| 2-4 | 27 | 9.0 ms | 4.78 s | 8.1 ms | 4.78 s | 41.8 ms | 2.3 ms | 440.9 ms | 4.61 s |
| 5-9 | 5 | 5.3 ms | 22.11 s | 4.0 ms | 22.11 s | 8.5 ms | 2.1 ms | 835.3 ms | 21.98 s |
| 10-24 | 4 | 12.00 s | 48.75 s | 12.00 s | 48.75 s | 27.8 ms | 13.9 ms | 1.93 s | 48.62 s |

| Kind | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| invoice | 17 | 643.2 ms | 12.00 s | 642.8 ms | 12.00 s | 29.1 ms | 13.9 ms | 846.7 ms | 11.88 s |
| letter | 20 | 4.4 ms | 22.11 s | 4.0 ms | 22.11 s | 41.8 ms | 1.7 ms | 835.3 ms | 21.98 s |
| notice | 18 | 4.1 ms | 14.28 s | 3.8 ms | 14.28 s | 27.8 ms | 3.5 ms | 1.23 s | 14.18 s |
| receipt | 2 | 435.4 ms | 1.04 s | 435.1 ms | 1.04 s | 16.0 ms | 0.08 ms | 0.00 ms | 961.4 ms |
| statement | 1 | 1.9 ms | 1.9 ms | 1.4 ms | 1.4 ms | 1.1 ms | 0.00 ms | 0.00 ms | 0.00 ms |

Over the documents that completed. Wall is the runner's clock around the request; worker is the worker's own total. OCR is summed over the pages, so when the worker reads pages in parallel it can exceed the total. A document's route class is the most expensive route any of its pages took (ocr > ocr_regions > layout > fast), or `unrouted` when the worker sent no layouts.

## Memory

| Process | Typical peak (p50) | Highest peak | During |
| --- | ---: | ---: | ---: |
| Parser worker | 280 MB | 798 MB | real-invoice-13 |
| Model server | 6134 MB | 6184 MB | real-invoice-08 |
| Benchmark (engine) | 16 MB | 20 MB | real-office-15 |

Resident memory sampled every 25 ms per document; a spike shorter than that can be missed.

## Misses (26)

- **real-letter-02**: expected `2012-06-19 Business Review Request Letter to U.S. Department of Justice, Antitrust Division.pdf`, got `2012-06-19 Letter to Antitrust Division.pdf` · review: TYPE_MISSING, LOW_CONFIDENCE
- **real-letter-03**: expected `2012-11-30 Business Review Request Letter to U.S. Department of Justice, Antitrust Division.pdf`, got `2012-11-30 Letter to Department of Justice.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING
- **real-letter-04**: expected `2011-04-27 Approval of Closure Plan to Kincaid Project Group, Inc.pdf`, got `2011-04-27 EPA Approval of Closure Plan for Kincaid Project Group. Inc.pdf` · review: LOW_CONFIDENCE
- **real-letter-06**: expected `2018-03-08 Response Letter to Pipeline and Hazardous Materials Safety Administration.pdf`, got `2018-03-08 Letter from Toledo Refining Company LLC.pdf` · review: TYPE_MISSING
- **real-letter-07**: expected `2025-04-28 Approval of SEP Completion Report to TPWR Developer, LLC.pdf`, got `2025-03-14 Letter to TPWR Developer, LLC.pdf` · trap: date 2025-03-14 (second amendment of the report) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, LOW_CONFIDENCE
- **real-letter-10**: expected `2022-06-22 Public Letter to Tarmac.pdf`, got `2022-06-22 Letter from CMA.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED
- **real-letter-12**: expected `2024-05-21 Letter to Explain the Need for Redactions.pdf`, got `2024-05-21 Letter to Explain the Need for Redactions to Hon. Jessica G. L. Clarke.pdf` · trap: party Jessica G. L. Clarke (judge to whom it is addressed and who endorses it) · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real-notice-02**: expected `2009-10-13 Notice of Appeal between Sompo Japan Insurance Company of America and Norfolk Southern Railway Company.pdf`, got `2009-10-13 Notice of Appeal to Norfolk Southern Railway Company.pdf` · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real-notice-04**: expected `2009-11-02 Notice of Dismissal between Luxo AS and The Walt Disney Company.pdf`, got `2009-11-02 Notice of Dismissal for LUXO AS.pdf` · review: PARTY_UNSUPPORTED
- **real-notice-05**: expected `2006-10-25 Notice of Appearance and Demand for Notices and Papers for Delta Mills, Inc.pdf`, got `2006-10-25 Notice of Appearance and Demand for Notices and Papers for Official Committee of Unsecured Creditors.pdf` · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real-notice-07**: expected `2024-08-09 Notice of Appeal between Phoenix Metal Co., Ltd and United States.pdf`, got `2024-06-10 Notice of Appeal for Phoenix Metal Co., Ltd.pdf` · trap: date 2024-06-10 (date of the final judgment or order being appealed) · review: DATE_AMBIGUOUS
- **real-notice-10**: expected `2011-10-05 Notice of Hearing for GSC Group, Inc.pdf`, got `2011-10-05 Notice of Hearing for GSC Recovery IIA GP, L.P.pdf` · review: PARTY_UNSUPPORTED
- **real-notice-11**: expected `2005-02-15 Notice of Appointment of Official Committee of Unsecured Creditors for Tile Outlet, Inc.pdf`, got `2005-02-15 Notice of Appointment of Official Committee of Unsecured Creditors from QEP Inc.pdf` · trap: party QEP Inc. (committee member, not the subject) · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real-notice-13**: expected `2025-12-10 Final Enforcement Notice for Euro Car Parks Limited.pdf`, got `2025-10-20 Document from Competition and Markets Authority.pdf` · trap: date 2025-10-20 (date of the CMA's provisional notice) · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED
- **real-invoice-01**: expected `1898-12-30 Invoice from Woodworth & Co.jpg`, got `1898-12-31 Document - WOODWRTH&CO.jpg` · trap: date 1898-12-31 (PAID stamp (payment date)) · review: TYPE_UNSUPPORTED, DATE_IMPLAUSIBLE, PARSER_WARNING, LOW_CONFIDENCE
- **real-invoice-02**: expected `1897-07-31 Invoice from Jacoby Brothers.jpg`, got `Document.jpg` · review: TYPE_MISSING, DATE_MISSING
- **real-invoice-03**: expected `1882-07-21 Invoice from Deming, Palmer & Co.jpg`, got `List of Articles.jpg` · review: TYPE_INFERRED, DATE_MISSING, DESCRIPTION_INVALID
- **real-invoice-04**: expected `1859-01-13 Receipt from Leesburg Washingtonian.jpg`, got `Document - Dr.jpg` · review: TYPE_MISSING, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, DESCRIPTION_INVALID, PARSER_WARNING, LOW_CONFIDENCE
- **real-invoice-05**: expected `1983-02-06 Receipt from Snyder Drug.jpg`, got `Document.jpg` · review: TYPE_MISSING, DATE_MISSING, DESCRIPTION_INVALID, PARSER_WARNING
- **real-invoice-07**: expected `1996-08-28 Invoice from Vernon Computer Rentals & Leasing.tif`, got `1996-08-28 Document from Vernon Computer Rentals & Leaging.tif` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED
- **real-invoice-12**: expected `2012-10-28 Official Billing Invoice from WPXI.pdf`, got `2012-10-29 Pittsburgh (WPXI) OFFICIAL BILLING INVOICE from Main Street Media Group.pdf` · trap: date 2012-10-29 ('Gen. Date' and 'Officially printed on' date); party Main Street Media Group (agency / billing address) · review: LOW_CONFIDENCE
- **real-invoice-15**: expected `2025-02-23 Invoice from WBTV.pdf`, got `2025-02-23 Invoice.pdf` · review: PARTY_MISSING
- **real-office-08**: expected `2020-09-10 Letter to Labour Party.docx`, got `2020-09-10 Statement of Conduct to Angela Rayner MP.docx` · trap: party Angela Rayner (party chair addressed by name) · review: TYPE_UNSUPPORTED
- **real-office-11**: expected `2001-04-23 Invoice Dispute Letter to Enron North America.xls`, got `2001-04-23 INVOICE from Enron North America.xls` · review: LOW_CONFIDENCE
- **real-office-14**: expected `2001-11-26 Outstanding Invoices Statement from Locke Liddell & Sapp LLP.xls`, got `2001-11-26 Document from Locke Liddell & Sapp LLP.xls` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED
- **real-office-15**: expected `2002-03-20 Ship Notification for Enron Corp.eml`, got `2002-03-20 Email from Enron Corp.eml` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, LOW_CONFIDENCE

## How to compare

Keep this run's JSON, make the change, run again, then:

```text
intern-bench compare --before before.json --after after.json --markdown diff.md
```

It recomputes every rate and count over the documents both runs scored, lists each document whose score flipped, and gives the change in p50/p95 of every stage over the documents both completed - between two live runs only, since a replay's timings are its recording's. `intern-bench report --input report.json --markdown report.md` re-renders this page from the JSON.
