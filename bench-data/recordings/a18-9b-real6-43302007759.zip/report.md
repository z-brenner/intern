# InternBench: live run

- **Run:** 2026-11-12T20:42:36Z · commit `343ee39b8e`
- **Machine:** Intel(R) Xeon(R) Platinum 8370C CPU @ 2.80GHz, 4 logical cores, 15.6 GB RAM, linux (Ubuntu 24.04.5 LTS)
- **Model:** `intern-local` · 5.68 GB · sha256 `03b74727a860`
- **Corpus:** 51 documents · 51 completed · gold `d3d89f869a`
- **Wall time:** 3067.41 s for the whole run, the worker's start included

## Scorecard

| Score | Result |
| --- | ---: |
| Filename (the whole name) | 21/45 (46.7%) |
| Document type | 39/51 (76.5%) |
| Date | 38/45 (84.4%) |
| Date role (when the reviewed date was chosen) | 19/36 (52.8%) |
| Parties | 37/51 (72.5%) |
| Relation word (when parties were named) | 35/44 (79.5%) |
| Party in the right role (when parties were named) | 31/39 (79.5%) |
| Ready / review routing | 10/31 (32.3%) |
| Description states nothing false | 51/51 (100.0%) |
| Description is specific | 35/51 (68.6%) |
| Description specificity | 62.1% (mean of 51) |
| Evidence recall (model's quotes) | 67.4% (mean of 46) |
| Digest recall (facts reaching the digest) | 89.1% (mean of 46) |
| Prompt recall (facts reaching the prompt sent) | 84.8% (mean of 46) |
| Sent to review | 82.3% of 51 completed |

## Phase 3 scorecard

| Figure | Value | Docs |
| --- | ---: | ---: |
| Long-document filename accuracy (10+ pages) | 50.0% | 6 |
| Complex-document filename accuracy | – | 0 |
| Description completeness | – | 0 |
| Unsupported-fact rate (documents) | 66.7% | 51 |
| Review rate | 82.3% | 51 |
| Evidence recall | 67.4% | 46 |
| Total latency p50 | 55.64 s | 51 |
| Total latency p95 | 101.86 s | 51 |
| Generation latency p50 | 23.09 s | 51 |
| Generation latency p95 | 29.53 s | 51 |
| Generated tokens p50 | 86 | 51 |
| Generated tokens p95 | 111 | 51 |
| Prompt tokens p50 | 750 | 51 |

Long: 10 pages or more. Complex: any of `referenced_agreement`, `middle_fact`, `multi_column`, `layout_parties`, `irrelevant_names`, `information_dense`, `stream_order`, `date_in_table`, `key_value`, `complex_pdf`. Unsupported-fact rate: documents with any `*_UNSUPPORTED` review reason. Latency and tokens over the documents that completed.

## Safety

| Check | Count |
| --- | ---: |
| Filed without review under a wrong name | 3 of 45 |
| Trap date chosen | 5 of 51 |
| Forbidden party named | 6 of 51 |
| Spurious parties named | 12 |
| Description states a known-wrong fact | 0 |
| Unsupported description claims | 0 of 140 (0.0%) |
| Right name sent to review anyway | 9 of 24 |
| Sent to review for an unsupported fact | 34 of 51 |

## By kind

| Kind | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| form | 6 | 0/2 | 2/2 | 5/6 | 3/4 | 83.3% | 52.63 s | 105.08 s |
| invoice | 4 | 2/4 | 2/4 | 2/4 | 1/2 | 75.0% | 55.77 s | 92.81 s |
| letter | 18 | 9/18 | 15/18 | 13/18 | 1/11 | 94.4% | 50.77 s | 85.58 s |
| memo | 5 | 0/4 | 4/4 | 2/5 | 2/3 | 80.0% | 55.97 s | 80.20 s |
| minutes | 6 | 3/6 | 6/6 | 4/6 | 1/5 | 66.7% | 61.03 s | 128.92 s |
| notice | 11 | 7/11 | 9/11 | 10/11 | 1/5 | 72.7% | 50.50 s | 67.74 s |
| statement | 1 | – | – | 1/1 | 1/1 | 100.0% | 25.06 s | 25.06 s |

## By text layer

| Text layer | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| image | 4 | 1/4 | 2/4 | 2/4 | 0/1 | 100.0% | 39.00 s | 57.97 s |
| native | 25 | 13/24 | 22/24 | 15/25 | 5/19 | 80.0% | 58.56 s | 101.07 s |
| office | 5 | 1/1 | 1/1 | 4/5 | 3/4 | 60.0% | 47.15 s | 55.64 s |
| scan | 17 | 6/16 | 13/16 | 16/17 | 2/7 | 88.2% | 55.03 s | 105.08 s |

## By page count

| Pages | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 22 | 9/18 | 12/18 | 15/22 | 6/11 | 86.4% | 43.09 s | 67.01 s |
| 2-4 | 16 | 7/15 | 15/15 | 14/16 | 2/9 | 87.5% | 60.06 s | 101.86 s |
| 5-9 | 7 | 2/6 | 5/6 | 4/7 | 0/5 | 71.4% | 56.35 s | 105.08 s |
| 10-24 | 4 | 2/4 | 4/4 | 3/4 | 1/4 | 75.0% | 55.97 s | 101.07 s |
| 25-49 | 2 | 1/2 | 2/2 | 1/2 | 1/2 | 50.0% | 82.57 s | 128.92 s |

## By slice

| Slice | Docs | Filename | Date | Parties | Routing | Unsafe ready | p50 total | p95 total | p50 generation | p95 generation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| long | 6 | 3/6 | 6/6 | 4/6 | 2/6 | 1 of 6 | 58.56 s | 128.92 s | 25.35 s | 35.16 s |

`long`: 10 pages or more. `complex`: any of the categories listed under the phase 3 scorecard. A document may be in both.

## By challenge

| Category | Docs | Filename | Date | Parties | Traps sprung |
| --- | ---: | ---: | ---: | ---: | ---: |
| abbreviated_issuer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| addressed_to_office_holder | 1 | 0/1 | 0/1 | 1/1 | 0 |
| addressed_to_person | 3 | 2/3 | 2/3 | 2/3 | 0 |
| addressee_is_office_holder | 1 | 0/1 | 1/1 | 1/1 | 0 |
| agencies_named_in_boilerplate | 1 | – | – | 0/1 | 0 |
| agency_enforcement | 1 | 1/1 | 1/1 | 1/1 | 0 |
| agency_guidance | 2 | 0/2 | 2/2 | 1/2 | 0 |
| agency_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| annotation_banner | 1 | 0/1 | 1/1 | 1/1 | 0 |
| appendices | 1 | 0/1 | 1/1 | 0/1 | 0 |
| applicant_named | 1 | 0/1 | 1/1 | 0/1 | 0 |
| approval_blocks_in_footer | 1 | – | – | 0/1 | 1 |
| attached_order_form | 1 | 1/1 | 1/1 | 1/1 | 0 |
| attachment_with_own_date | 2 | 1/2 | 2/2 | 2/2 | 0 |
| attachments | 3 | 0/3 | 3/3 | 3/3 | 0 |
| attendance_list | 3 | 2/3 | 3/3 | 2/3 | 1 |
| attendee_list | 2 | 1/2 | 2/2 | 1/2 | 0 |
| australia | 6 | 4/5 | 4/5 | 6/6 | 1 |
| bilingual_letterhead | 1 | 1/1 | 1/1 | 1/1 | 0 |
| billhead | 2 | 0/2 | 0/2 | 0/2 | 1 |
| blank_fields | 1 | – | – | 1/1 | 0 |
| blank_template | 5 | – | – | 3/5 | 3 |
| board_minutes | 4 | 1/4 | 4/4 | 2/4 | 1 |
| body_recounts_events | 1 | 1/1 | 1/1 | 1/1 | 0 |
| born_digital | 23 | 11/22 | 20/22 | 13/23 | 6 |
| brand_names_in_letterhead | 1 | 0/1 | 0/1 | 0/1 | 1 |
| brand_vs_legal_name | 2 | 2/2 | 2/2 | 2/2 | 0 |
| canada | 2 | 2/2 | 2/2 | 2/2 | 0 |
| caption_title | 1 | 1/1 | 1/1 | 1/1 | 0 |
| cc_list | 1 | 1/1 | 1/1 | 1/1 | 0 |
| certificate_of_service | 1 | 1/1 | 1/1 | 1/1 | 0 |
| checkboxes | 1 | – | – | 1/1 | 0 |
| class_of_recipients | 1 | 0/1 | 1/1 | 0/1 | 0 |
| client_vs_counsel | 1 | 1/1 | 1/1 | 1/1 | 0 |
| comment_letter | 1 | 1/1 | 1/1 | 1/1 | 0 |
| competing_dates | 38 | 19/38 | 33/38 | 30/38 | 6 |
| confirmation_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| copier_searchable_pdf | 2 | 2/2 | 2/2 | 2/2 | 0 |
| corporate_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| council_minutes | 1 | 1/1 | 1/1 | 1/1 | 0 |
| counsel_named | 1 | 1/1 | 1/1 | 1/1 | 0 |
| court_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| cover_letter | 1 | 1/1 | 1/1 | 1/1 | 0 |
| cover_page | 1 | 1/1 | 1/1 | 1/1 | 0 |
| cover_sheet | 2 | 1/2 | 2/2 | 2/2 | 0 |
| customer_first | 4 | 2/4 | 2/4 | 2/4 | 1 |
| date_at_end | 5 | 2/5 | 2/5 | 4/5 | 2 |
| date_at_foot | 1 | 1/1 | 1/1 | 1/1 | 0 |
| date_at_top | 1 | 0/1 | 1/1 | 0/1 | 0 |
| date_field_trap | 1 | – | – | 1/1 | 1 |
| date_in_title | 1 | 0/1 | 1/1 | 1/1 | 0 |
| date_range | 1 | 0/1 | 1/1 | 0/1 | 1 |
| date_without_year | 1 | 0/1 | 0/1 | 1/1 | 0 |
| dated_line_at_end | 1 | 1/1 | 1/1 | 1/1 | 0 |
| day_first_date | 4 | 2/3 | 2/3 | 4/4 | 2 |
| dd_month_yyyy | 1 | 1/1 | 1/1 | 1/1 | 0 |
| deadline_in_body | 7 | 2/7 | 7/7 | 5/7 | 2 |
| dear_ceo_letter | 1 | 0/1 | 1/1 | 0/1 | 0 |
| decided_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| deposit_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| digital_signature_date | 1 | 0/1 | 1/1 | 0/1 | 0 |
| docket_number | 1 | 1/1 | 1/1 | 1/1 | 0 |
| docx | 4 | 1/1 | 1/1 | 3/4 | 2 |
| due_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| effective_date_differs | 1 | 1/1 | 1/1 | 1/1 | 0 |
| effective_dates | 3 | 2/3 | 3/3 | 2/3 | 0 |
| enclosure | 1 | 1/1 | 1/1 | 1/1 | 0 |
| enclosures | 1 | 1/1 | 1/1 | 1/1 | 0 |
| encrypted_pdf | 1 | 0/1 | 1/1 | 0/1 | 0 |
| engraved_letterhead | 1 | 0/1 | 0/1 | 0/1 | 0 |
| engraved_portraits | 1 | 0/1 | 0/1 | 0/1 | 0 |
| event_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| event_date_prominent | 1 | 1/1 | 1/1 | 1/1 | 0 |
| file_number | 1 | 0/1 | 1/1 | 1/1 | 0 |
| fillable_form | 1 | – | – | 0/1 | 0 |
| filled_form | 1 | 0/1 | 1/1 | 1/1 | 0 |
| first_name_salutation | 1 | 1/1 | 1/1 | 1/1 | 0 |
| foi_release | 5 | 3/4 | 3/4 | 5/5 | 1 |
| footnotes | 3 | 1/3 | 2/3 | 2/3 | 1 |
| form | 7 | 1/3 | 3/3 | 6/7 | 2 |
| form_layout | 1 | 0/1 | 1/1 | 0/1 | 0 |
| form_revision_date | 2 | 0/1 | 1/1 | 1/2 | 0 |
| formula_date | 1 | – | – | 1/1 | 1 |
| future_period | 1 | 0/1 | 1/1 | 0/1 | 1 |
| goods_for_third_party | 1 | 0/1 | 0/1 | 0/1 | 1 |
| government_form | 5 | 1/3 | 3/3 | 4/5 | 0 |
| government_sender | 1 | 1/1 | 1/1 | 1/1 | 0 |
| handwritten | 2 | 0/2 | 0/2 | 0/2 | 0 |
| handwritten_annotations | 1 | 1/1 | 1/1 | 1/1 | 0 |
| handwritten_date | 3 | 2/3 | 2/3 | 3/3 | 0 |
| handwritten_dates | 2 | 1/2 | 2/2 | 2/2 | 0 |
| handwritten_signature | 2 | 1/2 | 1/2 | 2/2 | 0 |
| hearing_date | 1 | 0/1 | 0/1 | 1/1 | 1 |
| hearing_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| historic | 4 | 1/4 | 1/4 | 1/4 | 1 |
| historical | 2 | 2/2 | 2/2 | 2/2 | 0 |
| image | 4 | 1/4 | 2/4 | 2/4 | 0 |
| image_only | 4 | 0/3 | 1/3 | 4/4 | 1 |
| image_page | 1 | 1/1 | 1/1 | 1/1 | 0 |
| industry_letter | 1 | 0/1 | 1/1 | 0/1 | 0 |
| instructions_in_cells | 1 | – | – | 1/1 | 1 |
| internal_correspondence | 1 | 1/1 | 1/1 | 1/1 | 0 |
| invoice | 5 | 2/4 | 2/4 | 3/5 | 2 |
| invoice_template | 1 | – | – | 1/1 | 1 |
| ireland | 2 | 1/2 | 2/2 | 1/2 | 0 |
| irregular_spacing | 1 | 1/1 | 1/1 | 1/1 | 0 |
| issuer_in_header | 1 | – | – | 1/1 | 0 |
| issuer_in_header_image | 2 | 1/1 | 1/1 | 1/2 | 1 |
| issuer_in_image | 1 | 0/1 | 0/1 | 1/1 | 1 |
| issuer_in_logo | 1 | 0/1 | 1/1 | 1/1 | 0 |
| issuer_in_logo_only | 1 | 0/1 | 1/1 | 0/1 | 1 |
| issuer_in_signature_block | 1 | 0/1 | 1/1 | 0/1 | 0 |
| issuer_not_named | 1 | 0/1 | 1/1 | 0/1 | 1 |
| jpeg | 1 | 0/1 | 1/1 | 1/1 | 0 |
| law_firm_letterhead | 1 | 1/1 | 1/1 | 1/1 | 0 |
| letter | 18 | 9/18 | 15/18 | 13/18 | 3 |
| letter_format | 1 | 1/1 | 1/1 | 1/1 | 0 |
| letter_from_company | 3 | 2/3 | 2/3 | 2/3 | 0 |
| letter_from_counsel | 1 | 1/1 | 1/1 | 1/1 | 0 |
| letter_from_nonprofit | 1 | 0/1 | 1/1 | 1/1 | 0 |
| letterhead | 9 | 4/9 | 8/9 | 7/9 | 1 |
| letterhead_image_only | 2 | 1/2 | 2/2 | 1/2 | 0 |
| letterhead_logo | 2 | 1/2 | 2/2 | 1/2 | 0 |
| letterhead_logo_only | 1 | 0/1 | 0/1 | 1/1 | 1 |
| letterhead_vs_signer_entity | 1 | 1/1 | 1/1 | 1/1 | 0 |
| line_item_dates | 2 | 1/2 | 2/2 | 2/2 | 0 |
| local_government | 1 | 1/1 | 1/1 | 1/1 | 0 |
| logo_issuer | 1 | 0/1 | 1/1 | 0/1 | 0 |
| long_document | 4 | 3/4 | 4/4 | 3/4 | 1 |
| long_letter | 1 | 1/1 | 1/1 | 1/1 | 0 |
| many_addressees | 1 | 0/1 | 0/1 | 0/1 | 1 |
| many_companies_named | 1 | 0/1 | 1/1 | 1/1 | 0 |
| many_dates | 8 | 3/8 | 7/8 | 4/8 | 2 |
| many_named_organisations | 3 | 1/3 | 3/3 | 2/3 | 1 |
| many_organisations | 1 | 1/1 | 1/1 | 1/1 | 0 |
| many_parties | 4 | 3/4 | 4/4 | 4/4 | 0 |
| memo | 5 | 0/4 | 4/4 | 2/5 | 2 |
| memo_header | 1 | 0/1 | 1/1 | 0/1 | 0 |
| memorandum | 5 | 0/4 | 4/4 | 2/5 | 2 |
| metadata_date_trap | 15 | 7/10 | 8/10 | 13/15 | 4 |
| minutes | 6 | 3/6 | 6/6 | 4/6 | 1 |
| misprinted_year | 1 | 1/1 | 1/1 | 1/1 | 0 |
| mixed_scan_and_digital | 1 | 0/1 | 1/1 | 1/1 | 0 |
| modern | 45 | 18/39 | 35/39 | 34/45 | 10 |
| month_only_date | 2 | 1/1 | 1/1 | 1/2 | 0 |
| month_only_references | 1 | 0/1 | 1/1 | 0/1 | 0 |
| multi_page | 1 | 0/1 | 1/1 | 0/1 | 0 |
| multiple_parties | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multiple_sheets | 1 | – | – | 1/1 | 1 |
| municipal | 2 | 0/2 | 1/2 | 2/2 | 1 |
| named_officials | 9 | 3/8 | 7/8 | 6/9 | 3 |
| named_person_at_org | 9 | 6/9 | 9/9 | 8/9 | 1 |
| no_addressee_block | 1 | 0/1 | 1/1 | 0/1 | 0 |
| no_document_date | 6 | – | – | 4/6 | 4 |
| no_explicit_addressee | 1 | 1/1 | 1/1 | 1/1 | 0 |
| no_issuer_printed | 3 | 0/1 | 1/1 | 2/3 | 3 |
| no_letterhead | 1 | 0/1 | 0/1 | 0/1 | 1 |
| no_signatory | 1 | 0/1 | 1/1 | 1/1 | 0 |
| no_specific_addressee | 1 | 0/1 | 1/1 | 1/1 | 0 |
| no_text_layer | 2 | 0/2 | 1/2 | 1/2 | 1 |
| no_title | 1 | – | – | 1/1 | 1 |
| noisy_ocr_layer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| nonprofit | 2 | 0/2 | 1/2 | 0/2 | 1 |
| notice | 11 | 7/11 | 9/11 | 10/11 | 1 |
| notice_of_decision | 1 | 0/1 | 1/1 | 0/1 | 0 |
| notice_of_meeting | 1 | 1/1 | 1/1 | 1/1 | 0 |
| notice_of_violation | 1 | 1/1 | 1/1 | 1/1 | 0 |
| number_looks_like_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| ocr_text_layer | 12 | 6/12 | 12/12 | 12/12 | 0 |
| office | 5 | 1/1 | 1/1 | 4/5 | 3 |
| open_letter | 1 | 0/1 | 0/1 | 0/1 | 1 |
| opinion_letter | 1 | 1/1 | 1/1 | 1/1 | 0 |
| paid | 1 | 1/1 | 1/1 | 1/1 | 0 |
| partly_printed_date_line | 2 | 0/2 | 0/2 | 0/2 | 0 |
| personal_sender_on_letterhead | 1 | 0/1 | 0/1 | 1/1 | 0 |
| placeholders | 4 | 0/1 | 1/1 | 3/4 | 3 |
| printed_form | 1 | 0/1 | 1/1 | 1/1 | 0 |
| prior_invoices_deducted | 1 | 1/1 | 1/1 | 1/1 | 0 |
| procurement | 1 | – | – | 1/1 | 0 |
| proprietor_in_letterhead | 1 | 1/1 | 1/1 | 1/1 | 0 |
| public_notice | 6 | 3/6 | 4/6 | 6/6 | 1 |
| purchase_order | 1 | 0/1 | 1/1 | 1/1 | 0 |
| re_line_references_document | 1 | 0/1 | 1/1 | 1/1 | 0 |
| received_stamp | 1 | 0/1 | 1/1 | 1/1 | 0 |
| redacted | 1 | 1/1 | 1/1 | 1/1 | 0 |
| redactions | 3 | 3/3 | 3/3 | 3/3 | 0 |
| reference_number | 11 | 5/11 | 11/11 | 9/11 | 2 |
| reference_stamp | 1 | 1/1 | 1/1 | 1/1 | 0 |
| referenced_case | 1 | 1/1 | 1/1 | 1/1 | 0 |
| referenced_dates | 6 | 3/6 | 6/6 | 5/6 | 0 |
| regulator | 5 | 2/5 | 5/5 | 4/5 | 0 |
| regulator_correspondence | 1 | 1/1 | 1/1 | 1/1 | 0 |
| regulatory_filing | 1 | 1/1 | 1/1 | 1/1 | 0 |
| relative_date_reference | 1 | 1/1 | 1/1 | 1/1 | 0 |
| resignation | 1 | 0/1 | 0/1 | 1/1 | 0 |
| revised | 1 | 1/1 | 1/1 | 1/1 | 0 |
| row_dates | 1 | – | – | 1/1 | 1 |
| running_header | 1 | 0/1 | 1/1 | 0/1 | 1 |
| scanned | 17 | 6/16 | 13/16 | 16/17 | 2 |
| scanned_signature_page | 1 | 1/1 | 1/1 | 1/1 | 0 |
| script_font_date | 1 | 0/1 | 0/1 | 1/1 | 1 |
| seal_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| security_marking | 1 | – | – | 1/1 | 1 |
| senate_minutes | 1 | 1/1 | 1/1 | 1/1 | 0 |
| sender_at_end | 2 | 0/2 | 1/2 | 1/2 | 1 |
| service_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| service_period | 3 | 0/2 | 2/2 | 3/3 | 1 |
| short | 8 | 2/7 | 4/7 | 6/8 | 3 |
| signatory_trap | 2 | 0/2 | 1/2 | 2/2 | 1 |
| signatory_vs_org | 3 | 1/3 | 3/3 | 3/3 | 0 |
| signature_date | 1 | 0/1 | 1/1 | 0/1 | 0 |
| signature_on_later_page | 1 | 1/1 | 1/1 | 1/1 | 0 |
| signature_scan | 5 | 3/5 | 5/5 | 5/5 | 0 |
| signer_vs_letterhead | 1 | 0/1 | 0/1 | 0/1 | 0 |
| small_print | 1 | 0/1 | 1/1 | 1/1 | 0 |
| source_title_mismatch | 3 | 1/3 | 3/3 | 2/3 | 0 |
| south_africa | 3 | 0/2 | 1/2 | 3/3 | 1 |
| spreadsheet | 1 | – | – | 1/1 | 1 |
| staff_names | 8 | 2/8 | 8/8 | 5/8 | 1 |
| stamp_date | 1 | 0/1 | 1/1 | 1/1 | 0 |
| stamped_date | 3 | 0/3 | 2/3 | 2/3 | 1 |
| statement | 1 | – | – | 1/1 | 1 |
| statute_date | 1 | – | – | 0/1 | 0 |
| statutory_notice | 1 | 0/1 | 1/1 | 1/1 | 0 |
| successor_name | 2 | 0/2 | 0/2 | 0/2 | 1 |
| table | 2 | 0/1 | 1/1 | 2/2 | 1 |
| table_layout | 1 | 0/1 | 1/1 | 0/1 | 0 |
| table_of_contents | 2 | 1/2 | 2/2 | 1/2 | 1 |
| tables | 3 | 0/2 | 2/2 | 3/3 | 1 |
| tax_invoice | 2 | 2/2 | 2/2 | 2/2 | 0 |
| template_attachment | 1 | 0/1 | 1/1 | 1/1 | 0 |
| third_party_named_in_body | 3 | 2/3 | 3/3 | 2/3 | 0 |
| through_line | 1 | – | – | 0/1 | 1 |
| trading_name | 2 | 0/2 | 1/2 | 1/2 | 0 |
| transmittal_letter | 1 | 0/1 | 1/1 | 1/1 | 0 |
| two_addressees | 1 | 1/1 | 1/1 | 1/1 | 0 |
| two_day_meeting | 1 | 0/1 | 1/1 | 0/1 | 1 |
| two_digit_year | 2 | 1/1 | 1/1 | 2/2 | 1 |
| two_senders | 1 | 0/1 | 0/1 | 0/1 | 1 |
| type_in_subject_line | 1 | 1/1 | 1/1 | 1/1 | 0 |
| type_not_printed | 2 | 0/1 | 1/1 | 2/2 | 1 |
| typed | 1 | 1/1 | 1/1 | 1/1 | 0 |
| typewritten | 2 | 1/2 | 1/2 | 1/2 | 1 |
| university | 4 | 2/3 | 3/3 | 2/4 | 2 |
| university_foundation | 1 | 0/1 | 1/1 | 0/1 | 0 |
| us_date_format | 4 | 3/4 | 4/4 | 4/4 | 0 |
| us_federal | 12 | 5/11 | 11/11 | 8/12 | 1 |
| us_local | 6 | 3/5 | 4/5 | 6/6 | 1 |
| us_state | 8 | 2/8 | 8/8 | 6/8 | 2 |
| warn_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| watermark | 1 | 1/1 | 1/1 | 1/1 | 0 |
| withdrawn | 1 | 1/1 | 1/1 | 1/1 | 0 |
| xlsx | 1 | – | – | 1/1 | 1 |
| year_in_letterhead | 1 | 0/1 | 0/1 | 0/1 | 0 |

## Routes

- **Pages:** fast 147 · layout 33 · ocr 32 · ocr_regions 4
- **Documents by route class:** fast 13 · layout 13 · ocr 22 · ocr_regions 3

## Where the time goes

| Stage | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `total_ms` | 51 | 55.64 s | 101.86 s | 128.92 s |
| `extraction_wall_ms` | 51 | 190.8 ms | 5.48 s | 17.63 s |
| `worker_total_ms` | 51 | 189.6 ms | 5.48 s | 17.63 s |
| `worker_snapshot_ms` | 51 | 0.26 ms | 0.56 ms | 1.2 ms |
| `worker_parse_ms` | 51 | 6.0 ms | 63.3 ms | 183.2 ms |
| `worker_analysis_ms` | 51 | 0.80 ms | 5.8 ms | 7.8 ms |
| `worker_render_ms` | 51 | 0.00 ms | 570.4 ms | 1.70 s |
| `worker_image_decode_ms` | 51 | 0.00 ms | 30.7 ms | 60.3 ms |
| `worker_ocr_ms` | 51 | 0.00 ms | 8.99 s | 33.66 s |
| `worker_ocr_encode_ms` | 51 | 0.00 ms | 592.1 ms | 1.46 s |
| `worker_ocr_engine_ms` | 51 | 0.00 ms | 8.16 s | 31.84 s |
| `worker_vision_ms` | 51 | 0.00 ms | 10.7 ms | 19.5 ms |
| `analyze_wall_ms` | 51 | 53.45 s | 96.49 s | 128.86 s |
| `distill_ms` | 51 | 2.9 ms | 30.0 ms | 44.3 ms |
| `prompt_ms` | 51 | 0.03 ms | 0.06 ms | 0.08 ms |
| `inference_ms` | 51 | 53.45 s | 96.48 s | 128.79 s |
| `prefill_ms` | 51 | 29.80 s | 69.52 s | 93.62 s |
| `generation_ms` | 51 | 23.09 s | 29.53 s | 35.16 s |
| `validation_ms` | 51 | 6.0 ms | 20.0 ms | 28.5 ms |
| `naming_ms` | 51 | 0.30 ms | 3.7 ms | 6.0 ms |
| `index_ms` | 51 | 2.2 ms | 27.8 ms | 41.1 ms |
| `retrieval_ms` | 51 | 0.05 ms | 2.2 ms | 3.3 ms |

| Measure | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `prefill_tok_per_s` | 51 | 24.9 tok/s | 25.4 tok/s | 25.9 tok/s |
| `generation_tok_per_s` | 51 | 3.8 tok/s | 3.8 tok/s | 3.9 tok/s |
| `prompt_tokens` | 51 | 750 | 1756 | 2350 |
| `cached_tokens` | 51 | 477 | 477 | 477 |
| `generated_tokens` | 51 | 86 | 111 | 126 |
| `estimated_prompt_tokens` | 51 | 1327 | 2271 | 2481 |
| `model_requests` | 51 | 1 | 1 | 1 |
| `redistillations` | 51 | 0 | 0 | 0 |
| `source_characters` | 51 | 2983 | 48744 | 68987 |
| `digest_characters` | 51 | 2269 | 5501 | 5873 |
| `prompt_characters` | 51 | 4324 | 7550 | 7928 |
| `worker_ocr_pages` | 51 | 0 | 2 | 8 |
| `worker_ocr_passes` | 51 | 0 | 2 | 8 |
| `worker_orientation_passes` | 51 | 0 | 2 | 8 |
| `worker_rendered_pixels` | 51 | 0 | 16846830 | 67320000 |
| `index_units` | 51 | 33 | 284 | 347 |
| `context_units` | 51 | 19 | 56 | 67 |
| `context_tokens` | 51 | 739 | 1683 | 1891 |

## Extraction time

| Route class | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fast | 13 | 5.9 ms | 75.0 ms | 5.3 ms | 73.7 ms | 63.3 ms | 6.3 ms | 0.00 ms | 0.00 ms |
| layout | 13 | 10.5 ms | 190.8 ms | 10.0 ms | 189.6 ms | 183.2 ms | 5.8 ms | 0.00 ms | 0.00 ms |
| ocr_regions | 3 | 1.63 s | 2.75 s | 1.63 s | 2.75 s | 5.1 ms | 1.2 ms | 134.9 ms | 2.57 s |
| ocr | 22 | 2.75 s | 7.09 s | 2.75 s | 7.09 s | 35.9 ms | 4.0 ms | 961.2 ms | 12.92 s |

| Pages | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 22 | 1.63 s | 4.51 s | 1.63 s | 4.51 s | 17.4 ms | 1.2 ms | 570.4 ms | 4.48 s |
| 2-4 | 16 | 13.6 ms | 7.09 s | 12.8 ms | 7.09 s | 31.6 ms | 3.0 ms | 313.9 ms | 12.92 s |
| 5-9 | 7 | 20.8 ms | 17.63 s | 20.3 ms | 17.63 s | 183.2 ms | 5.1 ms | 1.70 s | 33.66 s |
| 10-24 | 4 | 27.1 ms | 3.19 s | 26.2 ms | 3.19 s | 63.3 ms | 7.8 ms | 483.4 ms | 5.38 s |
| 25-49 | 2 | 60.3 ms | 67.2 ms | 58.7 ms | 65.5 ms | 57.4 ms | 6.3 ms | 0.00 ms | 0.00 ms |

| Kind | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| form | 6 | 5.9 ms | 17.63 s | 5.3 ms | 17.63 s | 69.8 ms | 4.0 ms | 1.70 s | 33.66 s |
| invoice | 4 | 2.14 s | 2.75 s | 2.14 s | 2.75 s | 10.9 ms | 1.2 ms | 570.4 ms | 2.55 s |
| letter | 18 | 190.8 ms | 7.09 s | 189.6 ms | 7.09 s | 183.2 ms | 5.1 ms | 961.2 ms | 12.92 s |
| memo | 5 | 7.7 ms | 5.48 s | 7.2 ms | 5.48 s | 13.5 ms | 2.2 ms | 225.6 ms | 8.28 s |
| minutes | 6 | 60.3 ms | 3.19 s | 58.7 ms | 3.19 s | 57.4 ms | 7.8 ms | 483.4 ms | 5.38 s |
| notice | 11 | 1.35 s | 4.80 s | 1.35 s | 4.80 s | 23.9 ms | 2.2 ms | 256.0 ms | 4.61 s |
| statement | 1 | 1.13 s | 1.13 s | 1.13 s | 1.13 s | 0.44 ms | 0.16 ms | 119.3 ms | 999.2 ms |

Over the documents that completed. Wall is the runner's clock around the request; worker is the worker's own total. OCR is summed over the pages, so when the worker reads pages in parallel it can exceed the total. A document's route class is the most expensive route any of its pages took (ocr > ocr_regions > layout > fast), or `unrouted` when the worker sent no layouts.

## Memory

| Process | Typical peak (p50) | Highest peak | During |
| --- | ---: | ---: | ---: |
| Parser worker | 441 MB | 1263 MB | real6-form-03 |
| Model server | 6083 MB | 6085 MB | real6-minutes-06 |
| Benchmark (engine) | 15 MB | 18 MB | real6-minutes-06 |

Resident memory sampled every 25 ms per document; a spike shorter than that can be missed.

## Misses (24)

- **real6-letter-03**: expected `2002-11-01 Letter from Nevada Nuclear Waste Task Force.pdf`, got `2002-11-01 Letter to The Members of the Nuclear Waste Technical Review Board.pdf` · review: TYPE_MISSING, PARTY_UNSUPPORTED
- **real6-letter-04**: expected `2017-11-14 Letter to The President.pdf`, got `2017-11-14 Letter from The President.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING
- **real6-letter-06**: expected `2024-02-16 Attorney General Opinion to Hardin County Attorney.pdf`, got `2024-02-16 Opinion to Matthew E. Minick.pdf` · trap: party Matthew E. Minick (addressee, the county attorney as a person) · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real6-letter-07**: expected `2019-05-02 Violation Notice to LECO Corporation.pdf`, got `2019-05-02 Violation Notice for IF Leco Corporation.pdf` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real6-letter-08**: expected `2025-04-11 House Executive Message from Office of the Governor.pdf`, got `2025-04-11 Document to Javier Martínez.pdf` · trap: party Javier Martínez (Speaker of the House, addressed with the Members on the House's behalf) · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED
- **real6-letter-12**: expected `2024-04-24 Dear CEO Letter from Central Bank of Ireland.pdf`, got `2024-04-24 Thematic Review on Early Mortgage Arrears for CEO.pdf` · **filed without review**
- **real6-letter-13**: expected `2018-07-11 Resignation Letter from John A. Fraser.pdf`, got `Letter to His Excellency General The Hon Sir Peter Cosgrove AK MC (Retd) Governor-General.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, DATE_UNSUPPORTED, PARTY_UNSUPPORTED
- **real6-letter-16**: expected `1874-07-03 Letter from Freedman's Savings and Trust Company.jpg`, got `Document - Reh Docplals.jpg` · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, DESCRIPTION_INVALID, PARSER_WARNING, LOW_CONFIDENCE
- **real6-letter-18**: expected `2026-02-05 Open Letter from ACLU of Northern California.pdf`, got `2025-09-03 Open Letter Tech Companies Must Resist Unlawful Subpoenas for User Data.pdf` · trap: date 2025-09-03 (date of the DHS subpoena to Meta the letter recounts) · review: PARTY_UNSUPPORTED
- **real6-notice-04**: expected `2025-06-05 Commission Action for National Park Service.pdf`, got `2025-06-05 Document - Commemorative Works.pdf` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real6-notice-05**: expected `2025-04-23 Public Hearing Notice from Conway Board of Health.pdf`, got `Document from Conway Board of Health.pdf` · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED
- **real6-notice-09**: expected `2026-06-16 Public Notice from Midvaal Local Municipality.jpg`, got `2026-06-16 Public Notice for Midvaal Local Municipality.jpg` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, PARTY_UNSUPPORTED
- **real6-notice-10**: expected `2025-07-09 Notice for Public Hearings from Mogale City Local Municipality.pdf`, got `2025-07-24 Notice for Public Hearings Uifwe Mpac from Mogale City.pdf` · trap: date 2025-07-24 (date of the public hearings) · **filed without review**
- **real6-invoice-04**: expected `1863-06-10 Bill from M. A. Meade.jpg`, got `Document.jpg` · review: TYPE_MISSING, DATE_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, DESCRIPTION_INVALID, PARSER_WARNING, LOW_CONFIDENCE
- **real6-invoice-05**: expected `1906-03-14 Bill from Watkins-Cottrell Co.pdf`, got `Document from Fleming & Woodhouse Bros.pdf` · trap: party Fleming & Woodhouse Bros. (the customer) · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED, LOW_CONFIDENCE
- **real6-form-01**: expected `2019-12-23 Federal Financial Report from Secretary of the Commonwealth.pdf`, got `2019-09-30 Federal Financial Report from US Election Assistance Commission.pdf` · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real6-form-03**: expected `2026-04-06 Delivery Order to Matheny Motor Truck Co.pdf`, got `2026-04-06 Delivery Order from Department of Administration State of West Virginia.pdf` · review: LOW_CONFIDENCE
- **real6-memo-01**: expected `2004-06-01 Memorandum from Office of Government Ethics.pdf`, got `2004-06-01 Memorandum to Designated Agency Ethics Officials from Office of Government Ethics.pdf` · review: LOW_CONFIDENCE
- **real6-memo-02**: expected `2024-10-16 Informational Memorandum from Farm Credit Administration.pdf`, got `2024-10-16 Informational Memorandum to Chair, Board of Directors.pdf` · **filed without review**
- **real6-memo-03**: expected `2024-01-08 Memorandum from Florida Public Service Commission.pdf`, got `2024-01-08 Letter to Adam J. Teitzman, Commission Clerk, Office of Commission Clerk.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real6-memo-05**: expected `2025-07-16 Memorandum from University of Florida.pdf`, got `2025-07-16 Memorandum to Academic Deans and Directors.pdf` · trap: party Academic Deans and Directors (class of addressees in the To line) · review: LOW_CONFIDENCE
- **real6-minutes-01**: expected `2026-08-18 Board Meeting Minutes for Federal Accounting Standards Advisory Board.pdf`, got `2026-08-18 Fasab Meeting Minutes for Department of War.pdf` · trap: party Department of War (department that briefed the Board) · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real6-minutes-02**: expected `2025-09-23 Meeting Minutes for Port of Vancouver USA.pdf`, got `2025-09-23 Order from Port of Vancouver USA.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, LOW_CONFIDENCE
- **real6-minutes-05**: expected `2024-08-30 Board Meeting Minutes for Cal Poly Humboldt Foundation.pdf`, got `2024-08-30 MINUTES of the BOARD OF DIRECTORS for Robin Quigley.pdf` · review: PARTY_UNSUPPORTED

## How to compare

Keep this run's JSON, make the change, run again, then:

```text
intern-bench compare --before before.json --after after.json --markdown diff.md
```

It recomputes every rate and count over the documents both runs scored, lists each document whose score flipped, and gives the change in p50/p95 of every stage over the documents both completed - between two live runs only, since a replay's timings are its recording's. `intern-bench report --input report.json --markdown report.md` re-renders this page from the JSON.
