# InternBench: live run

- **Run:** 2026-11-11T08:00:56Z · commit `0c8d3295d9`
- **Machine:** AMD EPYC 9V74 80-Core Processor, 4 logical cores, 15.6 GB RAM, linux (Ubuntu 24.04.5 LTS)
- **Model:** `intern-local` · 5.68 GB · sha256 `03b74727a860`
- **Corpus:** 57 documents · 57 completed · gold `352419aa3c`
- **Wall time:** 2424.45 s for the whole run, the worker's start included

## Scorecard

| Score | Result |
| --- | ---: |
| Filename (the whole name) | 24/56 (42.9%) |
| Document type | 46/57 (80.7%) |
| Date | 44/56 (78.6%) |
| Date role (when the reviewed date was chosen) | 16/44 (36.4%) |
| Parties | 39/57 (68.4%) |
| Relation word (when parties were named) | 40/50 (80.0%) |
| Party in the right role (when parties were named) | 20/30 (66.7%) |
| Ready / review routing | 11/34 (32.4%) |
| Description states nothing false | 57/57 (100.0%) |
| Description is specific | 44/57 (77.2%) |
| Description specificity | 66.7% (mean of 57) |
| Evidence recall (model's quotes) | 63.7% (mean of 57) |
| Digest recall (facts reaching the digest) | 79.8% (mean of 57) |
| Prompt recall (facts reaching the prompt sent) | 77.2% (mean of 57) |
| Sent to review | 84.2% of 57 completed |

## Phase 3 scorecard

| Figure | Value | Docs |
| --- | ---: | ---: |
| Long-document filename accuracy (10+ pages) | 50.0% | 2 |
| Complex-document filename accuracy | – | 0 |
| Description completeness | – | 0 |
| Unsupported-fact rate (documents) | 79.0% | 57 |
| Review rate | 84.2% | 57 |
| Evidence recall | 63.7% | 57 |
| Total latency p50 | 40.02 s | 57 |
| Total latency p95 | 63.69 s | 57 |
| Generation latency p50 | 17.39 s | 57 |
| Generation latency p95 | 22.23 s | 57 |
| Generated tokens p50 | 91 | 57 |
| Generated tokens p95 | 119 | 57 |
| Prompt tokens p50 | 754 | 57 |

Long: 10 pages or more. Complex: any of `referenced_agreement`, `middle_fact`, `multi_column`, `layout_parties`, `irrelevant_names`, `information_dense`, `stream_order`, `date_in_table`, `key_value`, `complex_pdf`. Unsupported-fact rate: documents with any `*_UNSUPPORTED` review reason. Latency and tokens over the documents that completed.

## Safety

| Check | Count |
| --- | ---: |
| Filed without review under a wrong name | 4 of 56 |
| Trap date chosen | 3 of 57 |
| Forbidden party named | 6 of 57 |
| Spurious parties named | 10 |
| Description states a known-wrong fact | 0 |
| Unsupported description claims | 0 of 140 (0.0%) |
| Right name sent to review anyway | 11 of 29 |
| Sent to review for an unsupported fact | 45 of 57 |

## By kind

| Kind | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| invoice | 10 | 3/10 | 5/10 | 4/10 | 3/7 | 70.0% | 40.02 s | 68.33 s |
| letter | 23 | 11/23 | 20/23 | 17/23 | 2/11 | 95.7% | 35.49 s | 61.82 s |
| notice | 19 | 9/18 | 16/18 | 16/19 | 4/12 | 84.2% | 46.27 s | 73.93 s |
| receipt | 1 | 0/1 | 0/1 | 1/1 | – | 100.0% | 25.50 s | 25.50 s |
| statement | 4 | 1/4 | 3/4 | 1/4 | 2/4 | 50.0% | 39.03 s | 57.31 s |

## By text layer

| Text layer | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| image | 10 | 3/10 | 6/10 | 6/10 | 0/2 | 100.0% | 30.71 s | 54.47 s |
| native | 17 | 10/16 | 15/16 | 12/17 | 4/14 | 82.3% | 44.49 s | 68.33 s |
| office | 14 | 7/14 | 12/14 | 11/14 | 2/8 | 100.0% | 35.17 s | 62.25 s |
| scan | 13 | 3/13 | 8/13 | 8/13 | 4/7 | 69.2% | 47.37 s | 73.93 s |
| text | 3 | 1/3 | 3/3 | 2/3 | 1/3 | 33.3% | 30.43 s | 42.02 s |

## By page count

| Pages | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 27 | 11/27 | 19/27 | 18/27 | 5/14 | 85.2% | 33.05 s | 57.31 s |
| 2-4 | 22 | 11/21 | 19/21 | 17/22 | 4/14 | 81.8% | 41.60 s | 59.15 s |
| 5-9 | 6 | 1/6 | 4/6 | 3/6 | 2/4 | 83.3% | 48.03 s | 73.93 s |
| 10-24 | 2 | 1/2 | 2/2 | 1/2 | 0/2 | 100.0% | 51.90 s | 63.69 s |

## By slice

| Slice | Docs | Filename | Date | Parties | Routing | Unsafe ready | p50 total | p95 total | p50 generation | p95 generation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| long | 2 | 1/2 | 2/2 | 1/2 | 0/2 | 0 of 2 | 51.90 s | 63.69 s | 17.39 s | 22.13 s |

`long`: 10 pages or more. `complex`: any of the categories listed under the phase 3 scorecard. A document may be in both.

## By challenge

| Category | Docs | Filename | Date | Parties | Traps sprung |
| --- | ---: | ---: | ---: | ---: | ---: |
| addressed_to_staff | 1 | 0/1 | 1/1 | 0/1 | 1 |
| agency_billing | 4 | 3/4 | 4/4 | 3/4 | 1 |
| aging_table | 2 | 1/2 | 2/2 | 1/2 | 1 |
| all_caps_parties | 2 | 2/2 | 2/2 | 2/2 | 0 |
| ambiguous_digit | 1 | 1/1 | 1/1 | 1/1 | 0 |
| ambiguous_numeric_date | 1 | 0/1 | 1/1 | 0/1 | 0 |
| attachment_with_own_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| attachments | 2 | 0/2 | 2/2 | 1/2 | 0 |
| attachments_with_own_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| bank_details_redacted | 1 | 1/1 | 1/1 | 1/1 | 0 |
| bcc_distribution_list | 1 | 0/1 | 0/1 | 0/1 | 0 |
| billhead | 3 | 0/3 | 0/3 | 0/3 | 0 |
| blank_date | 2 | 0/2 | 0/2 | 1/2 | 1 |
| body_recounts_events | 7 | 4/6 | 6/6 | 6/7 | 1 |
| born_digital | 14 | 10/13 | 13/13 | 11/14 | 2 |
| brand_vs_legal_name | 4 | 3/4 | 4/4 | 3/4 | 1 |
| caption_court_differs_from_header | 1 | 0/1 | 1/1 | 0/1 | 0 |
| catalogue_date_trap | 2 | 0/2 | 0/2 | 0/2 | 0 |
| cc_above_subject | 1 | 1/1 | 1/1 | 1/1 | 0 |
| cc_list | 1 | 1/1 | 1/1 | 1/1 | 0 |
| circular | 1 | 0/1 | 1/1 | 1/1 | 0 |
| client_in_subject | 1 | 1/1 | 1/1 | 1/1 | 0 |
| coloured_paper | 2 | 0/2 | 0/2 | 0/2 | 1 |
| comparative_period | 1 | 0/1 | 1/1 | 0/1 | 0 |
| competing_dates | 32 | 13/32 | 26/32 | 21/32 | 4 |
| consultation_response | 1 | 0/1 | 1/1 | 1/1 | 0 |
| copies_list | 1 | 0/1 | 1/1 | 1/1 | 0 |
| corrected_firm_name | 1 | 0/1 | 0/1 | 0/1 | 0 |
| corrected_printed_year | 1 | 0/1 | 0/1 | 0/1 | 0 |
| court_filing | 3 | 2/3 | 3/3 | 2/3 | 0 |
| cover_sheet | 2 | 0/2 | 1/2 | 1/2 | 0 |
| csv | 1 | 0/1 | 1/1 | 0/1 | 0 |
| customer_first | 5 | 1/5 | 1/5 | 3/5 | 1 |
| customer_missing | 1 | 0/1 | 1/1 | 0/1 | 0 |
| date_at_end | 6 | 2/6 | 5/6 | 5/6 | 0 |
| date_in_caption | 1 | 1/1 | 1/1 | 1/1 | 0 |
| date_missing_from_text_layer | 1 | 0/1 | 0/1 | 1/1 | 0 |
| date_only_in_certificate | 1 | 0/1 | 1/1 | 0/1 | 0 |
| deadline_date | 4 | 3/4 | 4/4 | 3/4 | 1 |
| deadline_in_body | 6 | 1/5 | 3/5 | 5/6 | 3 |
| dear_colleague | 1 | 1/1 | 1/1 | 1/1 | 0 |
| dear_sir_madam | 1 | 0/1 | 1/1 | 0/1 | 0 |
| decision_letter | 1 | 0/1 | 1/1 | 0/1 | 0 |
| decision_numbers_look_like_dates | 1 | 0/1 | 1/1 | 0/1 | 1 |
| direction | 1 | 1/1 | 1/1 | 1/1 | 0 |
| docket_stamp | 1 | 0/1 | 1/1 | 1/1 | 0 |
| due_date | 2 | 1/2 | 1/2 | 2/2 | 0 |
| ecf_header_text | 1 | 1/1 | 1/1 | 1/1 | 0 |
| effective_date_differs | 1 | 0/1 | 1/1 | 0/1 | 0 |
| email | 2 | 1/2 | 2/2 | 2/2 | 0 |
| email_thread | 1 | 0/1 | 1/1 | 1/1 | 0 |
| enclosures_not_included | 1 | 1/1 | 1/1 | 1/1 | 0 |
| enforcement_notice | 1 | 0/1 | 0/1 | 1/1 | 0 |
| engraved_vignette | 1 | 0/1 | 0/1 | 0/1 | 0 |
| file_number | 1 | 1/1 | 1/1 | 1/1 | 0 |
| filing_stamps | 1 | 1/1 | 1/1 | 1/1 | 0 |
| flight_dates | 2 | 2/2 | 2/2 | 2/2 | 0 |
| foi_response | 2 | 2/2 | 2/2 | 2/2 | 0 |
| footnote_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| form | 2 | 1/2 | 1/2 | 2/2 | 0 |
| government_issuer | 1 | 0/1 | 0/1 | 1/1 | 0 |
| handwritten | 4 | 0/4 | 0/4 | 1/4 | 0 |
| handwritten_annotation | 3 | 0/3 | 3/3 | 1/3 | 0 |
| handwritten_date | 1 | 0/1 | 0/1 | 1/1 | 0 |
| header_fields | 1 | 0/1 | 1/1 | 1/1 | 0 |
| hearing_date_in_body | 2 | 0/2 | 1/2 | 2/2 | 1 |
| hidden_sheets | 1 | 0/1 | 0/1 | 1/1 | 1 |
| historic | 5 | 0/5 | 0/5 | 1/5 | 1 |
| historical | 6 | 3/6 | 6/6 | 5/6 | 0 |
| image | 6 | 3/6 | 6/6 | 5/6 | 0 |
| image_only | 2 | 1/2 | 2/2 | 2/2 | 0 |
| image_only_body | 1 | 1/1 | 1/1 | 1/1 | 0 |
| improvement_notice | 1 | 0/1 | 0/1 | 1/1 | 0 |
| inside_address_at_end | 1 | 0/1 | 1/1 | 0/1 | 1 |
| invoice | 10 | 3/10 | 5/10 | 4/10 | 1 |
| iso_dates | 1 | 0/1 | 1/1 | 1/1 | 0 |
| jpeg | 4 | 1/4 | 1/4 | 2/4 | 0 |
| junk_ocr_layer | 1 | 0/1 | 0/1 | 0/1 | 0 |
| large_image | 1 | 0/1 | 0/1 | 0/1 | 0 |
| legacy_doc | 2 | 1/2 | 2/2 | 2/2 | 0 |
| letter | 23 | 11/23 | 20/23 | 17/23 | 4 |
| letter_format | 2 | 1/2 | 2/2 | 1/2 | 1 |
| letterhead | 2 | 1/2 | 2/2 | 1/2 | 1 |
| letterhead_logo | 1 | 1/1 | 1/1 | 1/1 | 0 |
| letterhead_names_people | 1 | 1/1 | 1/1 | 1/1 | 0 |
| line_item_dates | 5 | 3/5 | 4/5 | 3/5 | 1 |
| live_date_field | 1 | 1/1 | 1/1 | 1/1 | 0 |
| local_government | 2 | 1/2 | 1/2 | 2/2 | 1 |
| lockbox | 2 | 2/2 | 2/2 | 2/2 | 0 |
| logo | 1 | 0/1 | 0/1 | 1/1 | 0 |
| logo_trap | 1 | 1/1 | 1/1 | 1/1 | 0 |
| long_document | 2 | 1/2 | 2/2 | 1/2 | 0 |
| many_dates | 3 | 2/3 | 3/3 | 2/3 | 1 |
| memo | 1 | 0/1 | 0/1 | 1/1 | 1 |
| metadata_date_trap | 5 | 2/5 | 5/5 | 4/5 | 0 |
| metadata_title_trap | 3 | 2/3 | 3/3 | 2/3 | 1 |
| microfilm_targets | 1 | 0/1 | 0/1 | 0/1 | 0 |
| mislabelled_source | 1 | 1/1 | 1/1 | 1/1 | 0 |
| misleading_metadata | 1 | 0/1 | 1/1 | 0/1 | 0 |
| modern | 8 | 4/8 | 7/8 | 5/8 | 1 |
| msg | 2 | 1/2 | 2/2 | 2/2 | 0 |
| multi_page | 3 | 2/3 | 3/3 | 2/3 | 0 |
| multi_recipient | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multi_round | 1 | 0/1 | 0/1 | 1/1 | 1 |
| multiple_parties_side | 2 | 1/2 | 2/2 | 1/2 | 0 |
| multiple_recipients | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multiple_senders | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multiple_signatories | 1 | 1/1 | 1/1 | 1/1 | 0 |
| named_person_at_org | 10 | 5/10 | 8/10 | 7/10 | 2 |
| network_logo | 1 | 1/1 | 1/1 | 1/1 | 0 |
| no_explicit_title | 3 | 0/3 | 1/3 | 0/3 | 1 |
| no_issuer_in_text | 2 | 0/2 | 1/2 | 0/2 | 0 |
| no_letterhead_on_letter | 1 | 0/1 | 0/1 | 0/1 | 0 |
| no_specific_addressee | 1 | 1/1 | 1/1 | 1/1 | 0 |
| no_title | 1 | 0/1 | 1/1 | 1/1 | 0 |
| no_title_word | 1 | 0/1 | 1/1 | 0/1 | 0 |
| notice | 19 | 9/18 | 16/18 | 16/19 | 3 |
| notice_of_appeal | 1 | 1/1 | 1/1 | 1/1 | 0 |
| notice_of_decision | 2 | 2/2 | 2/2 | 2/2 | 0 |
| notice_of_determination | 1 | 1/1 | 1/1 | 1/1 | 0 |
| notice_of_hearing | 2 | 0/2 | 1/2 | 2/2 | 1 |
| notice_of_removal | 2 | 1/2 | 2/2 | 1/2 | 0 |
| notice_of_violation | 1 | 0/1 | 1/1 | 0/1 | 1 |
| numeric_date | 1 | 0/1 | 0/1 | 0/1 | 1 |
| ocr_layer | 2 | 0/2 | 0/2 | 2/2 | 1 |
| ocr_text_layer | 3 | 0/3 | 2/3 | 1/3 | 1 |
| on_behalf_of_client | 3 | 1/3 | 2/3 | 2/3 | 1 |
| order_date | 1 | 0/1 | 0/1 | 1/1 | 0 |
| organization_issuer | 1 | 0/1 | 1/1 | 1/1 | 0 |
| payment_advice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| penalty_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| pgp_signed | 1 | 0/1 | 1/1 | 1/1 | 0 |
| plain_text | 2 | 1/2 | 2/2 | 2/2 | 0 |
| posted_notice | 3 | 1/3 | 3/3 | 2/3 | 0 |
| print_field_trap | 1 | 0/1 | 0/1 | 0/1 | 0 |
| printed_form | 2 | 0/2 | 0/2 | 1/2 | 1 |
| printer_credit | 1 | 0/1 | 0/1 | 0/1 | 1 |
| public_notice | 5 | 1/4 | 3/4 | 4/5 | 2 |
| publication_number_year_differs | 1 | 1/1 | 1/1 | 1/1 | 0 |
| quaker_date | 1 | 0/1 | 0/1 | 0/1 | 0 |
| quoted_third_party | 1 | 0/1 | 1/1 | 1/1 | 0 |
| rasterized_born_digital | 1 | 1/1 | 1/1 | 1/1 | 0 |
| re_line_references_document | 4 | 1/4 | 3/4 | 3/4 | 0 |
| receipt | 1 | 0/1 | 0/1 | 1/1 | 0 |
| receipted | 3 | 0/3 | 0/3 | 1/3 | 0 |
| received_stamp | 1 | 0/1 | 1/1 | 0/1 | 0 |
| recipient_by_domain_only | 1 | 1/1 | 1/1 | 1/1 | 0 |
| redacted | 2 | 1/2 | 2/2 | 1/2 | 0 |
| redacted_addressee | 2 | 2/2 | 2/2 | 2/2 | 0 |
| redactions | 1 | 0/1 | 1/1 | 1/1 | 0 |
| reference_numbers | 1 | 1/1 | 1/1 | 1/1 | 0 |
| reference_numbers_look_like_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| relative_dates | 1 | 1/1 | 1/1 | 1/1 | 0 |
| remit_letter | 1 | 0/1 | 1/1 | 0/1 | 1 |
| remit_to | 5 | 3/5 | 4/5 | 3/5 | 2 |
| remit_to_bank | 3 | 1/3 | 2/3 | 2/3 | 0 |
| renamed_firm | 1 | 0/1 | 1/1 | 1/1 | 0 |
| report_parameters | 1 | 1/1 | 1/1 | 1/1 | 0 |
| revenue_stamp | 1 | 0/1 | 0/1 | 0/1 | 0 |
| review | 3 | 0/3 | 1/3 | 1/3 | 1 |
| rotated_page | 1 | 0/1 | 1/1 | 0/1 | 0 |
| scanned | 15 | 2/15 | 9/15 | 8/15 | 5 |
| sender_block_above_addressee | 1 | 0/1 | 1/1 | 0/1 | 1 |
| sender_in_signoff_only | 1 | 0/1 | 1/1 | 1/1 | 0 |
| service_period | 2 | 1/2 | 1/2 | 2/2 | 0 |
| signatory_trap | 3 | 1/3 | 3/3 | 1/3 | 1 |
| signatory_vs_org | 1 | 0/1 | 0/1 | 0/1 | 0 |
| signature_on_later_page | 3 | 1/3 | 3/3 | 2/3 | 1 |
| signature_only_no_typed_name | 3 | 2/3 | 3/3 | 3/3 | 0 |
| small_print_date | 1 | 0/1 | 1/1 | 0/1 | 0 |
| spreadsheet | 2 | 0/2 | 0/2 | 1/2 | 1 |
| staff_names | 2 | 1/2 | 2/2 | 1/2 | 0 |
| stamp_date_only | 2 | 0/2 | 0/2 | 2/2 | 1 |
| stamp_dates | 2 | 0/2 | 1/2 | 1/2 | 0 |
| statement | 4 | 1/4 | 3/4 | 1/4 | 1 |
| struck_through | 1 | 0/1 | 0/1 | 0/1 | 0 |
| subject_is_product | 1 | 1/1 | 1/1 | 1/1 | 0 |
| tables | 1 | 0/1 | 1/1 | 0/1 | 0 |
| third_party_named_in_subject | 1 | 0/1 | 1/1 | 0/1 | 1 |
| tiff | 4 | 1/4 | 3/4 | 3/4 | 0 |
| trading_name | 1 | 1/1 | 1/1 | 1/1 | 0 |
| transmittal_letter | 1 | 0/1 | 1/1 | 1/1 | 0 |
| tribunal | 2 | 2/2 | 2/2 | 2/2 | 0 |
| trustee_party | 1 | 1/1 | 1/1 | 1/1 | 0 |
| two_digit_year | 4 | 2/4 | 3/4 | 2/4 | 1 |
| two_letterhead_seals | 1 | 1/1 | 1/1 | 1/1 | 0 |
| two_signatories | 1 | 1/1 | 1/1 | 1/1 | 0 |
| typed | 1 | 0/1 | 0/1 | 0/1 | 1 |
| typist_footer_date | 1 | 0/1 | 1/1 | 0/1 | 1 |
| typo_date | 1 | 0/1 | 1/1 | 1/1 | 0 |
| uk | 7 | 4/7 | 6/7 | 5/7 | 0 |
| uk_date_format | 2 | 0/2 | 1/2 | 1/2 | 0 |
| undated | 1 | – | – | 1/1 | 1 |
| us_state | 5 | 1/4 | 3/4 | 4/5 | 3 |
| utility_commission | 1 | 0/1 | 1/1 | 0/1 | 1 |
| vat | 2 | 1/2 | 1/2 | 2/2 | 0 |
| watermark | 1 | 1/1 | 1/1 | 1/1 | 0 |
| wide_image | 1 | 0/1 | 0/1 | 1/1 | 0 |
| windows-1252 | 1 | 0/1 | 1/1 | 0/1 | 0 |
| windows_1252_encoding | 1 | 1/1 | 1/1 | 1/1 | 0 |
| yearless_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| zero_amount | 2 | 1/2 | 2/2 | 1/2 | 1 |

## Routes

- **Pages:** fast 74 · layout 14 · ocr 40 · ocr_regions 6
- **Documents by route class:** fast 27 · layout 6 · ocr 21 · ocr_regions 3

## Where the time goes

| Stage | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `total_ms` | 57 | 40.02 s | 63.69 s | 73.93 s |
| `extraction_wall_ms` | 57 | 18.1 ms | 6.42 s | 20.76 s |
| `worker_total_ms` | 57 | 17.8 ms | 6.42 s | 20.75 s |
| `worker_snapshot_ms` | 57 | 0.24 ms | 3.0 ms | 13.0 ms |
| `worker_parse_ms` | 57 | 3.2 ms | 27.0 ms | 739.7 ms |
| `worker_analysis_ms` | 57 | 0.20 ms | 1.9 ms | 5.5 ms |
| `worker_render_ms` | 57 | 0.00 ms | 554.8 ms | 2.11 s |
| `worker_image_decode_ms` | 57 | 0.00 ms | 92.4 ms | 1.18 s |
| `worker_ocr_ms` | 57 | 0.00 ms | 6.22 s | 20.48 s |
| `worker_ocr_encode_ms` | 57 | 0.00 ms | 713.4 ms | 1.87 s |
| `worker_ocr_engine_ms` | 57 | 0.00 ms | 5.51 s | 18.50 s |
| `worker_vision_ms` | 57 | 0.00 ms | 12.4 ms | 34.0 ms |
| `analyze_wall_ms` | 57 | 38.51 s | 62.24 s | 68.33 s |
| `distill_ms` | 57 | 3.4 ms | 29.1 ms | 32.3 ms |
| `prompt_ms` | 57 | 0.03 ms | 0.04 ms | 0.05 ms |
| `inference_ms` | 57 | 38.48 s | 62.08 s | 68.27 s |
| `prefill_ms` | 57 | 21.17 s | 40.87 s | 52.72 s |
| `generation_ms` | 57 | 17.39 s | 22.23 s | 24.83 s |
| `validation_ms` | 57 | 20.9 ms | 74.6 ms | 122.3 ms |
| `naming_ms` | 57 | 0.37 ms | 3.3 ms | 3.8 ms |
| `index_ms` | 57 | 3.2 ms | 26.1 ms | 28.3 ms |
| `retrieval_ms` | 57 | 0.03 ms | 1.5 ms | 2.9 ms |

| Measure | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `prefill_tok_per_s` | 57 | 35.3 tok/s | 36.0 tok/s | 36.1 tok/s |
| `generation_tok_per_s` | 57 | 5.3 tok/s | 5.5 tok/s | 5.6 tok/s |
| `prompt_tokens` | 57 | 754 | 1474 | 1881 |
| `cached_tokens` | 57 | 477 | 477 | 477 |
| `generated_tokens` | 57 | 91 | 119 | 134 |
| `estimated_prompt_tokens` | 57 | 1318 | 2220 | 2346 |
| `model_requests` | 57 | 1 | 1 | 1 |
| `redistillations` | 57 | 0 | 0 | 0 |
| `source_characters` | 57 | 2713 | 36778 | 45033 |
| `digest_characters` | 57 | 2087 | 5156 | 5561 |
| `prompt_characters` | 57 | 4136 | 7205 | 7616 |
| `worker_ocr_pages` | 57 | 0 | 4 | 8 |
| `worker_ocr_passes` | 57 | 0 | 4 | 9 |
| `worker_orientation_passes` | 57 | 0 | 4 | 8 |
| `worker_rendered_pixels` | 57 | 0 | 33660000 | 67578072 |
| `index_units` | 57 | 31 | 258 | 464 |
| `context_units` | 57 | 22 | 58 | 74 |
| `context_tokens` | 57 | 729 | 1632 | 1756 |

## Extraction time

| Route class | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fast | 27 | 3.9 ms | 23.0 ms | 3.4 ms | 21.4 ms | 21.0 ms | 0.90 ms | 0.00 ms | 0.00 ms |
| layout | 6 | 6.5 ms | 42.6 ms | 6.0 ms | 41.1 ms | 33.9 ms | 5.5 ms | 0.00 ms | 0.00 ms |
| ocr_regions | 3 | 1.98 s | 1.98 s | 1.98 s | 1.98 s | 24.1 ms | 1.9 ms | 321.3 ms | 1.84 s |
| ocr | 21 | 1.99 s | 7.98 s | 1.99 s | 7.98 s | 26.6 ms | 1.1 ms | 1.22 s | 7.83 s |

| Pages | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 27 | 975.1 ms | 4.52 s | 974.8 ms | 4.52 s | 26.6 ms | 1.1 ms | 121.6 ms | 4.23 s |
| 2-4 | 22 | 8.7 ms | 5.41 s | 8.3 ms | 5.41 s | 24.1 ms | 1.9 ms | 499.1 ms | 5.24 s |
| 5-9 | 6 | 15.1 ms | 20.76 s | 14.7 ms | 20.75 s | 16.5 ms | 1.6 ms | 2.11 s | 20.48 s |
| 10-24 | 2 | 23.0 ms | 42.6 ms | 21.4 ms | 41.1 ms | 33.9 ms | 5.5 ms | 0.00 ms | 0.00 ms |

| Kind | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| invoice | 10 | 1.35 s | 5.52 s | 1.35 s | 5.52 s | 26.6 ms | 1.9 ms | 331.8 ms | 5.45 s |
| letter | 23 | 11.2 ms | 4.66 s | 10.3 ms | 4.66 s | 21.0 ms | 1.6 ms | 499.1 ms | 4.51 s |
| notice | 19 | 16.5 ms | 20.76 s | 16.2 ms | 20.75 s | 33.9 ms | 5.5 ms | 2.11 s | 20.48 s |
| receipt | 1 | 1.47 s | 1.47 s | 1.47 s | 1.47 s | 12.5 ms | 0.07 ms | 0.00 ms | 1.44 s |
| statement | 4 | 2.0 ms | 1.93 s | 1.3 ms | 1.93 s | 3.4 ms | 1.2 ms | 121.6 ms | 1.79 s |

Over the documents that completed. Wall is the runner's clock around the request; worker is the worker's own total. OCR is summed over the pages, so when the worker reads pages in parallel it can exceed the total. A document's route class is the most expensive route any of its pages took (ocr > ocr_regions > layout > fast), or `unrouted` when the worker sent no layouts.

## Memory

| Process | Typical peak (p50) | Highest peak | During |
| --- | ---: | ---: | ---: |
| Parser worker | 237 MB | 794 MB | real3-notice-02 |
| Model server | 6134 MB | 6135 MB | real3-office-15 |
| Benchmark (engine) | 20 MB | 20 MB | real3-office-15 |

Resident memory sampled every 25 ms per document; a spike shorter than that can be missed.

## Misses (32)

- **real3-letter-03**: expected `2023-03-28 Decision Letter to Good Energy.pdf`, got `2023-03-28 This letter sets out the decision for Good Electricity Gas Limited.pdf` · **filed without review**
- **real3-letter-06**: expected `1976-11-18 Letter to Los Alamos Scientific Laboratory.pdf`, got `1976-11-18 Document - Pacific Northwest Laboratories.pdf` · review: TYPE_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, LOW_CONFIDENCE
- **real3-letter-07**: expected `1966-01-04 Letter to U.S. Atomic Energy Commission.pdf`, got `Document.pdf` · review: TYPE_MISSING, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, PARSER_WARNING, LOW_CONFIDENCE
- **real3-letter-08**: expected `1995-12-07 Decision Letter to Bloom & Kreten.pdf`, got `1995-12-07 Letter to Bernhard Kreten.pdf` · trap: party Bernhard Kreten (addressee, attorney at Bloom & Kreten) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real3-letter-09**: expected `1992-12-24 Objection Letter to Pilcher and Pilcher.pdf`, got `Document - U.S. Department of Justice Civil Rights Division.pdf` · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED, PARTY_UNSUPPORTED
- **real3-letter-10**: expected `2019-03-28 Response Letter to Transport Scotland.pdf`, got `2019-03-28 Letter to Network Rail Scotland.pdf` · trap: party Network Rail (subject of the letter, not its recipient) · review: TYPE_MISSING, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real3-letter-13**: expected `1908-02-11 Transmittal Letter to Wright Brothers.tif`, got `1908-02-11 Document - Wright Brothers.tif` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real3-notice-01**: expected `2024-02-19 Improvement Notice for The Chiltern Railway Company Limited.pdf`, got `Improvement Notice for The Chiltern Railway Company Limited.pdf` · review: DATE_UNSUPPORTED, PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED
- **real3-notice-02**: expected `2007-04-24 Notice of Public Site Visit and Informational Hearing for City of Victorville.pdf`, got `2007-04-24 Application for Certification for the Victorville for City of Victorville.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED
- **real3-notice-05**: expected `2008-09-22 Notice of Hearing from Mojave Desert Air Quality Management District.pdf`, got `2008-10-27 Notice of Hearing for Mojave Desert Air Quality Management District.pdf` · trap: date 2008-10-27 (date of the public hearing) · review: DATE_UNSUPPORTED, LOW_CONFIDENCE
- **real3-notice-07**: expected `2023-04-07 Notice of Violation for PacifiCorp.pdf`, got `2023-04-07 Notice of Violation to Shelley McCoy.pdf` · trap: party Shelley McCoy (PacifiCorp's Director, Regulation, to whom the letter is addressed) · review: PARTY_UNSUPPORTED
- **real3-notice-08**: expected `2018-01-26 Notice of Removal between Olymbec USA LLC and CWFS Insight LLC.pdf`, got `2018-01-26 Notice of Removal for Olymbec USA LLC.pdf` · review: PARTY_UNSUPPORTED
- **real3-notice-13**: expected `1831-11-01 Notice from Parish of Clerkenwell.jpg`, got `1831-11-01 Document.jpg` · review: TYPE_UNSUPPORTED, DATE_IMPLAUSIBLE, PARTY_UNSUPPORTED, DESCRIPTION_INVALID
- **real3-notice-14**: expected `1867-05-01 Notice from Assessors of the City of Boston.tif`, got `1867-05-01 Notice to the Inhabitants and Other Persons Liable to Pay from City of Boston.tif` · review: DATE_IMPLAUSIBLE, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real3-notice-15**: expected `2026-10-14 Errata Notice from The FreeBSD Project.txt`, got `2026-10-14 Errata Notice for FreeBSD Project.txt` · **filed without review**
- **real3-invoice-05**: expected `2025-12-05 Statement of Account from Lotus Communications Corp.pdf`, got `2025-12-05 Statement of Account from Media Financial Services.pdf` · trap: party Media Financial Services (agency addressed on the statement) · review: PARTY_UNSUPPORTED
- **real3-invoice-06**: expected `2014-09-26 Invoice from Idox Software Limited.pdf`, got `2014-09-28 Invoice from Idox Sofiware Limited.pdf` · **filed without review**
- **real3-invoice-07**: expected `2017-03-08 Invoice from East Lothian Council.pdf`, got `2017-03-08 Invoice.pdf` · review: DATE_AMBIGUOUS, PARTY_UNSUPPORTED, PARTY_MISSING, LOW_CONFIDENCE
- **real3-invoice-08**: expected `2017-06-02 Invoice from Aberdeen City Council.pdf`, got `2017-06-02 Invoice from Pefredacted-Elections Team.pdf` · review: DATE_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, LOW_CONFIDENCE
- **real3-invoice-09**: expected `1916-11-04 Invoice from Mergenthaler Linotype Co.pdf`, got `INVOICE from Panama City PUB Co.pdf` · trap: party Panama City Pub Co (customer, typed above the issuer) · review: DATE_UNSUPPORTED
- **real3-invoice-10**: expected `1868-10-01 Bill from Haviland & Sutton.tif`, got `Document from M Covace dby.tif` · review: TYPE_MISSING, DATE_UNSUPPORTED, DESCRIPTION_INVALID, PARSER_WARNING
- **real3-invoice-11**: expected `1850-07-11 Bill from Henry D. Gray & Son.jpg`, got `Document.jpg` · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real3-invoice-12**: expected `1848-11-14 Bill from Veranda Hotel.jpg`, got `Document.jpg` · review: TYPE_MISSING, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, DESCRIPTION_INVALID, PARSER_WARNING, LOW_CONFIDENCE
- **real3-invoice-15**: expected `1848-07-01 Receipt from Post-Office, Duxbury, Mass.jpg`, got `Document - POST-OFFICE.jpg` · review: TYPE_UNSUPPORTED, DATE_UNSUPPORTED, PARSER_WARNING, LOW_CONFIDENCE
- **real3-office-01**: expected `2026-09-14 Consultation Response to London Borough of Islington.docx`, got `2026-09-14 Letter from London Borough of Islington.docx` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING
- **real3-office-02**: expected `2018-11-21 Remit Letter to NHS Pay Review Body.docx`, got `2018-11-21 Letter to Office of Manpower Economics.docx` · trap: party Office of Manpower Economics (secretariat whose address is used) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING
- **real3-office-06**: expected `2014-02-20 Circular from Home Office.doc`, got `2014-02-20 report of the Winsor Review for Home Secretary.doc` · review: TYPE_UNSUPPORTED, TYPE_INFERRED
- **real3-office-07**: expected `2020-04-28 Update Letter to Home Affairs Select Committee.odt`, got `2020-04-28 Letter to Home Secretary.odt` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED
- **real3-office-10**: expected `2018-03-21 Email to Royal Borough of Greenwich.msg`, got `2018-03-21 Email from Smith, Greg (GVA).msg` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, LOW_CONFIDENCE
- **real3-office-12**: expected `2012-09-30 Statement of Financial Position from Province of British Columbia.xlsx`, got `Statement of Financial Position.xlsx` · review: DATE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real3-office-13**: expected `2026-08-07 Air Quality Memo to Stoney Wood Property Developments Ltd.xlsx`, got `2025-11-01 Air Quality Memo GLA Consultation to Stoney Wood Property Developments Ltd.xlsx` · trap: date 2025-11-01 (date of the applicant's air quality assessment) · review: PARTY_UNSUPPORTED
- **real3-office-14**: expected `2017-03-31 Condensed Statement of Financial Position from Administrative Tribunals Support Service of Canada.csv`, got `2017-03-31 Condensed Statement of Financial Position unaudited.csv` · **filed without review**

## How to compare

Keep this run's JSON, make the change, run again, then:

```text
intern-bench compare --before before.json --after after.json --markdown diff.md
```

It recomputes every rate and count over the documents both runs scored, lists each document whose score flipped, and gives the change in p50/p95 of every stage over the documents both completed - between two live runs only, since a replay's timings are its recording's. `intern-bench report --input report.json --markdown report.md` re-renders this page from the JSON.
