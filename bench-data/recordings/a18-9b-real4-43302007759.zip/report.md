# InternBench: live run

- **Run:** 2026-11-12T20:40:58Z · commit `343ee39b8e`
- **Machine:** AMD EPYC 9V74 80-Core Processor, 4 logical cores, 15.6 GB RAM, linux (Ubuntu 24.04.5 LTS)
- **Model:** `intern-local` · 5.68 GB · sha256 `03b74727a860`
- **Corpus:** 52 documents · 52 completed · gold `5bd7851dd8`
- **Wall time:** 2471.49 s for the whole run, the worker's start included

## Scorecard

| Score | Result |
| --- | ---: |
| Filename (the whole name) | 27/49 (55.1%) |
| Document type | 51/52 (98.1%) |
| Date | 44/49 (89.8%) |
| Date role (when the reviewed date was chosen) | 18/44 (40.9%) |
| Parties | 39/52 (75.0%) |
| Relation word (when parties were named) | 42/50 (84.0%) |
| Party in the right role (when parties were named) | 10/23 (43.5%) |
| Ready / review routing | 16/34 (47.1%) |
| Description states nothing false | 52/52 (100.0%) |
| Description is specific | 42/52 (80.8%) |
| Description specificity | 74.4% (mean of 52) |
| Evidence recall (model's quotes) | 65.7% (mean of 52) |
| Digest recall (facts reaching the digest) | 93.3% (mean of 52) |
| Prompt recall (facts reaching the prompt sent) | 90.7% (mean of 52) |
| Sent to review | 75.0% of 52 completed |

## Phase 3 scorecard

| Figure | Value | Docs |
| --- | ---: | ---: |
| Long-document filename accuracy (10+ pages) | 50.0% | 10 |
| Complex-document filename accuracy | – | 0 |
| Description completeness | – | 0 |
| Unsupported-fact rate (documents) | 59.6% | 52 |
| Review rate | 75.0% | 52 |
| Evidence recall | 65.7% | 52 |
| Total latency p50 | 38.93 s | 52 |
| Total latency p95 | 123.07 s | 52 |
| Generation latency p50 | 16.02 s | 52 |
| Generation latency p95 | 20.76 s | 52 |
| Generated tokens p50 | 88 | 52 |
| Generated tokens p95 | 111 | 52 |
| Prompt tokens p50 | 852 | 52 |

Long: 10 pages or more. Complex: any of `referenced_agreement`, `middle_fact`, `multi_column`, `layout_parties`, `irrelevant_names`, `information_dense`, `stream_order`, `date_in_table`, `key_value`, `complex_pdf`. Unsupported-fact rate: documents with any `*_UNSUPPORTED` review reason. Latency and tokens over the documents that completed.

## Safety

| Check | Count |
| --- | ---: |
| Filed without review under a wrong name | 3 of 49 |
| Trap date chosen | 3 of 52 |
| Forbidden party named | 9 of 52 |
| Spurious parties named | 9 |
| Description states a known-wrong fact | 0 |
| Unsupported description claims | 0 of 140 (0.0%) |
| Right name sent to review anyway | 7 of 29 |
| Sent to review for an unsupported fact | 31 of 52 |

## By kind

| Kind | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| invoice | 14 | 8/13 | 11/13 | 13/14 | 8/13 | 50.0% | 38.93 s | 54.44 s |
| letter | 23 | 12/22 | 19/22 | 14/23 | 2/10 | 100.0% | 37.93 s | 130.38 s |
| notice | 13 | 5/12 | 12/12 | 10/13 | 5/10 | 61.5% | 43.30 s | 71.67 s |
| statement | 2 | 2/2 | 2/2 | 2/2 | 1/1 | 50.0% | 30.27 s | 123.07 s |

## By text layer

| Text layer | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| native | 29 | 16/28 | 26/28 | 22/29 | 11/22 | 65.5% | 38.93 s | 130.38 s |
| office | 11 | 7/9 | 9/9 | 9/11 | 2/3 | 100.0% | 33.24 s | 51.36 s |
| scan | 10 | 2/10 | 7/10 | 6/10 | 3/9 | 90.0% | 66.70 s | 123.07 s |
| text | 2 | 2/2 | 2/2 | 2/2 | – | 0.0% | 30.27 s | 48.41 s |

## By page count

| Pages | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 21 | 10/19 | 18/19 | 14/21 | 5/10 | 76.2% | 30.86 s | 54.16 s |
| 2-4 | 16 | 10/15 | 14/15 | 11/16 | 4/11 | 87.5% | 42.40 s | 57.82 s |
| 5-9 | 5 | 2/5 | 3/5 | 5/5 | 3/5 | 40.0% | 38.93 s | 43.62 s |
| 10-24 | 7 | 2/7 | 6/7 | 6/7 | 3/6 | 57.1% | 66.78 s | 71.67 s |
| 25-49 | 2 | 2/2 | 2/2 | 2/2 | 1/2 | 100.0% | 123.07 s | 130.38 s |
| 100+ | 1 | 1/1 | 1/1 | 1/1 | – | 100.0% | 141.81 s | 141.81 s |

## By slice

| Slice | Docs | Filename | Date | Parties | Routing | Unsafe ready | p50 total | p95 total | p50 generation | p95 generation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| long | 10 | 5/10 | 9/10 | 9/10 | 4/8 | 1 of 10 | 68.47 s | 141.81 s | 16.98 s | 21.45 s |

`long`: 10 pages or more. `complex`: any of the categories listed under the phase 3 scorecard. A document may be in both.

## By challenge

| Category | Docs | Filename | Date | Parties | Traps sprung |
| --- | ---: | ---: | ---: | ---: | ---: |
| acknowledgement | 3 | 2/3 | 3/3 | 3/3 | 0 |
| addressee_redacted | 6 | 4/6 | 6/6 | 4/6 | 2 |
| agency_billing | 8 | 4/8 | 6/8 | 8/8 | 1 |
| attachment_title_trap | 1 | 0/1 | 1/1 | 0/1 | 1 |
| attachments | 11 | 5/11 | 10/11 | 9/11 | 2 |
| body_recounts_events | 1 | – | – | 1/1 | 1 |
| born_digital | 29 | 16/28 | 26/28 | 22/29 | 6 |
| brand_vs_legal_name | 3 | 3/3 | 3/3 | 3/3 | 0 |
| broadcast_invoice | 8 | 4/8 | 6/8 | 8/8 | 1 |
| broken_text_layer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| caption | 4 | 2/4 | 4/4 | 2/4 | 0 |
| card_statement | 1 | 1/1 | 1/1 | 1/1 | 0 |
| certificate_of_service | 2 | 1/2 | 2/2 | 1/2 | 0 |
| certified_mail | 4 | 0/4 | 4/4 | 4/4 | 0 |
| citation | 2 | 2/2 | 2/2 | 2/2 | 0 |
| competing_dates | 40 | 24/40 | 36/40 | 32/40 | 7 |
| contract_numbers | 1 | 0/1 | 1/1 | 0/1 | 1 |
| court_filing | 4 | 2/4 | 4/4 | 2/4 | 0 |
| cover_letter | 4 | 0/4 | 4/4 | 4/4 | 0 |
| customer_first | 1 | 0/1 | 1/1 | 0/1 | 0 |
| customer_redacted | 1 | 1/1 | 1/1 | 1/1 | 0 |
| date_at_end | 1 | 1/1 | 1/1 | 1/1 | 0 |
| date_stamp | 3 | 1/3 | 1/3 | 1/3 | 1 |
| deadline_in_body | 8 | 3/8 | 8/8 | 8/8 | 0 |
| doc | 3 | 2/2 | 2/2 | 3/3 | 1 |
| docket_number | 3 | 2/3 | 3/3 | 3/3 | 0 |
| docx | 4 | 3/4 | 4/4 | 4/4 | 0 |
| doubled_ocr_text | 4 | 0/4 | 4/4 | 4/4 | 0 |
| due_date | 4 | 4/4 | 4/4 | 4/4 | 0 |
| duplicate_marking | 1 | 1/1 | 1/1 | 1/1 | 0 |
| email | 2 | 1/2 | 2/2 | 1/2 | 1 |
| embedded_second_letter | 1 | 0/1 | 0/1 | 0/1 | 1 |
| enclosure_list | 1 | – | – | 1/1 | 1 |
| esignature | 1 | 1/1 | 1/1 | 1/1 | 0 |
| fee_invoice | 2 | 0/1 | 1/1 | 1/2 | 1 |
| file_name_date_trap | 1 | 1/1 | 1/1 | 1/1 | 0 |
| filed_stamp | 4 | 2/4 | 4/4 | 2/4 | 0 |
| foi_release | 1 | 1/1 | 1/1 | 1/1 | 0 |
| foi_response | 15 | 8/14 | 11/14 | 9/15 | 6 |
| forecaster_initials | 1 | 1/1 | 1/1 | 1/1 | 0 |
| form | 2 | 2/2 | 2/2 | 2/2 | 0 |
| group_recipient | 1 | 1/1 | 1/1 | 1/1 | 0 |
| illegible_date | 1 | 0/1 | 0/1 | 0/1 | 1 |
| image_only | 2 | 1/2 | 1/2 | 1/2 | 1 |
| internal_email | 2 | 1/2 | 2/2 | 1/2 | 1 |
| invoice | 14 | 8/13 | 11/13 | 13/14 | 2 |
| issuer_in_logo | 1 | 0/1 | 1/1 | 0/1 | 0 |
| journal_number | 1 | – | – | 0/1 | 1 |
| journalist_addressee | 1 | 1/1 | 1/1 | 1/1 | 0 |
| letter | 23 | 12/22 | 19/22 | 14/23 | 9 |
| letterhead_names | 1 | 0/1 | 1/1 | 0/1 | 1 |
| line_item_dates | 9 | 5/9 | 7/9 | 9/9 | 1 |
| long_document | 2 | 2/2 | 2/2 | 2/2 | 0 |
| many_dates | 1 | – | – | 1/1 | 1 |
| metadata_date_trap | 3 | 2/2 | 2/2 | 3/3 | 1 |
| military_date_format | 1 | 0/1 | 0/1 | 0/1 | 1 |
| modern | 52 | 27/49 | 44/49 | 39/52 | 12 |
| msg | 2 | 1/2 | 2/2 | 1/2 | 1 |
| multiple_addressees | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multiple_documents_in_file | 1 | 1/1 | 1/1 | 1/1 | 0 |
| named_person_at_org | 15 | 7/15 | 13/15 | 8/15 | 5 |
| new_zealand | 4 | 2/4 | 4/4 | 2/4 | 2 |
| no_addressee | 2 | 1/1 | 1/1 | 2/2 | 1 |
| no_issuer_name_in_header | 1 | – | – | 0/1 | 1 |
| no_letterhead_text | 2 | 0/2 | 2/2 | 1/2 | 1 |
| no_signer_name | 1 | 1/1 | 1/1 | 1/1 | 0 |
| nonprofit | 1 | 1/1 | 1/1 | 1/1 | 0 |
| notice | 13 | 5/12 | 12/12 | 10/13 | 1 |
| notice_of_appeal | 4 | 2/4 | 4/4 | 2/4 | 0 |
| numeric_date_dmy | 1 | 1/1 | 1/1 | 1/1 | 0 |
| ocr_text_layer | 8 | 1/8 | 6/8 | 5/8 | 2 |
| odt | 1 | 1/1 | 1/1 | 1/1 | 0 |
| office | 11 | 7/9 | 9/9 | 9/11 | 3 |
| on_behalf_of_client | 2 | 1/2 | 2/2 | 2/2 | 0 |
| ordinal_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| pay_gov | 1 | 0/1 | 1/1 | 0/1 | 0 |
| payment_page | 2 | 2/2 | 2/2 | 2/2 | 0 |
| penalty_notice | 6 | 2/6 | 6/6 | 6/6 | 0 |
| person_in_official_capacity | 3 | 1/3 | 3/3 | 1/3 | 0 |
| plaintiff_appeals | 1 | 1/1 | 1/1 | 1/1 | 0 |
| planning_notice | 1 | 0/1 | 1/1 | 1/1 | 0 |
| political_file | 8 | 4/8 | 6/8 | 8/8 | 1 |
| preliminary_data | 1 | 1/1 | 1/1 | 1/1 | 0 |
| proration_note | 1 | 1/1 | 1/1 | 1/1 | 0 |
| public_notice | 1 | 0/1 | 1/1 | 1/1 | 0 |
| re_line | 3 | 1/3 | 2/3 | 1/3 | 1 |
| re_line_references_document | 1 | 1/1 | 1/1 | 1/1 | 0 |
| redacted | 1 | 1/1 | 1/1 | 1/1 | 0 |
| redacted_signer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| reference_number | 10 | 4/9 | 8/9 | 6/10 | 5 |
| referral | 1 | 1/1 | 1/1 | 1/1 | 0 |
| remit_to_bank | 3 | 3/3 | 3/3 | 3/3 | 0 |
| rtf | 1 | – | – | 0/1 | 1 |
| same_day_order | 1 | 0/1 | 1/1 | 0/1 | 0 |
| scanned | 10 | 2/10 | 7/10 | 6/10 | 3 |
| service_period | 11 | 7/11 | 9/11 | 11/11 | 1 |
| short | 5 | 2/4 | 4/4 | 3/5 | 2 |
| sidebar_metadata | 1 | 0/1 | 1/1 | 1/1 | 0 |
| signature_block_org | 1 | 1/1 | 1/1 | 1/1 | 0 |
| signature_in_caps | 1 | 1/1 | 1/1 | 1/1 | 0 |
| signature_on_later_page | 6 | 3/6 | 5/6 | 3/6 | 3 |
| statement | 2 | 2/2 | 2/2 | 2/2 | 0 |
| system_generated | 1 | – | – | 1/1 | 1 |
| tabular_body | 1 | 1/1 | 1/1 | 1/1 | 0 |
| text | 2 | 2/2 | 2/2 | 2/2 | 0 |
| title_line | 2 | 2/2 | 2/2 | 2/2 | 0 |
| two_digit_year | 8 | 4/8 | 6/8 | 8/8 | 1 |
| txt | 2 | 2/2 | 2/2 | 2/2 | 0 |
| uk | 8 | 5/6 | 6/6 | 7/8 | 2 |
| undated | 3 | – | – | 2/3 | 3 |
| us | 8 | 4/8 | 6/8 | 8/8 | 1 |
| us_city | 3 | 3/3 | 3/3 | 3/3 | 0 |
| us_federal | 12 | 6/11 | 8/11 | 7/12 | 4 |
| us_federal_court | 4 | 2/4 | 4/4 | 2/4 | 0 |
| us_state | 12 | 4/12 | 12/12 | 9/12 | 3 |
| utc_vs_local | 2 | 2/2 | 2/2 | 2/2 | 0 |
| vendor_invoice | 4 | 4/4 | 4/4 | 4/4 | 0 |
| weather_product | 2 | 2/2 | 2/2 | 2/2 | 0 |
| wmo_header | 2 | 2/2 | 2/2 | 2/2 | 0 |
| zero_amount | 1 | – | – | 1/1 | 1 |
| zone_list | 1 | 1/1 | 1/1 | 1/1 | 0 |

## Routes

- **Pages:** fast 113 · layout 103 · ocr 156 · ocr_regions 2
- **Documents by route class:** fast 18 · layout 21 · ocr 11 · ocr_regions 2

## Where the time goes

| Stage | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `total_ms` | 52 | 38.93 s | 123.07 s | 141.81 s |
| `extraction_wall_ms` | 52 | 6.1 ms | 56.06 s | 72.37 s |
| `worker_total_ms` | 52 | 5.6 ms | 56.05 s | 72.36 s |
| `worker_snapshot_ms` | 52 | 0.21 ms | 0.62 ms | 3.5 ms |
| `worker_parse_ms` | 52 | 3.4 ms | 68.9 ms | 97.1 ms |
| `worker_analysis_ms` | 52 | 0.43 ms | 59.9 ms | 100.1 ms |
| `worker_render_ms` | 52 | 0.00 ms | 4.42 s | 10.98 s |
| `worker_image_decode_ms` | 52 | 0.00 ms | 0.00 ms | 0.00 ms |
| `worker_ocr_ms` | 52 | 0.00 ms | 110.36 s | 143.17 s |
| `worker_ocr_encode_ms` | 52 | 0.00 ms | 5.64 s | 8.71 s |
| `worker_ocr_engine_ms` | 52 | 0.00 ms | 101.26 s | 137.25 s |
| `worker_vision_ms` | 52 | 0.00 ms | 0.00 ms | 28.8 ms |
| `analyze_wall_ms` | 52 | 38.12 s | 67.39 s | 79.86 s |
| `distill_ms` | 52 | 1.6 ms | 56.9 ms | 66.4 ms |
| `prompt_ms` | 52 | 0.03 ms | 0.06 ms | 0.07 ms |
| `inference_ms` | 52 | 38.12 s | 67.28 s | 79.75 s |
| `prefill_ms` | 52 | 23.64 s | 50.39 s | 58.29 s |
| `generation_ms` | 52 | 16.02 s | 20.76 s | 21.74 s |
| `validation_ms` | 52 | 5.2 ms | 30.2 ms | 48.7 ms |
| `naming_ms` | 52 | 0.18 ms | 3.1 ms | 4.0 ms |
| `index_ms` | 52 | 1.5 ms | 53.7 ms | 60.7 ms |
| `retrieval_ms` | 52 | 0.03 ms | 3.3 ms | 4.5 ms |

| Measure | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `prefill_tok_per_s` | 52 | 35.9 tok/s | 36.3 tok/s | 36.5 tok/s |
| `generation_tok_per_s` | 52 | 5.4 tok/s | 5.6 tok/s | 5.6 tok/s |
| `prompt_tokens` | 52 | 852 | 1814 | 2116 |
| `cached_tokens` | 52 | 477 | 477 | 546 |
| `generated_tokens` | 52 | 88 | 111 | 118 |
| `estimated_prompt_tokens` | 52 | 1433 | 2241 | 2468 |
| `model_requests` | 52 | 1 | 1 | 1 |
| `redistillations` | 52 | 0 | 0 | 0 |
| `source_characters` | 52 | 2717 | 75251 | 87914 |
| `digest_characters` | 52 | 2064 | 4574 | 4770 |
| `prompt_characters` | 52 | 4113 | 6623 | 6826 |
| `worker_ocr_pages` | 52 | 0 | 29 | 66 |
| `worker_ocr_passes` | 52 | 0 | 29 | 66 |
| `worker_orientation_passes` | 52 | 0 | 29 | 66 |
| `worker_rendered_pixels` | 52 | 0 | 252367280 | 574406515 |
| `index_units` | 52 | 30 | 1694 | 1903 |
| `context_units` | 52 | 26 | 68 | 89 |
| `context_tokens` | 52 | 845 | 1651 | 1877 |

## Extraction time

| Route class | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fast | 18 | 2.6 ms | 69.9 ms | 2.4 ms | 69.7 ms | 68.9 ms | 0.35 ms | 0.00 ms | 0.00 ms |
| layout | 21 | 6.1 ms | 33.9 ms | 5.6 ms | 32.6 ms | 27.7 ms | 11.2 ms | 0.00 ms | 0.00 ms |
| ocr_regions | 2 | 891.4 ms | 1.33 s | 891.0 ms | 1.33 s | 14.7 ms | 0.69 ms | 110.8 ms | 1.16 s |
| ocr | 11 | 5.59 s | 72.37 s | 5.59 s | 72.36 s | 97.1 ms | 100.1 ms | 10.98 s | 143.17 s |

| Pages | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 21 | 3.4 ms | 69.9 ms | 3.0 ms | 69.7 ms | 13.8 ms | 0.98 ms | 0.00 ms | 0.00 ms |
| 2-4 | 16 | 5.8 ms | 4.62 s | 5.5 ms | 4.62 s | 27.3 ms | 3.8 ms | 388.1 ms | 6.97 s |
| 5-9 | 5 | 26.7 ms | 32.0 ms | 24.3 ms | 29.3 ms | 17.3 ms | 11.4 ms | 0.00 ms | 0.00 ms |
| 10-24 | 7 | 5.12 s | 18.02 s | 5.11 s | 18.01 s | 97.1 ms | 100.1 ms | 1.25 s | 34.96 s |
| 25-49 | 2 | 56.06 s | 72.37 s | 56.05 s | 72.36 s | 3.1 ms | 11.5 ms | 7.40 s | 143.17 s |
| 100+ | 1 | 61.95 s | 61.95 s | 61.94 s | 61.94 s | 33.9 ms | 12.2 ms | 10.98 s | 122.78 s |

| Kind | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| invoice | 14 | 6.0 ms | 32.0 ms | 5.6 ms | 29.3 ms | 17.3 ms | 11.4 ms | 0.00 ms | 0.00 ms |
| letter | 23 | 10.6 ms | 56.06 s | 10.3 ms | 56.05 s | 33.9 ms | 3.0 ms | 4.42 s | 110.36 s |
| notice | 13 | 4.7 ms | 5.75 s | 4.4 ms | 5.75 s | 97.1 ms | 100.1 ms | 727.8 ms | 10.67 s |
| statement | 2 | 0.65 ms | 72.37 s | 0.35 ms | 72.36 s | 1.4 ms | 11.5 ms | 7.40 s | 143.17 s |

Over the documents that completed. Wall is the runner's clock around the request; worker is the worker's own total. OCR is summed over the pages, so when the worker reads pages in parallel it can exceed the total. A document's route class is the most expensive route any of its pages took (ocr > ocr_regions > layout > fast), or `unrouted` when the worker sent no layouts.

## Memory

| Process | Typical peak (p50) | Highest peak | During |
| --- | ---: | ---: | ---: |
| Parser worker | 238 MB | 1307 MB | real4-letter-13 |
| Model server | 6085 MB | 6124 MB | real4-letter-05 |
| Benchmark (engine) | 22 MB | 27 MB | real4-office-13 |

Resident memory sampled every 25 ms per document; a spike shorter than that can be missed.

## Misses (22)

- **real4-letter-03**: expected `2024-07-05 Official Information Act Response from The Treasury.pdf`, got `2024-07-05 Letter to Laura Berntsen.pdf` · trap: party Laura Berntsen (acting manager who signs) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED
- **real4-letter-04**: expected `2024-09-03 Official Information Act Response from The Treasury.pdf`, got `2024-09-03 Letter from Jess Hewat.pdf` · trap: party Jess Hewat (manager who signs) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, LOW_CONFIDENCE
- **real4-letter-07**: expected `2015-04-27 Freedom of Information Act Request Acknowledgement to Public.Resource.Org.pdf`, got `Freedom of Information Act Request Acknowledgement.pdf` · review: DATE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real4-letter-09**: expected `2015-09-08 Freedom of Information Act Response to Public.Resource.Org.pdf`, got `Letter to Carl Malamud.pdf` · trap: party Carl Malamud (addressee and signer of the attached request) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, DATE_UNSUPPORTED
- **real4-letter-10**: expected `2015-06-11 Freedom of Information Act Response to Public.Resource.Org.pdf`, got `2015-06-11 Letter to Carl Malamud.pdf` · trap: party Carl Malamud (addressee) · review: TYPE_MISSING, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real4-letter-11**: expected `2021-05-14 Letter to Public.Resource.Org.pdf`, got `2021-05-14 Letter from Kansas Judicial Council.pdf` · trap: party Kansas Judicial Council (body the letter will be referred to) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING
- **real4-letter-14**: expected `2015-07-15 Freedom of Information Act Response to Public.Resource.Org.pdf`, got `2015-07-05 Letter to Carl Malamud.pdf` · trap: party Carl Malamud (addressee) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED
- **real4-letter-15**: expected `2021-08-27 Letter to Public.Resource.Org.pdf`, got `2021-08-27 Letter to Carl Malamud.pdf` · trap: party Carl Malamud (addressee) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, LOW_CONFIDENCE
- **real4-notice-02**: expected `2026-02-17 Notice of Appeal between City of Philadelphia and United States Department of the Interior.pdf`, got `2026-02-17 Notice of Appeal for City of Philadelphia.pdf` · review: LOW_CONFIDENCE
- **real4-notice-03**: expected `2026-03-02 Notice of Appeal between Joe Neguse and U.S. Immigration and Customs Enforcement.pdf`, got `2026-03-02 Notice of Appeal for JOE NEGUSE.pdf` · review: PARTY_UNSUPPORTED
- **real4-notice-08**: expected `2025-04-28 Town and Country Planning Notice from Department for Transport.pdf`, got `2025-04-28 Notice details Town and Country Planning for Department For Transport.pdf` · review: PARTY_UNSUPPORTED
- **real4-notice-12**: expected `2025-09-04 Notice of Civil Penalty Assessment and Order to Crown Enterprises, LLC.pdf`, got `2025-09-04 Notice of Civil Penalty Assessment and Order for Crown Enterprises LLC.pdf` · review: PARTY_UNSUPPORTED
- **real4-notice-13**: expected `2025-06-17 Notice of Civil Penalty Assessment and Order to City of Stanfield.pdf`, got `2025-06-17 Notice of Civil Penalty Assessment and Order Case to City of Stanfield.pdf` · review: PARTY_UNSUPPORTED
- **real4-notice-14**: expected `2025-10-28 Notice of Civil Penalty Assessment and Order to Erickson Incorporated.pdf`, got `2025-10-28 Notice of Civil Penalty Assessment and Order Case from Department of Environmental Quality.pdf` · **filed without review**
- **real4-notice-15**: expected `2025-07-22 Notice of Civil Penalty Assessment and Order to Columbia Plywood Corporation.pdf`, got `2025-07-22 Notice of Civil Penalty Assessment and Order Case to OTLO Columbia Plywood Corporation.pdf` · review: PARTY_UNSUPPORTED
- **real4-invoice-01**: expected `2023-10-05 Invoice from National Credit Union Administration.pdf`, got `2023-10-05 Requester Invoice.pdf` · review: DATE_AMBIGUOUS, PARTY_UNSUPPORTED, PARTY_MISSING
- **real4-invoice-10**: expected `2024-01-28 Invoice from WTTG.pdf`, got `2024-01-08 Invoice from WTTG.pdf` · **filed without review**
- **real4-invoice-11**: expected `2024-06-30 Invoice from WCCO-TV.pdf`, got `2024-06-30 Invoice from WCCO-TV Advertiser.pdf` · review: LOW_CONFIDENCE
- **real4-invoice-12**: expected `2024-11-10 Invoice from WCCO-TV.pdf`, got `2024-11-10 Invoice from WCCO-TV Advertiser.pdf` · **filed without review**
- **real4-invoice-14**: expected `2024-05-26 Invoice from WTTG.pdf`, got `2024-05-06 Invoice from WTTG.pdf` · trap: date 2024-05-06 (first air date) · review: DATE_AMBIGUOUS
- **real4-office-02**: expected `2016-05-12 Letter to Post & Schell.docx`, got `2016-05-12 Letter of Notification of PPL Electric Utilities for PPL Electric Utilities Corporation.docx` · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real4-office-10**: expected `2016-04-06 Email to Department of General Services.msg`, got `2016-04-06 Email from Bruce Betts.msg` · trap: party Bruce Betts (sender) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, LOW_CONFIDENCE

## How to compare

Keep this run's JSON, make the change, run again, then:

```text
intern-bench compare --before before.json --after after.json --markdown diff.md
```

It recomputes every rate and count over the documents both runs scored, lists each document whose score flipped, and gives the change in p50/p95 of every stage over the documents both completed - between two live runs only, since a replay's timings are its recording's. `intern-bench report --input report.json --markdown report.md` re-renders this page from the JSON.
