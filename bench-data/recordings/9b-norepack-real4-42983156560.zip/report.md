# InternBench: live run

- **Run:** 2026-11-11T07:59:45Z · commit `0c8d3295d9`
- **Machine:** AMD EPYC 9V74 80-Core Processor, 4 logical cores, 15.6 GB RAM, linux (Ubuntu 24.04.5 LTS)
- **Model:** `intern-local` · 5.68 GB · sha256 `03b74727a860`
- **Corpus:** 53 documents · 53 completed · gold `44664cc2c2`
- **Wall time:** 2581.52 s for the whole run, the worker's start included

## Scorecard

| Score | Result |
| --- | ---: |
| Filename (the whole name) | 24/50 (48.0%) |
| Document type | 46/53 (86.8%) |
| Date | 43/50 (86.0%) |
| Date role (when the reviewed date was chosen) | 19/42 (45.2%) |
| Parties | 41/53 (77.4%) |
| Relation word (when parties were named) | 41/51 (80.4%) |
| Party in the right role (when parties were named) | 11/23 (47.8%) |
| Ready / review routing | 12/34 (35.3%) |
| Description states nothing false | 53/53 (100.0%) |
| Description is specific | 41/53 (77.4%) |
| Description specificity | 72.3% (mean of 53) |
| Evidence recall (model's quotes) | 61.6% (mean of 53) |
| Digest recall (facts reaching the digest) | 89.6% (mean of 53) |
| Prompt recall (facts reaching the prompt sent) | 89.0% (mean of 53) |
| Sent to review | 83.0% of 53 completed |

## Phase 3 scorecard

| Figure | Value | Docs |
| --- | ---: | ---: |
| Long-document filename accuracy (10+ pages) | 40.0% | 10 |
| Complex-document filename accuracy | – | 0 |
| Description completeness | – | 0 |
| Unsupported-fact rate (documents) | 69.8% | 53 |
| Review rate | 83.0% | 53 |
| Evidence recall | 61.6% | 53 |
| Total latency p50 | 39.42 s | 53 |
| Total latency p95 | 131.36 s | 53 |
| Generation latency p50 | 16.51 s | 53 |
| Generation latency p95 | 21.82 s | 53 |
| Generated tokens p50 | 88 | 53 |
| Generated tokens p95 | 110 | 53 |
| Prompt tokens p50 | 852 | 53 |

Long: 10 pages or more. Complex: any of `referenced_agreement`, `middle_fact`, `multi_column`, `layout_parties`, `irrelevant_names`, `information_dense`, `stream_order`, `date_in_table`, `key_value`, `complex_pdf`. Unsupported-fact rate: documents with any `*_UNSUPPORTED` review reason. Latency and tokens over the documents that completed.

## Safety

| Check | Count |
| --- | ---: |
| Filed without review under a wrong name | 3 of 50 |
| Trap date chosen | 3 of 53 |
| Forbidden party named | 8 of 53 |
| Spurious parties named | 8 |
| Description states a known-wrong fact | 0 |
| Unsupported description claims | 0 of 138 (0.0%) |
| Right name sent to review anyway | 10 of 29 |
| Sent to review for an unsupported fact | 37 of 53 |

## By kind

| Kind | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| invoice | 14 | 8/13 | 11/13 | 13/14 | 7/13 | 57.1% | 39.42 s | 55.32 s |
| letter | 23 | 10/22 | 18/22 | 15/23 | 2/10 | 100.0% | 38.70 s | 143.76 s |
| notice | 14 | 4/13 | 12/13 | 11/14 | 2/10 | 85.7% | 37.68 s | 76.31 s |
| statement | 2 | 2/2 | 2/2 | 2/2 | 1/1 | 50.0% | 30.76 s | 131.36 s |

## By text layer

| Text layer | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| native | 30 | 12/29 | 27/29 | 23/30 | 8/22 | 73.3% | 38.44 s | 143.76 s |
| office | 11 | 7/9 | 9/9 | 9/11 | 2/3 | 100.0% | 34.10 s | 52.41 s |
| scan | 10 | 4/10 | 5/10 | 7/10 | 2/9 | 100.0% | 67.47 s | 131.36 s |
| text | 2 | 1/2 | 2/2 | 2/2 | – | 50.0% | 30.76 s | 49.32 s |

## By page count

| Pages | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 22 | 9/20 | 19/20 | 15/22 | 5/10 | 77.3% | 31.41 s | 54.29 s |
| 2-4 | 16 | 9/15 | 13/15 | 12/16 | 4/11 | 87.5% | 43.08 s | 58.69 s |
| 5-9 | 5 | 2/5 | 3/5 | 5/5 | 2/5 | 60.0% | 39.42 s | 44.25 s |
| 10-24 | 7 | 2/7 | 5/7 | 6/7 | 0/6 | 100.0% | 69.58 s | 76.31 s |
| 25-49 | 2 | 2/2 | 2/2 | 2/2 | 1/2 | 100.0% | 131.36 s | 143.76 s |
| 100+ | 1 | 0/1 | 1/1 | 1/1 | – | 100.0% | 154.28 s | 154.28 s |

## By slice

| Slice | Docs | Filename | Date | Parties | Routing | Unsafe ready | p50 total | p95 total | p50 generation | p95 generation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| long | 10 | 4/10 | 8/10 | 9/10 | 1/8 | 0 of 10 | 70.99 s | 154.28 s | 18.26 s | 21.82 s |

`long`: 10 pages or more. `complex`: any of the categories listed under the phase 3 scorecard. A document may be in both.

## By challenge

| Category | Docs | Filename | Date | Parties | Traps sprung |
| --- | ---: | ---: | ---: | ---: | ---: |
| acknowledgement | 3 | 2/3 | 3/3 | 3/3 | 0 |
| addressee_redacted | 6 | 2/6 | 6/6 | 4/6 | 2 |
| agency_billing | 8 | 4/8 | 6/8 | 8/8 | 1 |
| attachment_title_trap | 1 | 0/1 | 1/1 | 0/1 | 1 |
| attachments | 11 | 3/11 | 9/11 | 9/11 | 2 |
| body_recounts_events | 1 | – | – | 1/1 | 1 |
| born_digital | 30 | 12/29 | 27/29 | 23/30 | 6 |
| brand_vs_legal_name | 3 | 3/3 | 3/3 | 3/3 | 0 |
| broadcast_invoice | 8 | 4/8 | 6/8 | 8/8 | 1 |
| broken_text_layer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| caption | 4 | 2/4 | 4/4 | 2/4 | 0 |
| card_statement | 1 | 1/1 | 1/1 | 1/1 | 0 |
| certificate_of_service | 2 | 1/2 | 2/2 | 1/2 | 0 |
| certified_mail | 4 | 2/4 | 3/4 | 4/4 | 0 |
| citation | 2 | 0/2 | 2/2 | 2/2 | 0 |
| competing_dates | 40 | 21/40 | 34/40 | 33/40 | 6 |
| contract_numbers | 1 | 0/1 | 1/1 | 0/1 | 1 |
| court_filing | 4 | 2/4 | 4/4 | 2/4 | 0 |
| cover_letter | 4 | 2/4 | 3/4 | 4/4 | 0 |
| customer_first | 1 | 0/1 | 1/1 | 0/1 | 0 |
| customer_redacted | 1 | 1/1 | 1/1 | 1/1 | 0 |
| date_at_end | 1 | 1/1 | 1/1 | 1/1 | 0 |
| date_stamp | 3 | 1/3 | 1/3 | 1/3 | 1 |
| deadline_in_body | 9 | 2/9 | 8/9 | 9/9 | 0 |
| doc | 3 | 2/2 | 2/2 | 3/3 | 1 |
| docket_number | 3 | 2/3 | 3/3 | 3/3 | 0 |
| docx | 4 | 3/4 | 4/4 | 4/4 | 0 |
| doubled_ocr_text | 4 | 2/4 | 3/4 | 4/4 | 0 |
| due_date | 4 | 4/4 | 4/4 | 4/4 | 0 |
| duplicate_marking | 1 | 1/1 | 1/1 | 1/1 | 0 |
| email | 2 | 1/2 | 2/2 | 1/2 | 1 |
| embedded_second_letter | 1 | 0/1 | 0/1 | 0/1 | 1 |
| enclosure_list | 1 | – | – | 1/1 | 1 |
| esignature | 1 | 1/1 | 1/1 | 1/1 | 0 |
| fee_invoice | 2 | 0/1 | 1/1 | 1/2 | 1 |
| file_name_date_trap | 1 | 1/1 | 1/1 | 1/1 | 0 |
| filed_stamp | 4 | 2/4 | 4/4 | 2/4 | 0 |
| foi_release | 1 | 1/1 | 1/1 | 1/1 | 0 |
| foi_response | 15 | 6/14 | 10/14 | 10/15 | 5 |
| forecaster_initials | 1 | 1/1 | 1/1 | 1/1 | 0 |
| form | 2 | 0/2 | 2/2 | 2/2 | 0 |
| group_recipient | 1 | 1/1 | 1/1 | 1/1 | 0 |
| illegible_date | 1 | 0/1 | 0/1 | 0/1 | 1 |
| image_only | 2 | 1/2 | 1/2 | 1/2 | 1 |
| internal_email | 2 | 1/2 | 2/2 | 1/2 | 1 |
| invoice | 14 | 8/13 | 11/13 | 13/14 | 2 |
| issuer_in_logo | 1 | 0/1 | 1/1 | 0/1 | 0 |
| journal_number | 1 | – | – | 0/1 | 1 |
| journalist_addressee | 1 | 1/1 | 1/1 | 1/1 | 0 |
| letter | 23 | 10/22 | 18/22 | 15/23 | 8 |
| letterhead_names | 1 | 0/1 | 1/1 | 0/1 | 1 |
| line_item_dates | 9 | 5/9 | 7/9 | 9/9 | 1 |
| long_document | 2 | 1/2 | 2/2 | 2/2 | 0 |
| many_dates | 1 | – | – | 1/1 | 1 |
| metadata_date_trap | 3 | 2/2 | 2/2 | 3/3 | 1 |
| military_date_format | 1 | 0/1 | 0/1 | 0/1 | 1 |
| modern | 53 | 24/50 | 43/50 | 41/53 | 11 |
| msg | 2 | 1/2 | 2/2 | 1/2 | 1 |
| multiple_addressees | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multiple_documents_in_file | 1 | 1/1 | 1/1 | 1/1 | 0 |
| named_person_at_org | 15 | 7/15 | 12/15 | 9/15 | 4 |
| new_zealand | 4 | 0/4 | 4/4 | 2/4 | 2 |
| no_addressee | 2 | 1/1 | 1/1 | 2/2 | 1 |
| no_issuer_name_in_header | 1 | – | – | 0/1 | 1 |
| no_letterhead_text | 2 | 0/2 | 2/2 | 1/2 | 1 |
| no_signer_name | 1 | 1/1 | 1/1 | 1/1 | 0 |
| nonprofit | 1 | 1/1 | 1/1 | 1/1 | 0 |
| notice | 14 | 4/13 | 12/13 | 11/14 | 1 |
| notice_of_appeal | 4 | 2/4 | 4/4 | 2/4 | 0 |
| numeric_date_dmy | 1 | 1/1 | 1/1 | 1/1 | 0 |
| ocr_text_layer | 8 | 3/8 | 4/8 | 6/8 | 1 |
| odt | 1 | 1/1 | 1/1 | 1/1 | 0 |
| office | 11 | 7/9 | 9/9 | 9/11 | 3 |
| on_behalf_of_client | 2 | 1/2 | 2/2 | 2/2 | 0 |
| ordinal_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| pay_gov | 1 | 0/1 | 1/1 | 0/1 | 0 |
| payment_page | 2 | 2/2 | 2/2 | 2/2 | 0 |
| penalty_notice | 6 | 2/6 | 5/6 | 6/6 | 0 |
| person_in_official_capacity | 3 | 1/3 | 3/3 | 1/3 | 0 |
| plaintiff_appeals | 1 | 1/1 | 1/1 | 1/1 | 0 |
| planning_notice | 2 | 0/2 | 2/2 | 2/2 | 0 |
| political_file | 8 | 4/8 | 6/8 | 8/8 | 1 |
| preliminary_data | 1 | 0/1 | 1/1 | 1/1 | 0 |
| proration_note | 1 | 1/1 | 1/1 | 1/1 | 0 |
| public_notice | 2 | 0/2 | 2/2 | 2/2 | 0 |
| re_line | 3 | 1/3 | 2/3 | 1/3 | 1 |
| re_line_references_document | 1 | 1/1 | 1/1 | 1/1 | 0 |
| redacted | 1 | 1/1 | 1/1 | 1/1 | 0 |
| redacted_signer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| reference_number | 11 | 2/10 | 8/10 | 8/11 | 4 |
| referral | 1 | 1/1 | 1/1 | 1/1 | 0 |
| remit_to_bank | 3 | 3/3 | 3/3 | 3/3 | 0 |
| rtf | 1 | – | – | 0/1 | 1 |
| same_day_order | 1 | 0/1 | 1/1 | 0/1 | 0 |
| scanned | 10 | 4/10 | 5/10 | 7/10 | 2 |
| service_period | 11 | 7/11 | 9/11 | 11/11 | 1 |
| short | 5 | 2/4 | 4/4 | 3/5 | 2 |
| sidebar_metadata | 2 | 0/2 | 2/2 | 2/2 | 0 |
| signature_block_org | 1 | 1/1 | 1/1 | 1/1 | 0 |
| signature_in_caps | 1 | 1/1 | 1/1 | 1/1 | 0 |
| signature_on_later_page | 6 | 2/6 | 4/6 | 4/6 | 2 |
| statement | 2 | 2/2 | 2/2 | 2/2 | 0 |
| system_generated | 1 | – | – | 1/1 | 1 |
| tabular_body | 1 | 0/1 | 1/1 | 1/1 | 0 |
| text | 2 | 1/2 | 2/2 | 2/2 | 0 |
| title_line | 2 | 0/2 | 2/2 | 2/2 | 0 |
| two_digit_year | 8 | 4/8 | 6/8 | 8/8 | 1 |
| txt | 2 | 1/2 | 2/2 | 2/2 | 0 |
| uk | 9 | 5/7 | 7/7 | 8/9 | 2 |
| undated | 3 | – | – | 2/3 | 3 |
| us | 8 | 4/8 | 6/8 | 8/8 | 1 |
| us_city | 3 | 3/3 | 3/3 | 3/3 | 0 |
| us_federal | 12 | 3/11 | 7/11 | 8/12 | 3 |
| us_federal_court | 4 | 2/4 | 4/4 | 2/4 | 0 |
| us_state | 12 | 6/12 | 11/12 | 9/12 | 3 |
| utc_vs_local | 2 | 1/2 | 2/2 | 2/2 | 0 |
| vendor_invoice | 4 | 4/4 | 4/4 | 4/4 | 0 |
| weather_product | 2 | 1/2 | 2/2 | 2/2 | 0 |
| wmo_header | 2 | 1/2 | 2/2 | 2/2 | 0 |
| zero_amount | 1 | – | – | 1/1 | 1 |
| zone_list | 1 | 1/1 | 1/1 | 1/1 | 0 |

## Routes

- **Pages:** fast 113 · layout 116 · ocr 142 · ocr_regions 4
- **Documents by route class:** fast 18 · layout 25 · ocr 6 · ocr_regions 4

## Where the time goes

| Stage | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `total_ms` | 53 | 39.42 s | 131.36 s | 154.28 s |
| `extraction_wall_ms` | 53 | 8.1 ms | 67.26 s | 78.63 s |
| `worker_total_ms` | 53 | 7.6 ms | 67.26 s | 78.62 s |
| `worker_snapshot_ms` | 53 | 0.23 ms | 0.66 ms | 3.4 ms |
| `worker_parse_ms` | 53 | 3.4 ms | 69.0 ms | 97.8 ms |
| `worker_analysis_ms` | 53 | 0.44 ms | 21.4 ms | 30.5 ms |
| `worker_render_ms` | 53 | 0.00 ms | 3.64 s | 10.81 s |
| `worker_image_decode_ms` | 53 | 0.00 ms | 0.00 ms | 0.00 ms |
| `worker_ocr_ms` | 53 | 0.00 ms | 67.11 s | 78.40 s |
| `worker_ocr_encode_ms` | 53 | 0.00 ms | 4.10 s | 6.34 s |
| `worker_ocr_engine_ms` | 53 | 0.00 ms | 60.70 s | 74.17 s |
| `worker_vision_ms` | 53 | 0.00 ms | 0.00 ms | 20.3 ms |
| `analyze_wall_ms` | 53 | 39.41 s | 75.48 s | 81.38 s |
| `distill_ms` | 53 | 2.5 ms | 79.3 ms | 208.5 ms |
| `prompt_ms` | 53 | 0.03 ms | 0.07 ms | 0.07 ms |
| `inference_ms` | 53 | 39.34 s | 74.99 s | 80.77 s |
| `prefill_ms` | 53 | 23.98 s | 54.65 s | 58.94 s |
| `generation_ms` | 53 | 16.51 s | 21.82 s | 22.43 s |
| `validation_ms` | 53 | 26.9 ms | 397.1 ms | 498.7 ms |
| `naming_ms` | 53 | 0.38 ms | 6.9 ms | 13.7 ms |
| `index_ms` | 53 | 2.5 ms | 77.4 ms | 207.1 ms |
| `retrieval_ms` | 53 | 0.03 ms | 3.5 ms | 4.5 ms |

| Measure | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `prefill_tok_per_s` | 53 | 35.5 tok/s | 36.2 tok/s | 36.2 tok/s |
| `generation_tok_per_s` | 53 | 5.3 tok/s | 5.5 tok/s | 5.5 tok/s |
| `prompt_tokens` | 53 | 852 | 1964 | 2116 |
| `cached_tokens` | 53 | 477 | 477 | 546 |
| `generated_tokens` | 53 | 88 | 110 | 118 |
| `estimated_prompt_tokens` | 53 | 1433 | 2359 | 2468 |
| `model_requests` | 53 | 1 | 1 | 1 |
| `redistillations` | 53 | 0 | 0 | 0 |
| `source_characters` | 53 | 2717 | 85592 | 87914 |
| `digest_characters` | 53 | 2064 | 4643 | 4770 |
| `prompt_characters` | 53 | 4113 | 6698 | 6826 |
| `worker_ocr_pages` | 53 | 0 | 29 | 66 |
| `worker_ocr_passes` | 53 | 0 | 29 | 69 |
| `worker_orientation_passes` | 53 | 0 | 29 | 66 |
| `worker_rendered_pixels` | 53 | 0 | 252367280 | 574406515 |
| `index_units` | 53 | 31 | 2002 | 2486 |
| `context_units` | 53 | 27 | 83 | 89 |
| `context_tokens` | 53 | 845 | 1769 | 1877 |

## Extraction time

| Route class | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fast | 18 | 2.5 ms | 69.2 ms | 2.2 ms | 67.7 ms | 67.0 ms | 0.34 ms | 0.00 ms | 0.00 ms |
| layout | 25 | 8.1 ms | 102.6 ms | 7.7 ms | 95.7 ms | 69.0 ms | 21.4 ms | 0.00 ms | 0.00 ms |
| ocr_regions | 4 | 926.6 ms | 1.35 s | 926.2 ms | 1.34 s | 95.7 ms | 28.7 ms | 176.4 ms | 1.18 s |
| ocr | 6 | 19.51 s | 78.63 s | 19.51 s | 78.62 s | 27.0 ms | 11.6 ms | 10.81 s | 78.40 s |

| Pages | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 22 | 3.3 ms | 69.2 ms | 3.0 ms | 67.7 ms | 13.8 ms | 1.0 ms | 0.00 ms | 0.00 ms |
| 2-4 | 16 | 6.0 ms | 5.05 s | 5.6 ms | 5.05 s | 27.6 ms | 3.8 ms | 381.4 ms | 4.82 s |
| 5-9 | 5 | 27.5 ms | 36.1 ms | 24.6 ms | 33.2 ms | 20.5 ms | 12.0 ms | 0.00 ms | 0.00 ms |
| 10-24 | 7 | 102.6 ms | 19.51 s | 95.7 ms | 19.51 s | 97.8 ms | 30.5 ms | 988.5 ms | 19.37 s |
| 25-49 | 2 | 67.26 s | 78.63 s | 67.26 s | 78.62 s | 3.2 ms | 11.4 ms | 5.52 s | 78.40 s |
| 100+ | 1 | 72.90 s | 72.90 s | 72.89 s | 72.89 s | 27.0 ms | 11.6 ms | 10.81 s | 72.60 s |

| Kind | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| invoice | 14 | 6.2 ms | 36.1 ms | 5.7 ms | 33.2 ms | 20.5 ms | 12.0 ms | 0.00 ms | 0.00 ms |
| letter | 23 | 10.9 ms | 67.26 s | 10.6 ms | 67.26 s | 27.6 ms | 3.0 ms | 3.64 s | 67.11 s |
| notice | 14 | 4.2 ms | 836.8 ms | 3.9 ms | 827.8 ms | 97.8 ms | 30.5 ms | 176.4 ms | 503.7 ms |
| statement | 2 | 1.3 ms | 78.63 s | 0.30 ms | 78.62 s | 1.2 ms | 11.4 ms | 5.52 s | 78.40 s |

Over the documents that completed. Wall is the runner's clock around the request; worker is the worker's own total. OCR is summed over the pages, so when the worker reads pages in parallel it can exceed the total. A document's route class is the most expensive route any of its pages took (ocr > ocr_regions > layout > fast), or `unrouted` when the worker sent no layouts.

## Memory

| Process | Typical peak (p50) | Highest peak | During |
| --- | ---: | ---: | ---: |
| Parser worker | 134 MB | 743 MB | real4-letter-13 |
| Model server | 6135 MB | 6174 MB | real4-letter-05 |
| Benchmark (engine) | 24 MB | 28 MB | real4-office-13 |

Resident memory sampled every 25 ms per document; a spike shorter than that can be missed.

## Misses (26)

- **real4-letter-03**: expected `2024-07-05 Official Information Act Response from The Treasury.pdf`, got `2024-07-05 Letter to Laura Berntsen.pdf` · trap: party Laura Berntsen (acting manager who signs) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED
- **real4-letter-04**: expected `2024-09-03 Official Information Act Response from The Treasury.pdf`, got `2024-09-03 Letter from Jess Hewat.pdf` · trap: party Jess Hewat (manager who signs) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, LOW_CONFIDENCE
- **real4-letter-05**: expected `2024-08-23 Response to an Official Information Act Request from Ministry for Pacific Peoples.pdf`, got `2024-08-23 Document from Ministry for Pacific Peoples.pdf` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real4-letter-06**: expected `2024-10-04 Response to an Official Information Act Request from Ministry for Pacific Peoples.pdf`, got `2024-10-04 Tax Invoice from Ministry for Pacific Peoples.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, PARSER_WARNING
- **real4-letter-07**: expected `2015-04-27 Freedom of Information Act Request Acknowledgement to Public.Resource.Org.pdf`, got `Freedom of Information Act Request Acknowledgement.pdf` · review: DATE_UNSUPPORTED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real4-letter-09**: expected `2015-09-08 Freedom of Information Act Response to Public.Resource.Org.pdf`, got `Letter to Carl Malamud.pdf` · trap: party Carl Malamud (addressee and signer of the attached request) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, DATE_UNSUPPORTED
- **real4-letter-10**: expected `2015-06-11 Freedom of Information Act Response to Public.Resource.Org.pdf`, got `Letter from Federal Highway Administration.pdf` · review: TYPE_MISSING, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, DESCRIPTION_INVALID, LOW_CONFIDENCE
- **real4-letter-11**: expected `2021-05-14 Letter to Public.Resource.Org.pdf`, got `2021-05-14 Letter from Kansas Judicial Council.pdf` · trap: party Kansas Judicial Council (body the letter will be referred to) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING
- **real4-letter-14**: expected `2015-07-15 Freedom of Information Act Response to Public.Resource.Org.pdf`, got `2015-07-05 Letter to Carl Malamud.pdf` · trap: party Carl Malamud (addressee) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED
- **real4-letter-15**: expected `2021-08-27 Letter to Public.Resource.Org.pdf`, got `2021-08-27 Letter to Carl Malamud.pdf` · trap: party Carl Malamud (addressee) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, LOW_CONFIDENCE
- **real4-notice-02**: expected `2026-02-17 Notice of Appeal between City of Philadelphia and United States Department of the Interior.pdf`, got `2026-02-17 Notice of Appeal for City of Philadelphia.pdf` · review: LOW_CONFIDENCE
- **real4-notice-03**: expected `2026-03-02 Notice of Appeal between Joe Neguse and U.S. Immigration and Customs Enforcement.pdf`, got `2026-03-02 Notice of Appeal for JOE NEGUSE.pdf` · review: PARTY_UNSUPPORTED
- **real4-notice-08**: expected `2025-04-28 Town and Country Planning Notice from Department for Transport.pdf`, got `2025-04-28 Notice details Town and Country Planning for Department For Transport.pdf` · **filed without review**
- **real4-notice-09**: expected `2025-01-14 Town and Country Planning Notice from Department for Transport.pdf`, got `2025-01-14 Official Public Record from Department for Transport.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED
- **real4-notice-10**: expected `2024-06-06 Citation and Notification of Penalty to Maestro Construction, Inc.pdf`, got `2024-06-06 Document from U.S. Department of Labor.pdf` · review: TYPE_UNSUPPORTED
- **real4-notice-11**: expected `2024-02-20 Citation and Notification of Penalty to Henry Brick Company, Inc.pdf`, got `2024-02-20 Notice to Employees of Informal Conference from U.S. Department of Labor.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED
- **real4-notice-12**: expected `2025-09-04 Notice of Civil Penalty Assessment and Order to Crown Enterprises, LLC.pdf`, got `2025-08-26 Notice of Civil Penalty Assessment to Central Transport LLC.pdf` · review: PARTY_UNSUPPORTED
- **real4-notice-13**: expected `2025-06-17 Notice of Civil Penalty Assessment and Order to City of Stanfield.pdf`, got `Notice of Civil Penalty Assessment and Order Case for Oregon Department of Environmental Quality.pdf` · review: DATE_UNSUPPORTED, LOW_CONFIDENCE
- **real4-invoice-01**: expected `2023-10-05 Invoice from National Credit Union Administration.pdf`, got `2023-10-05 Requester Invoice.pdf` · review: DATE_AMBIGUOUS, PARTY_UNSUPPORTED, PARTY_MISSING
- **real4-invoice-10**: expected `2024-01-28 Invoice from WTTG.pdf`, got `2024-01-08 Invoice from WTTG.pdf` · **filed without review**
- **real4-invoice-11**: expected `2024-06-30 Invoice from WCCO-TV.pdf`, got `2024-06-30 Invoice from WCCO-TV Advertiser.pdf` · review: LOW_CONFIDENCE
- **real4-invoice-12**: expected `2024-11-10 Invoice from WCCO-TV.pdf`, got `2024-11-10 Invoice from WCCO-TV Advertiser.pdf` · **filed without review**
- **real4-invoice-14**: expected `2024-05-26 Invoice from WTTG.pdf`, got `2024-05-06 Invoice from WTTG.pdf` · trap: date 2024-05-06 (first air date) · review: DATE_AMBIGUOUS
- **real4-office-02**: expected `2016-05-12 Letter to Post & Schell.docx`, got `2016-05-12 Letter of Notification of PPL Electric Utilities for PPL Electric Utilities Corporation.docx` · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real4-office-10**: expected `2016-04-06 Email to Department of General Services.msg`, got `2016-04-06 Email from Bruce Betts.msg` · trap: party Bruce Betts (sender) · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real4-office-12**: expected `2026-10-19 Public Information Statement from National Weather Service Wichita KS.txt`, got `2026-10-19 Document from National Weather Service Wichita KS.txt` · review: TYPE_UNSUPPORTED, PARTY_UNSUPPORTED

## How to compare

Keep this run's JSON, make the change, run again, then:

```text
intern-bench compare --before before.json --after after.json --markdown diff.md
```

It recomputes every rate and count over the documents both runs scored, lists each document whose score flipped, and gives the change in p50/p95 of every stage over the documents both completed - between two live runs only, since a replay's timings are its recording's. `intern-bench report --input report.json --markdown report.md` re-renders this page from the JSON.
