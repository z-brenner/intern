# InternBench: live run

- **Run:** 2026-11-12T20:40:53Z · commit `343ee39b8e`
- **Machine:** AMD EPYC 9V45 96-Core Processor, 4 logical cores, 15.6 GB RAM, linux (Ubuntu 24.04.5 LTS)
- **Model:** `intern-local` · 5.68 GB · sha256 `03b74727a860`
- **Corpus:** 54 documents · 54 completed · gold `1f31432f7c`
- **Wall time:** 1594.09 s for the whole run, the worker's start included

## Scorecard

| Score | Result |
| --- | ---: |
| Filename (the whole name) | 19/51 (37.2%) |
| Document type | 46/54 (85.2%) |
| Date | 47/51 (92.2%) |
| Date role (when the reviewed date was chosen) | 24/47 (51.1%) |
| Parties | 33/54 (61.1%) |
| Relation word (when parties were named) | 32/54 (59.3%) |
| Party in the right role (when parties were named) | 24/39 (61.5%) |
| Ready / review routing | 15/37 (40.5%) |
| Description states nothing false | 54/54 (100.0%) |
| Description is specific | 44/54 (81.5%) |
| Description specificity | 73.5% (mean of 54) |
| Evidence recall (model's quotes) | 72.2% (mean of 54) |
| Digest recall (facts reaching the digest) | 83.6% (mean of 54) |
| Prompt recall (facts reaching the prompt sent) | 83.3% (mean of 54) |
| Sent to review | 74.1% of 54 completed |

## Phase 3 scorecard

| Figure | Value | Docs |
| --- | ---: | ---: |
| Long-document filename accuracy (10+ pages) | 50.0% | 2 |
| Complex-document filename accuracy | 0.0% | 2 |
| Description completeness | – | 0 |
| Unsupported-fact rate (documents) | 59.3% | 54 |
| Review rate | 74.1% | 54 |
| Evidence recall | 72.2% | 54 |
| Total latency p50 | 28.21 s | 54 |
| Total latency p95 | 39.17 s | 54 |
| Generation latency p50 | 14.93 s | 54 |
| Generation latency p95 | 18.60 s | 54 |
| Generated tokens p50 | 89 | 54 |
| Generated tokens p95 | 110 | 54 |
| Prompt tokens p50 | 651 | 54 |

Long: 10 pages or more. Complex: any of `referenced_agreement`, `middle_fact`, `multi_column`, `layout_parties`, `irrelevant_names`, `information_dense`, `stream_order`, `date_in_table`, `key_value`, `complex_pdf`. Unsupported-fact rate: documents with any `*_UNSUPPORTED` review reason. Latency and tokens over the documents that completed.

## Safety

| Check | Count |
| --- | ---: |
| Filed without review under a wrong name | 6 of 51 |
| Trap date chosen | 4 of 54 |
| Forbidden party named | 9 of 54 |
| Spurious parties named | 20 |
| Description states a known-wrong fact | 0 |
| Unsupported description claims | 0 of 157 (0.0%) |
| Right name sent to review anyway | 7 of 34 |
| Sent to review for an unsupported fact | 32 of 54 |

## By kind

| Kind | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| contract | 2 | 1/2 | 2/2 | 1/2 | 1/2 | 50.0% | 31.75 s | 38.13 s |
| form | 6 | 2/5 | 5/5 | 3/6 | 1/2 | 83.3% | 36.49 s | 50.52 s |
| invoice | 6 | 2/6 | 4/6 | 4/6 | 3/4 | 50.0% | 22.22 s | 38.22 s |
| letter | 15 | 5/14 | 13/14 | 10/15 | 2/10 | 86.7% | 27.51 s | 34.59 s |
| memo | 6 | 1/6 | 6/6 | 1/6 | 1/3 | 83.3% | 33.12 s | 38.71 s |
| minutes | 5 | 2/5 | 5/5 | 4/5 | 3/4 | 40.0% | 29.22 s | 37.56 s |
| notice | 9 | 4/8 | 8/8 | 8/9 | 2/8 | 88.9% | 23.71 s | 28.92 s |
| purchase_order | 1 | 0/1 | 1/1 | 0/1 | 0/1 | 100.0% | 39.17 s | 39.17 s |
| receipt | 2 | 1/2 | 1/2 | 1/2 | 1/1 | 50.0% | 16.52 s | 18.72 s |
| statement | 2 | 1/2 | 2/2 | 1/2 | 1/2 | 50.0% | 26.37 s | 32.29 s |

## By text layer

| Text layer | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| image | 3 | 0/3 | 0/3 | 1/3 | – | 100.0% | 16.52 s | 22.22 s |
| native | 32 | 11/30 | 30/30 | 21/32 | 11/31 | 68.8% | 27.68 s | 38.22 s |
| office | 4 | 1/3 | 3/3 | 2/4 | 1/3 | 100.0% | 26.47 s | 50.52 s |
| scan | 15 | 7/15 | 14/15 | 9/15 | 3/3 | 73.3% | 31.40 s | 41.09 s |

## By page count

| Pages | Docs | Filename | Date | Parties | Routing | Review | p50 total | p95 total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 21 | 6/19 | 16/19 | 11/21 | 7/13 | 71.4% | 22.83 s | 33.32 s |
| 2-4 | 21 | 7/21 | 20/21 | 15/21 | 5/15 | 71.4% | 28.53 s | 37.70 s |
| 5-9 | 10 | 5/9 | 9/9 | 6/10 | 2/7 | 90.0% | 31.40 s | 50.52 s |
| 10-24 | 2 | 1/2 | 2/2 | 1/2 | 1/2 | 50.0% | 31.75 s | 38.13 s |

## By slice

| Slice | Docs | Filename | Date | Parties | Routing | Unsafe ready | p50 total | p95 total | p50 generation | p95 generation |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| long | 2 | 1/2 | 2/2 | 1/2 | 1/2 | 0 of 2 | 31.75 s | 38.13 s | 14.99 s | 17.12 s |
| complex | 2 | 0/2 | 2/2 | 0/2 | 0/2 | 0 of 2 | 38.13 s | 39.17 s | 16.52 s | 17.12 s |

`long`: 10 pages or more. `complex`: any of the categories listed under the phase 3 scorecard. A document may be in both.

## By challenge

| Category | Docs | Filename | Date | Parties | Traps sprung |
| --- | ---: | ---: | ---: | ---: | ---: |
| abbreviated_names | 1 | 0/1 | 0/1 | 0/1 | 0 |
| account_statement | 2 | 1/2 | 2/2 | 1/2 | 0 |
| acord_form | 1 | 1/1 | 1/1 | 1/1 | 0 |
| addressed_to_office_holder | 4 | 2/4 | 4/4 | 3/4 | 0 |
| addressed_to_person | 3 | 2/3 | 2/3 | 3/3 | 1 |
| addressee_list | 1 | 0/1 | 1/1 | 0/1 | 1 |
| administrator_vs_fund | 1 | 0/1 | 1/1 | 0/1 | 0 |
| affidavit | 1 | 1/1 | 1/1 | 1/1 | 0 |
| agencies_named_in_body | 1 | 0/1 | 1/1 | 0/1 | 1 |
| agency_guidance | 1 | 0/1 | 1/1 | 0/1 | 1 |
| agency_notice | 1 | 0/1 | 1/1 | 1/1 | 0 |
| annex | 2 | 1/2 | 2/2 | 1/2 | 0 |
| annexed_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| applicant_not_named_as_entity | 1 | 0/1 | 1/1 | 0/1 | 0 |
| applicant_subject | 1 | 1/1 | 1/1 | 1/1 | 0 |
| approval_date | 1 | 0/1 | 1/1 | 1/1 | 0 |
| archive_back_page | 1 | 1/1 | 1/1 | 1/1 | 0 |
| archive_banner | 1 | 0/1 | 1/1 | 0/1 | 1 |
| association | 1 | 0/1 | 1/1 | 1/1 | 0 |
| attached_order_form | 1 | 0/1 | 1/1 | 0/1 | 0 |
| attachment_label | 2 | 0/2 | 2/2 | 1/2 | 0 |
| attachment_with_own_date | 1 | 0/1 | 1/1 | 0/1 | 1 |
| attachments | 2 | 2/2 | 2/2 | 2/2 | 0 |
| attendance_list | 2 | 1/2 | 2/2 | 2/2 | 0 |
| attention_line | 1 | 1/1 | 1/1 | 1/1 | 0 |
| australia | 2 | 0/1 | 1/1 | 1/2 | 1 |
| backup_report | 1 | 0/1 | 1/1 | 1/1 | 0 |
| bank_in_remittance | 1 | 0/1 | 1/1 | 0/1 | 1 |
| bank_statement | 1 | 1/1 | 1/1 | 1/1 | 0 |
| bilingual | 2 | 1/2 | 2/2 | 1/2 | 1 |
| bilingual_issuer_name | 1 | 0/1 | 1/1 | 1/1 | 0 |
| bilingual_letterhead | 5 | 3/5 | 5/5 | 4/5 | 0 |
| billhead | 2 | 0/2 | 0/2 | 1/2 | 0 |
| billing_period | 1 | 1/1 | 1/1 | 1/1 | 0 |
| black_and_white | 1 | 0/1 | 0/1 | 0/1 | 0 |
| board_minutes | 2 | 1/2 | 2/2 | 2/2 | 0 |
| body_recounts_events | 1 | 0/1 | 1/1 | 1/1 | 0 |
| born_digital | 32 | 11/30 | 30/30 | 21/32 | 7 |
| bought_of | 1 | 0/1 | 0/1 | 0/1 | 0 |
| brand_names_in_letterhead | 1 | 0/1 | 0/1 | 0/1 | 0 |
| brand_vs_legal_name | 2 | 0/2 | 2/2 | 1/2 | 1 |
| canada | 3 | 2/3 | 3/3 | 3/3 | 0 |
| catalogue_type_differs | 1 | 0/1 | 0/1 | 0/1 | 0 |
| cc_in_body | 1 | 1/1 | 1/1 | 1/1 | 0 |
| cc_list | 4 | 1/4 | 4/4 | 2/4 | 0 |
| certificate | 1 | 1/1 | 1/1 | 1/1 | 0 |
| certificate_of_completion | 1 | 1/1 | 1/1 | 1/1 | 0 |
| certificate_of_insurance | 1 | 1/1 | 1/1 | 1/1 | 0 |
| certification | 1 | 0/1 | 1/1 | 0/1 | 1 |
| checkboxes | 1 | 0/1 | 1/1 | 1/1 | 0 |
| circular_letter | 2 | 0/2 | 2/2 | 0/2 | 1 |
| class_of_recipients | 7 | 0/6 | 6/6 | 2/7 | 4 |
| competing_dates | 31 | 12/29 | 28/29 | 23/31 | 8 |
| consultation_response | 1 | 0/1 | 1/1 | 1/1 | 0 |
| content_control_date | 1 | 0/1 | 1/1 | 1/1 | 0 |
| continuous_page_numbers | 1 | 1/1 | 1/1 | 1/1 | 0 |
| contract | 2 | 1/2 | 2/2 | 1/2 | 0 |
| contract_term_dates | 1 | 0/1 | 1/1 | 1/1 | 0 |
| copier_scan | 2 | 1/2 | 2/2 | 1/2 | 0 |
| copyright_years | 1 | 1/1 | 1/1 | 1/1 | 0 |
| council_minutes | 3 | 1/3 | 3/3 | 2/3 | 1 |
| court | 1 | 0/1 | 1/1 | 1/1 | 0 |
| cover_letter | 1 | 0/1 | 1/1 | 1/1 | 0 |
| cover_sheet | 3 | 0/3 | 2/3 | 2/3 | 2 |
| customer_first | 3 | 0/3 | 1/3 | 1/3 | 0 |
| customer_printed_twice | 1 | 0/1 | 1/1 | 0/1 | 1 |
| daily_rows | 1 | 1/1 | 1/1 | 1/1 | 0 |
| date_at_end | 4 | 3/4 | 4/4 | 4/4 | 0 |
| date_in_body | 1 | 1/1 | 1/1 | 1/1 | 0 |
| date_in_file_name | 2 | 0/1 | 1/1 | 2/2 | 1 |
| date_in_other_language | 1 | 0/1 | 1/1 | 0/1 | 1 |
| date_in_title | 1 | 0/1 | 1/1 | 0/1 | 0 |
| date_without_year | 4 | 3/4 | 4/4 | 3/4 | 1 |
| dated_line_at_end | 2 | 1/2 | 2/2 | 2/2 | 0 |
| dates_without_year | 1 | 1/1 | 1/1 | 1/1 | 0 |
| day_first_date | 3 | 2/3 | 3/3 | 2/3 | 1 |
| dd_mon_yyyy | 1 | 0/1 | 1/1 | 0/1 | 0 |
| dd_month_yyyy | 2 | 1/2 | 2/2 | 2/2 | 0 |
| deadline_in_body | 9 | 2/7 | 7/7 | 6/9 | 4 |
| dear_accounting_officer_letter | 1 | 0/1 | 1/1 | 0/1 | 1 |
| decision_letter | 1 | 0/1 | 1/1 | 1/1 | 0 |
| declassified | 3 | 1/3 | 3/3 | 1/3 | 1 |
| department_vs_city | 1 | 0/1 | 1/1 | 0/1 | 0 |
| digital_signature_date | 1 | 0/1 | 1/1 | 0/1 | 1 |
| directors_in_footer | 1 | 0/1 | 1/1 | 1/1 | 0 |
| disclaimers | 1 | 0/1 | 1/1 | 0/1 | 0 |
| docusign | 2 | 1/2 | 2/2 | 1/2 | 0 |
| docx | 3 | 1/3 | 3/3 | 2/3 | 0 |
| doit_formula | 1 | 0/1 | 0/1 | 1/1 | 0 |
| due_date | 1 | 0/1 | 1/1 | 0/1 | 1 |
| effective_date_differs | 3 | 0/2 | 2/2 | 2/3 | 2 |
| effective_dates | 1 | – | – | 1/1 | 1 |
| enclosed_documents | 1 | 1/1 | 1/1 | 1/1 | 0 |
| enclosure_has_own_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| endorsements | 1 | 1/1 | 1/1 | 1/1 | 0 |
| enforcement_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| engraved_letterhead | 1 | 0/1 | 0/1 | 1/1 | 0 |
| engraver_imprint | 1 | 0/1 | 0/1 | 1/1 | 0 |
| envelope_id_header | 2 | 1/2 | 2/2 | 1/2 | 0 |
| eu | 1 | 0/1 | 1/1 | 1/1 | 0 |
| event_date_in_heading | 1 | 1/1 | 1/1 | 1/1 | 0 |
| event_date_prominent | 1 | 0/1 | 1/1 | 0/1 | 0 |
| example_sheet | 1 | – | – | 0/1 | 1 |
| exhibits | 2 | 1/2 | 2/2 | 1/2 | 0 |
| expiration_dates | 1 | – | – | 0/1 | 1 |
| expiry_date | 1 | 0/1 | 1/1 | 1/1 | 0 |
| faint_stamp | 1 | 0/1 | 0/1 | 0/1 | 0 |
| filed_in_other_partys_case | 1 | – | – | 1/1 | 1 |
| filed_stamp | 1 | 0/1 | 0/1 | 1/1 | 1 |
| filled_blank_date | 1 | 0/1 | 1/1 | 0/1 | 0 |
| filled_form | 5 | 1/4 | 4/4 | 2/5 | 2 |
| first_name_salutation | 2 | 1/2 | 2/2 | 1/2 | 0 |
| fiscal_year | 1 | 0/1 | 1/1 | 1/1 | 0 |
| fiscal_year_dates | 1 | 0/1 | 1/1 | 0/1 | 0 |
| follow_up_letter | 1 | 1/1 | 1/1 | 1/1 | 0 |
| footer_date | 2 | 1/2 | 2/2 | 2/2 | 0 |
| footnotes | 5 | 1/5 | 5/5 | 2/5 | 0 |
| form | 7 | 3/6 | 6/6 | 4/7 | 2 |
| form_layout | 1 | 1/1 | 1/1 | 1/1 | 0 |
| form_number_date | 1 | 0/1 | 1/1 | 1/1 | 0 |
| form_revision_date | 4 | 2/4 | 4/4 | 3/4 | 0 |
| formulas | 1 | – | – | 0/1 | 1 |
| french | 2 | 0/2 | 0/2 | 1/2 | 0 |
| future_period | 2 | 0/2 | 2/2 | 1/2 | 1 |
| government_customer | 4 | 2/4 | 4/4 | 3/4 | 1 |
| government_form | 2 | 0/2 | 2/2 | 0/2 | 1 |
| grant_application | 1 | 0/1 | 1/1 | 0/1 | 0 |
| handwritten | 3 | 0/3 | 0/3 | 1/3 | 0 |
| handwritten_annotations | 1 | 0/1 | 1/1 | 0/1 | 1 |
| handwritten_date | 3 | 0/3 | 3/3 | 1/3 | 1 |
| handwritten_postscript | 1 | 1/1 | 1/1 | 1/1 | 0 |
| handwritten_signature | 5 | 2/5 | 5/5 | 2/5 | 1 |
| hearing_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| hidden_sheets | 1 | – | – | 0/1 | 1 |
| hindi | 1 | 0/1 | 1/1 | 0/1 | 1 |
| historic | 3 | 0/3 | 0/3 | 1/3 | 0 |
| historical | 3 | 1/3 | 3/3 | 1/3 | 1 |
| hong_kong | 1 | 0/1 | 1/1 | 0/1 | 0 |
| image | 3 | 0/3 | 0/3 | 1/3 | 0 |
| image_only | 11 | 6/11 | 11/11 | 7/11 | 3 |
| image_pages | 1 | 0/1 | 1/1 | 0/1 | 0 |
| improvement_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| incomplete_copy | 1 | 0/1 | 1/1 | 0/1 | 1 |
| india | 3 | 2/3 | 3/3 | 2/3 | 1 |
| industry_letter | 1 | 0/1 | 1/1 | 0/1 | 0 |
| insurer_vs_producer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| internal_correspondence | 1 | 0/1 | 1/1 | 0/1 | 0 |
| internal_directive | 1 | 0/1 | 1/1 | 1/1 | 0 |
| internal_form | 1 | 0/1 | 1/1 | 1/1 | 0 |
| investment_pool | 1 | 0/1 | 1/1 | 0/1 | 0 |
| invoice | 6 | 2/6 | 4/6 | 4/6 | 1 |
| ireland | 2 | 0/2 | 2/2 | 2/2 | 0 |
| issuer_in_header | 1 | 0/1 | 1/1 | 0/1 | 0 |
| issuer_in_logo | 14 | 5/13 | 13/13 | 8/14 | 3 |
| issuer_in_remittance_block | 1 | 0/1 | 1/1 | 0/1 | 1 |
| issuer_in_seal | 1 | 0/1 | 1/1 | 0/1 | 1 |
| issuer_name_in_customer_block | 1 | 1/1 | 1/1 | 1/1 | 0 |
| issuer_not_in_heading | 1 | 0/1 | 1/1 | 0/1 | 1 |
| issuer_not_named_as_city | 1 | 0/1 | 1/1 | 1/1 | 0 |
| labelled_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| labelled_dates | 1 | 0/1 | 1/1 | 1/1 | 0 |
| law_firm_recipient | 1 | 1/1 | 1/1 | 1/1 | 0 |
| lease | 1 | 1/1 | 1/1 | 1/1 | 0 |
| legal_name_in_payable_line | 1 | 1/1 | 1/1 | 1/1 | 0 |
| letter | 15 | 5/14 | 13/14 | 10/15 | 3 |
| letter_from_company | 1 | 0/1 | 1/1 | 1/1 | 0 |
| letterhead | 10 | 4/9 | 8/9 | 7/10 | 4 |
| letterhead_logo | 3 | 2/3 | 3/3 | 2/3 | 0 |
| line_item_dates | 1 | 0/1 | 1/1 | 1/1 | 0 |
| lithographed_letterhead | 1 | 0/1 | 0/1 | 0/1 | 0 |
| litigation_named | 1 | 0/1 | 1/1 | 1/1 | 0 |
| local_government | 3 | 2/3 | 3/3 | 3/3 | 0 |
| lockbox_address | 1 | 1/1 | 1/1 | 1/1 | 0 |
| logo_issuer | 3 | 1/3 | 3/3 | 2/3 | 1 |
| many_companies_named | 1 | – | – | 0/1 | 1 |
| many_dates | 8 | 5/8 | 8/8 | 6/8 | 1 |
| many_named_organisations | 7 | 3/7 | 7/7 | 4/7 | 0 |
| many_parties | 1 | – | – | 1/1 | 1 |
| many_signers | 2 | 1/2 | 2/2 | 1/2 | 0 |
| map_page | 1 | 1/1 | 1/1 | 1/1 | 0 |
| memo | 6 | 1/6 | 6/6 | 1/6 | 4 |
| memo_header | 3 | 0/3 | 3/3 | 0/3 | 3 |
| memorandum | 4 | 0/4 | 4/4 | 0/4 | 3 |
| memorandum_of_understanding | 1 | 0/1 | 1/1 | 0/1 | 0 |
| metadata_date_trap | 29 | 11/27 | 27/27 | 17/29 | 7 |
| metadata_party_trap | 7 | 3/6 | 6/6 | 6/7 | 2 |
| metadata_title_trap | 1 | 0/1 | 1/1 | 0/1 | 0 |
| ministerial_letter | 1 | 0/1 | 1/1 | 0/1 | 0 |
| minutes | 5 | 2/5 | 5/5 | 4/5 | 1 |
| missing_page | 1 | 1/1 | 1/1 | 1/1 | 0 |
| mixed_digital_and_image_pages | 1 | 0/1 | 1/1 | 0/1 | 0 |
| mixed_scan_and_digital | 1 | 1/1 | 1/1 | 1/1 | 0 |
| modern | 48 | 18/45 | 44/45 | 31/48 | 12 |
| month_only_date | 1 | 0/1 | 1/1 | 0/1 | 0 |
| month_year_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| multiple_sheets | 1 | – | – | 0/1 | 1 |
| name_variant_in_signature_block | 1 | 0/1 | 1/1 | 0/1 | 0 |
| named_officials | 6 | 0/6 | 5/6 | 4/6 | 2 |
| named_person_at_org | 10 | 5/10 | 10/10 | 7/10 | 1 |
| new_zealand | 1 | 0/1 | 1/1 | 0/1 | 0 |
| newspaper | 1 | 1/1 | 1/1 | 1/1 | 0 |
| newspaper_advertisement | 1 | 0/1 | 1/1 | 1/1 | 0 |
| no_addressee_block | 1 | 0/1 | 1/1 | 0/1 | 0 |
| no_dated_line | 2 | 1/1 | 1/1 | 2/2 | 1 |
| no_document_date | 3 | – | – | 2/3 | 3 |
| no_invoice_number | 1 | 1/1 | 1/1 | 1/1 | 0 |
| no_issuer_printed | 1 | 0/1 | 1/1 | 0/1 | 1 |
| no_specific_addressee | 1 | 0/1 | 1/1 | 0/1 | 0 |
| no_text_layer | 7 | 5/7 | 7/7 | 5/7 | 1 |
| non_english_salutation | 1 | 0/1 | 1/1 | 0/1 | 0 |
| nonprofit | 2 | 1/2 | 2/2 | 2/2 | 0 |
| northern_ireland | 2 | 0/2 | 2/2 | 0/2 | 1 |
| notice | 9 | 4/8 | 8/8 | 8/9 | 2 |
| notice_author_trap | 1 | 1/1 | 1/1 | 1/1 | 0 |
| notice_of_hearing | 1 | 1/1 | 1/1 | 1/1 | 0 |
| notice_of_public_hearing | 1 | 1/1 | 1/1 | 1/1 | 0 |
| notification | 1 | 0/1 | 1/1 | 0/1 | 1 |
| number_looks_like_date | 3 | 1/3 | 3/3 | 1/3 | 2 |
| numeric_date | 3 | 1/3 | 3/3 | 2/3 | 0 |
| ocr_text_layer | 4 | 1/4 | 3/4 | 2/4 | 2 |
| offer_expiry_date | 1 | 0/1 | 1/1 | 0/1 | 0 |
| office | 4 | 1/3 | 3/3 | 2/4 | 1 |
| office_memorandum | 1 | 1/1 | 1/1 | 1/1 | 0 |
| officials_by_title | 1 | 0/1 | 1/1 | 0/1 | 1 |
| officials_in_letterhead | 1 | 0/1 | 1/1 | 1/1 | 0 |
| on_behalf_of | 1 | 1/1 | 1/1 | 1/1 | 0 |
| open_letter | 1 | 0/1 | 1/1 | 0/1 | 0 |
| order | 1 | 0/1 | 1/1 | 0/1 | 0 |
| ordinal_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| parent_body_in_letterhead | 1 | 1/1 | 1/1 | 1/1 | 0 |
| parish_council | 2 | 2/2 | 2/2 | 2/2 | 0 |
| partly_printed_date_line | 1 | 0/1 | 0/1 | 1/1 | 0 |
| partner_agency_named | 1 | 0/1 | 1/1 | 0/1 | 1 |
| payer_named | 1 | 1/1 | 1/1 | 1/1 | 0 |
| payer_named_in_body | 1 | 0/1 | 0/1 | 0/1 | 0 |
| payment_confirmation | 1 | 1/1 | 1/1 | 1/1 | 0 |
| period_end_in_title | 1 | 1/1 | 1/1 | 1/1 | 0 |
| person_subject | 2 | 0/2 | 2/2 | 1/2 | 1 |
| personal_sender_on_letterhead | 1 | 1/1 | 1/1 | 1/1 | 0 |
| photograph | 1 | 0/1 | 0/1 | 0/1 | 0 |
| placeholder_example_data | 1 | – | – | 0/1 | 1 |
| platform_vendor_footer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| policy_period | 1 | 1/1 | 1/1 | 1/1 | 0 |
| postscript_note | 1 | 0/1 | 0/1 | 0/1 | 0 |
| pounds_shillings_pence | 1 | 0/1 | 0/1 | 0/1 | 0 |
| print_date_footer | 1 | 0/1 | 1/1 | 1/1 | 0 |
| printer_imprint | 1 | 0/1 | 0/1 | 0/1 | 0 |
| processing_fee | 1 | 1/1 | 1/1 | 1/1 | 0 |
| public_body_party | 1 | 1/1 | 1/1 | 1/1 | 0 |
| public_notice | 2 | 0/2 | 2/2 | 2/2 | 0 |
| purchase_order | 1 | 0/1 | 1/1 | 0/1 | 0 |
| rate_notice | 1 | – | – | 1/1 | 1 |
| rate_table | 1 | – | – | 1/1 | 1 |
| re_line_references_document | 2 | 0/2 | 2/2 | 2/2 | 0 |
| receipt | 2 | 1/2 | 1/2 | 1/2 | 0 |
| receipted | 3 | 0/3 | 0/3 | 1/3 | 0 |
| recitals_with_dates | 1 | 0/1 | 1/1 | 0/1 | 0 |
| redacted | 2 | 2/2 | 2/2 | 2/2 | 0 |
| redacted_addressee | 1 | 0/1 | 1/1 | 1/1 | 0 |
| redacted_signer | 1 | 1/1 | 1/1 | 1/1 | 0 |
| redactions | 1 | 0/1 | 1/1 | 1/1 | 0 |
| reference_number | 15 | 4/14 | 14/14 | 9/15 | 6 |
| referenced_agreement | 2 | 0/2 | 2/2 | 0/2 | 0 |
| referenced_dates | 16 | 5/16 | 15/16 | 9/16 | 5 |
| regulator | 4 | 3/4 | 4/4 | 3/4 | 0 |
| regulator_correspondence | 1 | 1/1 | 1/1 | 1/1 | 0 |
| regulator_named | 1 | – | – | 1/1 | 1 |
| remittance_slip | 1 | 0/1 | 1/1 | 0/1 | 1 |
| renewal_date | 1 | 0/1 | 1/1 | 1/1 | 0 |
| resolution_number_like_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| response_letter | 4 | 2/4 | 3/4 | 3/4 | 1 |
| revision_date_header | 1 | 0/1 | 1/1 | 0/1 | 0 |
| running_footer | 2 | 0/2 | 2/2 | 1/2 | 0 |
| scanned | 14 | 6/14 | 13/14 | 8/14 | 5 |
| schedule_table | 1 | 1/1 | 1/1 | 1/1 | 0 |
| seal_date | 1 | 0/1 | 1/1 | 0/1 | 1 |
| seal_issuer | 1 | 0/1 | 1/1 | 0/1 | 0 |
| security_marking | 4 | 1/4 | 4/4 | 2/4 | 1 |
| service_period | 1 | 0/1 | 1/1 | 0/1 | 0 |
| short | 5 | 3/5 | 5/5 | 3/5 | 2 |
| show_through | 1 | 0/1 | 0/1 | 0/1 | 0 |
| signatory_trap | 5 | 2/5 | 5/5 | 3/5 | 1 |
| signatory_vs_org | 2 | 0/2 | 2/2 | 0/2 | 2 |
| signature_at_end | 1 | 0/1 | 1/1 | 1/1 | 0 |
| signature_block | 1 | 1/1 | 1/1 | 1/1 | 0 |
| signature_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| signature_dates | 2 | 0/2 | 2/2 | 0/2 | 0 |
| signature_dates_before_stated_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| signature_on_later_page | 1 | 0/1 | 1/1 | 0/1 | 1 |
| signature_only_no_typed_name | 2 | 2/2 | 2/2 | 2/2 | 0 |
| signature_scan | 6 | 2/6 | 5/6 | 4/6 | 3 |
| signature_without_title | 1 | 0/1 | 1/1 | 0/1 | 0 |
| signed_bracket | 1 | 0/1 | 1/1 | 1/1 | 0 |
| signer_for_firm | 2 | 0/2 | 0/2 | 1/2 | 0 |
| signer_for_issuer | 1 | 0/1 | 0/1 | 0/1 | 0 |
| single_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| small_page | 1 | 0/1 | 1/1 | 1/1 | 0 |
| software_vendor_footer | 1 | 0/1 | 1/1 | 1/1 | 0 |
| special_district | 1 | 1/1 | 1/1 | 1/1 | 0 |
| spreadsheet | 1 | – | – | 0/1 | 1 |
| staff_names | 7 | 3/6 | 6/6 | 5/7 | 2 |
| stamp_date | 2 | 0/2 | 1/2 | 1/2 | 1 |
| stamped_date | 2 | 1/2 | 2/2 | 1/2 | 1 |
| statement | 2 | 1/2 | 2/2 | 1/2 | 0 |
| statement_date_equals_period_end | 2 | 1/2 | 2/2 | 1/2 | 0 |
| statement_period | 2 | 1/2 | 2/2 | 1/2 | 0 |
| statute_date | 2 | 1/2 | 2/2 | 1/2 | 1 |
| statutory_notice | 1 | 1/1 | 1/1 | 1/1 | 0 |
| subject_vs_requester | 1 | 0/1 | 1/1 | 1/1 | 0 |
| tables | 3 | 2/3 | 3/3 | 3/3 | 0 |
| tax_id | 1 | 1/1 | 1/1 | 1/1 | 0 |
| term_end_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| third_party_named_in_body | 3 | 2/3 | 3/3 | 3/3 | 0 |
| three_roles | 1 | 1/1 | 1/1 | 1/1 | 0 |
| timestamp_date | 1 | 1/1 | 1/1 | 1/1 | 0 |
| transaction_dates | 1 | 0/1 | 1/1 | 0/1 | 0 |
| two_addressees | 1 | 0/1 | 1/1 | 0/1 | 0 |
| two_digit_year | 3 | 2/3 | 3/3 | 3/3 | 0 |
| two_public_bodies | 1 | 0/1 | 1/1 | 0/1 | 0 |
| type_not_printed | 1 | 0/1 | 1/1 | 0/1 | 1 |
| typed_fill_in | 1 | 0/1 | 1/1 | 0/1 | 1 |
| typewritten | 3 | 1/3 | 3/3 | 1/3 | 1 |
| typo_in_address | 1 | 1/1 | 1/1 | 1/1 | 0 |
| uk | 7 | 5/7 | 7/7 | 5/7 | 1 |
| uk_date_format | 1 | 1/1 | 1/1 | 1/1 | 0 |
| undated | 1 | – | – | 1/1 | 1 |
| university | 1 | 0/1 | 1/1 | 0/1 | 1 |
| us_date_format | 13 | 5/13 | 12/13 | 9/13 | 3 |
| us_federal | 6 | 1/6 | 6/6 | 3/6 | 2 |
| us_local | 21 | 9/19 | 19/19 | 13/21 | 5 |
| us_state | 6 | 0/6 | 5/6 | 2/6 | 4 |
| utility | 2 | 1/1 | 1/1 | 2/2 | 1 |
| vendor_document_attached | 1 | 0/1 | 1/1 | 0/1 | 0 |
| web_page_render | 1 | 1/1 | 1/1 | 1/1 | 0 |
| xlsx | 1 | – | – | 0/1 | 1 |
| year_in_title | 3 | 1/3 | 3/3 | 2/3 | 1 |

## Routes

- **Pages:** fast 85 · layout 39 · ocr 38 · ocr_regions 3
- **Documents by route class:** fast 14 · layout 18 · ocr 19 · ocr_regions 3

## Where the time goes

| Stage | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `total_ms` | 54 | 28.21 s | 39.17 s | 50.52 s |
| `extraction_wall_ms` | 54 | 11.7 ms | 6.66 s | 10.04 s |
| `worker_total_ms` | 54 | 11.1 ms | 6.66 s | 10.04 s |
| `worker_snapshot_ms` | 54 | 0.26 ms | 0.72 ms | 1.7 ms |
| `worker_parse_ms` | 54 | 3.0 ms | 43.6 ms | 228.2 ms |
| `worker_analysis_ms` | 54 | 0.43 ms | 3.4 ms | 7.9 ms |
| `worker_render_ms` | 54 | 0.00 ms | 542.2 ms | 963.0 ms |
| `worker_image_decode_ms` | 54 | 0.00 ms | 14.3 ms | 33.6 ms |
| `worker_ocr_ms` | 54 | 0.00 ms | 11.56 s | 19.32 s |
| `worker_ocr_encode_ms` | 54 | 0.00 ms | 875.3 ms | 1.34 s |
| `worker_ocr_engine_ms` | 54 | 0.00 ms | 10.46 s | 17.75 s |
| `worker_vision_ms` | 54 | 0.00 ms | 5.0 ms | 9.0 ms |
| `analyze_wall_ms` | 54 | 27.39 s | 38.21 s | 50.52 s |
| `distill_ms` | 54 | 2.1 ms | 9.1 ms | 27.2 ms |
| `prompt_ms` | 54 | 0.03 ms | 0.04 ms | 0.08 ms |
| `inference_ms` | 54 | 27.38 s | 38.20 s | 50.50 s |
| `prefill_ms` | 54 | 10.94 s | 23.27 s | 32.24 s |
| `generation_ms` | 54 | 14.93 s | 18.60 s | 21.87 s |
| `validation_ms` | 54 | 4.7 ms | 9.5 ms | 23.9 ms |
| `naming_ms` | 54 | 0.21 ms | 1.00 ms | 1.9 ms |
| `index_ms` | 54 | 1.6 ms | 8.0 ms | 17.4 ms |
| `retrieval_ms` | 54 | 0.03 ms | 0.86 ms | 1.5 ms |

| Measure | Docs | p50 | p95 | Max |
| --- | ---: | ---: | ---: | ---: |
| `prefill_tok_per_s` | 54 | 58.8 tok/s | 60.8 tok/s | 61.1 tok/s |
| `generation_tok_per_s` | 54 | 6.0 tok/s | 6.2 tok/s | 6.2 tok/s |
| `prompt_tokens` | 54 | 651 | 1405 | 1917 |
| `cached_tokens` | 54 | 477 | 477 | 499 |
| `generated_tokens` | 54 | 89 | 110 | 125 |
| `estimated_prompt_tokens` | 54 | 1341 | 1999 | 2269 |
| `model_requests` | 54 | 1 | 1 | 1 |
| `redistillations` | 54 | 0 | 0 | 0 |
| `source_characters` | 54 | 3737 | 20223 | 43499 |
| `digest_characters` | 54 | 2315 | 3847 | 5564 |
| `prompt_characters` | 54 | 4364 | 5901 | 7613 |
| `worker_ocr_pages` | 54 | 0 | 4 | 5 |
| `worker_ocr_passes` | 54 | 0 | 4 | 5 |
| `worker_orientation_passes` | 54 | 0 | 4 | 5 |
| `worker_rendered_pixels` | 54 | 0 | 33660000 | 42075000 |
| `index_units` | 54 | 29 | 233 | 353 |
| `context_units` | 54 | 20 | 37 | 43 |
| `context_tokens` | 54 | 752 | 1409 | 1681 |

## Extraction time

| Route class | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fast | 14 | 4.2 ms | 60.9 ms | 3.9 ms | 60.5 ms | 59.4 ms | 0.51 ms | 0.00 ms | 0.00 ms |
| layout | 18 | 6.3 ms | 245.7 ms | 6.0 ms | 244.6 ms | 228.2 ms | 7.9 ms | 0.00 ms | 0.00 ms |
| ocr_regions | 3 | 623.8 ms | 717.6 ms | 623.1 ms | 717.0 ms | 43.6 ms | 4.2 ms | 103.9 ms | 580.6 ms |
| ocr | 19 | 2.21 s | 10.04 s | 2.21 s | 10.04 s | 37.5 ms | 1.6 ms | 963.0 ms | 19.32 s |

| Pages | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 21 | 7.0 ms | 2.21 s | 6.1 ms | 2.21 s | 20.8 ms | 0.56 ms | 82.8 ms | 2.12 s |
| 2-4 | 21 | 9.5 ms | 6.50 s | 8.7 ms | 6.50 s | 31.0 ms | 2.8 ms | 288.5 ms | 10.82 s |
| 5-9 | 10 | 17.2 ms | 10.04 s | 16.6 ms | 10.04 s | 13.2 ms | 2.4 ms | 963.0 ms | 19.32 s |
| 10-24 | 2 | 245.7 ms | 521.6 ms | 244.6 ms | 520.3 ms | 228.2 ms | 7.9 ms | 80.1 ms | 357.2 ms |

| Kind | Docs | p50 wall | p95 wall | p50 worker | p95 worker | p95 parse | p95 analysis | p95 render | p95 OCR |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| contract | 2 | 245.7 ms | 521.6 ms | 244.6 ms | 520.3 ms | 228.2 ms | 7.9 ms | 80.1 ms | 357.2 ms |
| form | 6 | 15.3 ms | 3.02 s | 14.6 ms | 3.02 s | 10.7 ms | 2.8 ms | 153.2 ms | 4.37 s |
| invoice | 6 | 6.3 ms | 1.61 s | 6.0 ms | 1.61 s | 37.5 ms | 1.1 ms | 73.7 ms | 1.55 s |
| letter | 15 | 17.2 ms | 10.04 s | 16.6 ms | 10.04 s | 59.4 ms | 2.4 ms | 963.0 ms | 19.32 s |
| memo | 6 | 7.0 ms | 6.66 s | 6.1 ms | 6.66 s | 31.0 ms | 1.6 ms | 288.5 ms | 11.56 s |
| minutes | 5 | 11.4 ms | 6.50 s | 10.8 ms | 6.50 s | 8.4 ms | 1.6 ms | 349.0 ms | 10.82 s |
| notice | 9 | 5.5 ms | 1.31 s | 5.3 ms | 1.31 s | 15.4 ms | 3.4 ms | 74.0 ms | 1.21 s |
| purchase_order | 1 | 3.61 s | 3.61 s | 3.61 s | 3.61 s | 2.5 ms | 1.3 ms | 574.8 ms | 6.68 s |
| receipt | 2 | 449.0 ms | 501.2 ms | 448.7 ms | 500.4 ms | 12.4 ms | 0.16 ms | 46.8 ms | 436.2 ms |
| statement | 2 | 4.3 ms | 9.5 ms | 3.7 ms | 8.7 ms | 5.9 ms | 1.4 ms | 0.00 ms | 0.00 ms |

Over the documents that completed. Wall is the runner's clock around the request; worker is the worker's own total. OCR is summed over the pages, so when the worker reads pages in parallel it can exceed the total. A document's route class is the most expensive route any of its pages took (ocr > ocr_regions > layout > fast), or `unrouted` when the worker sent no layouts.

## Memory

| Process | Typical peak (p50) | Highest peak | During |
| --- | ---: | ---: | ---: |
| Parser worker | 237 MB | 1063 MB | real7-purchase_order-01 |
| Model server | 6078 MB | 6128 MB | real7-invoice-04 |
| Benchmark (engine) | 15 MB | 19 MB | real7-minutes-05 |

Resident memory sampled every 25 ms per document; a spike shorter than that can be missed.

## Misses (32)

- **real7-letter-01**: expected `2024-06-24 Open Letter from Electricity Authority.pdf`, got `2024-06-24 Open industry letter regarding the events of 10 May 2024 to industry participants.pdf` · review: PARTY_UNSUPPORTED
- **real7-letter-02**: expected `2025-07-31 Letter from Australian Prudential Regulation Authority.pdf`, got `2025-07-31 Letter to Federal Member for Rankin.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, LOW_CONFIDENCE
- **real7-letter-03**: expected `2024-06-20 Letter to Committee on Economic and Monetary Affairs.pdf`, got `2024-06-20 First Progress Report for European Parliament.pdf` · review: LOW_CONFIDENCE
- **real7-letter-07**: expected `2024-03-19 Consultation Response from Uisce Eireann.pdf`, got `2024-03-19 Review of Large Energy Users Connection Policy for Uisce Éireann.pdf` · **filed without review**
- **real7-letter-08**: expected `2021-06-30 Letter from Department of Justice.docx`, got `2021-06-30 Letter from Minister's Office.docx` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING
- **real7-letter-09**: expected `2025-10-30 Dear Accounting Officer Letter from Department of Finance.pdf`, got `2025-10-30 DAO letter to Accounting Officer.pdf` · trap: party Accounting Officer (class of recipients ('Dear Accounting Officer')) · review: LOW_CONFIDENCE
- **real7-letter-10**: expected `2024-02-13 Letter to Mayes Middleton.pdf`, got `2024-02-14 Filing Receipt from Public Utility Commission of Texas.pdf` · trap: date 2024-02-14 (the Commission's filing-receipt date on page 1) · review: PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED
- **real7-letter-12**: expected `2025-04-07 Circular from Hong Kong Monetary Authority.pdf`, got `2025-04-07 Letter from The Chief Executive.pdf` · review: TYPE_UNSUPPORTED, TYPE_INFERRED, TYPE_MISSING, PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED
- **real7-letter-13**: expected `2024-10-03 Decision Letter from British Columbia Utilities Commission.pdf`, got `2024-10-03 Letter L-29-24 for Rize Ayalaland Limited Partnership.pdf` · **filed without review**
- **real7-notice-02**: expected `2026-08-21 Notice of Proposal to Make Bye-Laws from Cork City Council.pdf`, got `2026-08-21 Notice of Proposal to Make Cork City for Cork City Council.pdf` · review: PARTY_UNSUPPORTED
- **real7-notice-03**: expected `2026-03-03 Public Notice from United States District Court for the Eastern District of Wisconsin.pdf`, got `2026-03-03 Public Notice for Eastern District of Wisconsin.pdf` · review: LOW_CONFIDENCE
- **real7-notice-05**: expected `2026-02-11 Procedural Notice from U.S. Small Business Administration.pdf`, got `2026-02-11 SBA Procedural Notice to All SBA Employees.pdf` · review: PARTY_UNSUPPORTED
- **real7-notice-07**: expected `2026-07-07 Notification from University of Delhi.pdf`, got `2026-07-07 Notification for Yogesh Singh.pdf` · trap: party Yogesh Singh (professor re-appointed as Vice Chancellor, whom the notification is about) · review: TYPE_MISSING, PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED
- **real7-invoice-02**: expected `2026-08-05 Invoice from Orlando Utilities Commission.pdf`, got `2026-08-05 Invoice Invoice Description from Ocala Electric Utility.pdf` · trap: party Ocala Electric Utility (the customer billed, printed twice at the top) · review: DATE_AMBIGUOUS, PARTY_UNSUPPORTED
- **real7-invoice-04**: expected `2026-10-26 Invoice from Beador Construction Company, Inc.pdf`, got `2026-10-26 Attachment B Invoice from Beador Construction Company, Inc.pdf` · **filed without review**
- **real7-invoice-06**: expected `1794-04-18 Bill from Wm Poyntell.jpg`, got `Document from B.3MMSTLE.jpg` · review: TYPE_MISSING, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, DESCRIPTION_INVALID, PARSER_WARNING, LOW_CONFIDENCE
- **real7-invoice-07**: expected `1842-01-08 Bill from Constantin.jpg`, got `Document - CONSTANTIN.jpg` · review: TYPE_MISSING, DATE_UNSUPPORTED, PARSER_WARNING, LOW_CONFIDENCE
- **real7-receipt-01**: expected `1844-08-24 Receipt from Vilmorin-Andrieux & Cie.jpg`, got `Document from machangers.jpg` · review: TYPE_MISSING, DATE_UNSUPPORTED, PARTY_UNSUPPORTED, PARSER_WARNING, LOW_CONFIDENCE
- **real7-statement-01**: expected `2026-09-30 Monthly Statement from CalFIT.pdf`, got `2026-09-30 Monthly Statement from Chandler Asset Management, Inc.pdf` · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real7-purchase_order-01**: expected `2026-10-08 Purchase Order to Oracle America, Inc.pdf`, got `2026-10-08 Purchase Order from Denver, CO 80202 United States of America.pdf` · review: LOW_CONFIDENCE
- **real7-form-01**: expected `2026-01-28 County Government Application from Fayette County.pdf`, got `2026-01-28 County Government Application Kbems G-1 for County Government.pdf` · review: LOW_CONFIDENCE
- **real7-form-02**: expected `2020-06-30 Certification for Receipt of Funds from City of Chula Vista.pdf`, got `2020-06-30 Certification for Receipt of Funds from Maria Kachadoorian.pdf` · trap: party Maria Kachadoorian (the city manager who certifies and signs) · review: PARTY_UNSUPPORTED
- **real7-form-04**: expected `2026-11-02 Resolution Request for Bayaud Works, LLC.docx`, got `2026-11-02 OrdinanceResolution Request from Bayaud Works, LLC.docx` · review: PARTY_UNSUPPORTED
- **real7-contract-02**: expected `2025-01-29 Memorandum of Understanding between City of Hayward and Hayward Area Recreation and Park District.pdf`, got `2025-01-29 Memorandum of Understanding to General Manager Hayward Area Recreation and Park District.pdf` · review: PARTY_UNSUPPORTED
- **real7-memo-01**: expected `2025-07-25 Memorandum from Office of Financial Management.pdf`, got `2025-07-25 Community Engagement to Agency Directors.pdf` · trap: party Agency Directors (class of recipients in the TO: line) · review: TYPE_UNSUPPORTED, TYPE_INFERRED
- **real7-memo-02**: expected `1965-07-20 Memorandum to Chairman, Joint Chiefs of Staff.pdf`, got `1965-07-20 Memorandum for the Chairman, Joint Chtefs of Staff from The Director of Defense Research and Engineering.pdf` · trap: party Director of Defense Research and Engineering (sender of the covering brief, not of the memorandum) · review: PARTY_UNSUPPORTED, DESCRIPTION_UNSUPPORTED, LOW_CONFIDENCE
- **real7-memo-03**: expected `1979-04-09 Memorandum from Gerard Smith.pdf`, got `1979-04-09 Memorandum for the Secretary of State to Defartmenici State Ambassadok A' Lare.pdf` · review: TYPE_INFERRED, PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real7-memo-04**: expected `2025-08-18 Memorandum from Virginia Department of Criminal Justice Services.pdf`, got `2025-08-18 Memo to K-12 School Superintendents.pdf` · trap: party K-12 School Superintendents (class of addressees) · review: PARTY_UNSUPPORTED, LOW_CONFIDENCE
- **real7-memo-05**: expected `2026-07-16 Memorandum from Department of Veterans Affairs.pdf`, got `2026-07-16 Veterans Affairs Memorandum to Jeffrey C. Neill.pdf` · trap: party Jeffrey C. Neill (Executive Director who signs) · **filed without review**
- **real7-minutes-01**: expected `2026-09-08 City Council Meeting Minutes for City of Poplar Bluff.pdf`, got `2026-09-08 Minutes of a Regular Meeting from City Council of the City of Poplar Bluff, Missouri.pdf` · **filed without review**
- **real7-minutes-02**: expected `2026-01-07 Town Council Meeting Minutes for Town of Lynndyl.pdf`, got `2026-01-07 read his application and opened it up for questions for Chase Nielson.pdf` · trap: party Chase Nielson (resident appointed to the mayoral vacancy) · review: TYPE_UNSUPPORTED, TYPE_INFERRED
- **real7-minutes-04**: expected `2026-04-22 Board of Directors Meeting Minutes for Utah League of Cities & Towns.pdf`, got `2026-04-22 Utah League of Cities & Towns Board of Directors Meeting Minutes from Utah League of Cities & Towns.pdf` · **filed without review**

## How to compare

Keep this run's JSON, make the change, run again, then:

```text
intern-bench compare --before before.json --after after.json --markdown diff.md
```

It recomputes every rate and count over the documents both runs scored, lists each document whose score flipped, and gives the change in p50/p95 of every stage over the documents both completed - between two live runs only, since a replay's timings are its recording's. `intern-bench report --input report.json --markdown report.md` re-renders this page from the JSON.
